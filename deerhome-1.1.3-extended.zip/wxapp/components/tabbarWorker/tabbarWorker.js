// components/tabbarWorker/tabbarWorker.js
Component({

  /**
   * 组件的属性列表
   */
  properties: {
    page: {
      type: Number,
      value: 0
    }
  },

  /**
   * 组件的初始数据
   */
  data: {
    current:0,
    tabBar: [
      {
        pagePath: '/pages/workerCode/home',
        text: '抢单',
        iconPath: '/static/tabbar/worker.png',
        selectedIconPath: '/static/tabbar/worker_on.png'
      },
      {
        pagePath: '/pages/workerCode/task',
        text: '任务',
        "selectedIconPath": "/static/tabbar/order_on.png",
        "iconPath": "/static/tabbar/order.png",
        num: 0,
        isDot: false,
        verify: false
      },
      {
        pagePath: '/pages/workerCode/my',
        text: '我的',
        "selectedIconPath": "/static/tabbar/user_on.png",
        "iconPath": "/static/tabbar/user.png"
      }
    ]
  },
  lifetimes:{
    attached(){
      this.setData({
        current:this.data.page
      })
      this.load();
    },
  },
  methods: {
    async load(){
      let sf=wx.getStorageSync('sf') || '';
      if(sf!='worker'){
        wx.switchTab({
          url:"/pages/index/index"
        })
        return;
      }
      let res=await wx.util.post("task/count_num");
      this.setData({
        ['tabBar[1].num']:res.data
      })
    },
    tabbarSwitch(s) {
      let e=s.detail;
      let isLogin = false;
      if (e.verify && !isLogin) {
        wx.util.toast('您还未登录，请先登录');
      } else {
        this.setData({
          current: e.index
        })
        wx.redirectTo({
          url:e.pagePath
        })
      }
    }
  }
})