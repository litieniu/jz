Component({
  properties: {
    
  },
  data :{
    formData: {
      address:'',
      detailAddress: '',
      userName: '',
      userPhone: '',
      lableName: '家',
      sexType: 1, //1 先生 2 女士
    },
    labelData: ['家', '公司', '学校', '其他'],
    addressInfo: {}, //选中的地址信息
    agreeState: true, //是否是默认地址
    longitude: null,
    latitude: null,
    markerIcon: ('./static/marker.png'),
    seleIcon: ('./static/sele.png'),
    sele2Icon: ('./static/sele2.png'),
    noseleIcon: ('./static/no-sele.png'),
  },
  observers:{
    'show':function(val){
      if(val){
        this.load();
      }
    }
  },
  attached(){
    this.getLocation();
  },
  methods: {
    close() {
      this.triggerEvent('close');
    },
    setInput(e) {
      let key = e.currentTarget.dataset.key;
      let value = e.detail.value;
      this.setData({
        [key]: value
      })
    },
    setTel(tel) {
      this.setData({
        'formData.userPhone':tel
      })
    },
    //数据回显时使用此方法
    setDataInfo(obj) {
      this.setData({
        'formData.detailAddress':obj.detailAddress,
        'formData.userName':obj.userName,
        'formData.userPhone':obj.userPhone,
        'formData.lableName':obj.lableName,
        'formData.sexType':obj.sexType,
        'addressInfo.title':obj.title,
        'addressInfo.address':obj.address,
        'addressInfo.latitude':obj.latitude,
        'addressInfo.longitude':obj.longitude,
        'agreeState':obj.agreeState,
      })
    },
    //获取当前的地理位置
    getLocation() {
      let that=this;
      wx.showLoading({
        title: '正在获取定位中...',
      })
      wx.getLocation({
        type: 'gcj02',
        isHighAccuracy: true,
        geocode: 'true',
        highAccuracyExpireTime: 3500,
        success: (res) => {
          wx.hideLoading();
          that.setData({
            longitude: res.longitude,
            latitude: res.latitude
          })
        },
        fail: (res) => {
          if (res.errMsg == "getLocation:fail auth deny") {
            wx.showModal({
              content: '检测到您没打开获取信息功能权限，是否去设置打开？',
              confirmText: "确认",
              cancelText: '取消',
              success: (res) => {
                if (res.confirm) {
                  wx.openSetting({
                    success: (res) => {}
                  })
                } else {
                  return false;
                }
              }
            })
          }
        }
      })
    },
    //保存地址
    submitAddress() {
      let obj = {
        ...this.data.formData,
        ...this.data.addressInfo
      }
      obj.agreeState = this.data.agreeState
      this.triggerEvent('submitAdd',obj);
    },
    //删除地址
    deleteAddress() {
      this.triggerEvent('deteleAdd');
    },
    //选择地址、修改编辑地址
    chooseAddressView() {
      let that=this;
      wx.chooseLocation({
        success: res => {
          console.log(res)
          if (!res.name || !res.address || !res.latitude || !res.longitude) return
          let addressObj = {
            title: res.name,
            address: res.address,
            latitude: res.latitude,
            longitude: res.longitude
          }
          that.setData({
            latitude: res.latitude,
            longitude: res.longitude,
            addressInfo: addressObj
          })

        }
      });
    },
    //联系人性别选择
    chooseSex(e) {
      let type = e.currentTarget.dataset.type;
      this.setData({
        'formData.sexType': type
      })
    },
    //标签选择
    chooseLable(e) {
      let item = e.currentTarget.dataset.item;
      this.setData({
        'formData.lableName': item
      })
    },
    //点击隐私协议
    changeAgree() {
      this.setData({
        agreeState: !this.data.agreeState
      })
    }

  }
})