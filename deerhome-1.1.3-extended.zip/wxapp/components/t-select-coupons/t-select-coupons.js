Component({
  emits: ['close','confirm'],
  properties: {
    couponList: {
      type: Array,
      default () {
        return [];
      }
    },
    //控制显示
    show: {
      type: Boolean,
      default: false
    },
    page: {
      type: Number,
      default: 1
    }
  },
  data :{
      checkedValue:''
  },
  methods: {
    close() {
      this.triggerEvent('close');
    },
    radioChange(evt){
      this.setData({
        checkedValue:evt.detail.value
      })
    },
    btnConfirm() {
      if(this.data.checkedValue==""){
        wx.util.toast('请选择优惠券');
        return;
      }
      let arr={};
      arr.type=this.data.checkedValue==-1?'no':'yes';
      arr.id=0;
      arr.price=0;
      if(arr.type=='yes'){
        arr.id=this.data.couponList[this.data.checkedValue].id;
        arr.price=this.data.couponList[this.data.checkedValue].money_yh;
      }
      console.log(arr);
      this.triggerEvent('confirm',arr);
      this.close();
    }
  },
})