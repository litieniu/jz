Component({
  properties: {
    islist:{
      type:Boolean,
      value:false
    },
    width:{
      type:String,
      value:'340rpx'
    },
    color1:{
      type:String,
      value:'#2e2e2e'
    },
    color2:{
      type:String,
      value:'#e41f19'
    },
    item: {
      type: Object,
      value:{}
    }
  },
  data:{
      no_pic:'/static/images/no-pic.png',
  },
  methods: {
    detail: function(e) {
      let id=e.currentTarget.dataset.id;
      wx.navigateTo({
        url: '/pages/productDetail/productDetail?id='+id
      });
    }
  }
})