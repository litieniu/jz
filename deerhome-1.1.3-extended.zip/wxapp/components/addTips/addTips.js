// components/addTips/addTips.js
Component({

  /**
   * 组件的属性列表
   */
  properties: {
    tips: {
      type: String,
      value: "点击「添加小程序」，下次访问更便捷",
    },
    duration: {
      type: Number,
      value: 5,
    },
    color: {
      type: String,
      value: 'rgba(0,0,0,0.7)'
    }
  },

  data:{
    showTip: true,
    marginRight: '10px',
    fixedRight: 52,
    top:0
  },
  lifetimes:{
    created(){
			const systemInfo = wx.getSystemInfoSync();
			const screenWidth = systemInfo.screenWidth;
      this.setData({
        marginRight: this.estimateValue(screenWidth)
      });
			let that=this;
			wx.checkIsAddedToMyMiniProgram({
				success: (res) => {
					console.log(res);
          that.setData({
            showTip: !res.added
          });
					setTimeout(() => {
            that.setData({
              showTip: false
            });
					}, that.data.duration * 1000);
				},
				fail: (err) => {
					console.log(err);
				}
			});
    },
  },
  /**
   * 组件的方法列表
   */
  methods: {
    //拉格朗日插值算法
    estimateValue(width) {
      const data = [{
          width: 375,
          value: 52
        },
        {
          width: 320,
          value: 55
        },
        {
          width: 834,
          value: 38
        },
        {
          width: 1024,
          value: 32
        },
        {
          width: 500,
          value: 48
        }
      ];
      // 如果宽度直接等于某个样本的宽度，则返回该样本的值
      for (let i = 0; i < data.length; i++) {
        if (data[i].width === width) {
          return data[i].value;
        }
      }
      // 定义拉格朗日插值多项式L(x)
      function L(n, x) {
        let result = 1;
        for (let i = 0; i < data.length; i++) {
          if (i !== n) {
            result *= (x - data[i].width) / (data[n].width - data[i].width);
          }
        }
        return result;
      }
      // 计算f(x)
      let f_x = 0;
      for (let i = 0; i < data.length; i++) {
        f_x += L(i, width) * data[i].value;
      }
      return Math.round(f_x * 100) / 100;
    },
    hideTip() {
      wx.setStorageSync("isShowTips", 'yes');
      this.setData({ 
        showTip: false 
      })
      // this.$emit('change');
    },
  }
})