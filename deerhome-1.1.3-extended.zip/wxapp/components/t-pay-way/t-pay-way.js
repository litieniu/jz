Component({
  emits: ['close'],
  properties: {
    //控制显示
    show: {
      type: Boolean,
      default: false
    },
    //订单类型：order服务订单,card套餐次卡订单
    orderType:{
      type:String,
      default:'order'
    },
    orderId:{
      type:[Number,String],
      default:0
    },
    page:{
      type:Number,
      default:1
    }
  },
  data :{
    price:'-',
    wallet:'-',
    can:false,
    payWay:'wechat',
  },
  observers:{
    'show':function(val){
      if(val){
        this.load();
      }
    }
  },
  methods: {
    async load(){
      this.setData({
        price:'-',
        wallet:'-'
      })
      let url="order/order_pay_info";
      if(this.data.orderType=="card"){
        url="card_order/order_pay_info";
      }
      let res=await wx.util.post(url,{id:this.data.orderId},false);
      this.setData({
        price:res.data.price,
        wallet:res.data.wallet,
        can:res.data.can==1
      })
    },
    setPayWay(e){
      this.setData({
        payWay:e.detail.value
      })
    },
    close(res="") {
      let url="";
      if(res=='ok' && this.data.orderType=="card"){
        url="/pages/card/my";
      }
      this.triggerEvent('close',{url:url});
    },
    async btnPay(){
      if(this.data.payWay==""){
        wx.util.toast("请选择支付方式");
        return false;
      }
      if(this.data.payWay=="wechat"){
        await this.wechatPay();
      }
      if(this.data.payWay=="wallet"){
        await this.walletPay();
      }
      this.close('ok');
    },
    async walletPay(){
      let url="pay/wallet";
      if(this.data.orderType=="card"){
        url="card_pay/wallet";
      }
      await  wx.util.post(url,{id:this.data.orderId},false);
      wx.setStorageSync("order_tab",-1);
      wx.util.toast('支付成功');
    },
    async wechatPay(){
      let url="pay/weixin_jsapi";
      if(this.data.orderType=="card"){
        url="card_pay/weixin_jsapi";
      }
      let res=await wx.util.post(url,{id:this.data.orderId},false);
      await  wx.util.requestPayment(res.data);
      wx.setStorageSync("order_tab",-1);
      wx.util.toast('支付成功');
    },
    toCharge(){
      this.close();
      wx.navigateTo({
        url:'/pages/wallet/wallet'
      })
    },
  }
})