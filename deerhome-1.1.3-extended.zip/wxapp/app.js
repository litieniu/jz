import util from '/utils/func';
wx.util = util;
App({
  onLaunch() {

  },
  async onShow(e) {
    await wx.util.getOpenIdSys(e.query);
  }
})
