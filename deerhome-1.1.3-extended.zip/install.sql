-- phpMyAdmin SQL Dump
-- version 5.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

--
-- 表的结构 `__PREFIX__deerhome_agent_lev`
--

CREATE TABLE `__PREFIX__deerhome_agent_lev` (
  `id` int(10) NOT NULL,
  `name` varchar(300) NOT NULL COMMENT '等级名称',
  `lev` int(2) NOT NULL COMMENT '等级权重',
  `lev1` decimal(5,2) NOT NULL COMMENT '上级上浮比例',
  `lev2` decimal(5,2) NOT NULL COMMENT '上上级上浮比例',
  `task` text NOT NULL COMMENT '升级条件',
  `task_type` tinyint(1) DEFAULT '1' COMMENT '条件类型:1=全部满足,2=任意一个',
  `note` varchar(600) DEFAULT NULL COMMENT '描述',
  `bg_image` varchar(300) DEFAULT NULL COMMENT '背景图'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='分销等级';

-- --------------------------------------------------------

--
-- 表的结构 `__PREFIX__deerhome_article`
--

CREATE TABLE `__PREFIX__deerhome_article` (
  `id` int(10) NOT NULL,
  `cate` tinyint(2) NOT NULL COMMENT '分类',
  `name` varchar(300) NOT NULL COMMENT '标题',
  `con` text NOT NULL COMMENT '内容',
  `see` int(10) DEFAULT '0' COMMENT '阅读次数',
  `add_time` datetime NOT NULL COMMENT '添加时间'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='文章管理';

--
-- 转存表中的数据 `__PREFIX__deerhome_article`
--

INSERT INTO `__PREFIX__deerhome_article` (`id`, `cate`, `name`, `con`, `see`, `add_time`) VALUES
(1, 1, '用户协议', '用户协议内容', 0, '2023-06-20 11:03:07'),
(2, 1, '隐私政策', '隐私政策内容', 0, '2023-06-20 11:06:02'),
(3, 1, '充值协议', '充值协议内容', 0, '2023-06-20 11:06:02'),
(4, 2, '是否可以开发票？', '&lt;p&gt;订单完成之后可在个人中心申请开具增值税普通发票&lt;/p&gt;', 0, '2023-06-30 16:03:15'),
(5, 2, '空调维修后质保多久？', '&lt;p&gt;一般情况是保修半年，具体请联系为您服务的维修师傅。&lt;/p&gt;', 0, '2023-09-10 21:49:44'),
(6, 2, '师傅没有按时上门', '&lt;p&gt;您可以在订单详情，主动联系师傅，询问原因。&lt;/p&gt;', 0, '2023-09-10 21:50:47');

-- --------------------------------------------------------

--
-- 表的结构 `__PREFIX__deerhome_bank`
--

CREATE TABLE `__PREFIX__deerhome_bank` (
  `id` int(10) NOT NULL,
  `bank` varchar(300) NOT NULL COMMENT '银行',
  `status` tinyint(1) DEFAULT '1' COMMENT '状态:1=启用,2=停用'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='银行管理';

--
-- 转存表中的数据 `__PREFIX__deerhome_bank`
--

INSERT INTO `__PREFIX__deerhome_bank` (`id`, `bank`, `status`) VALUES
(1, '招商银行', 1),
(2, '工商银行', 1),
(3, '农业银行', 1),
(4, '中国银行', 1);

-- --------------------------------------------------------

--
-- 表的结构 `__PREFIX__deerhome_card`
--

CREATE TABLE `__PREFIX__deerhome_card` (
  `id` int(10) NOT NULL,
  `anget` tinyint(1) DEFAULT '2' COMMENT '参与分销:1=是,2=否',
  `anget_lev1` decimal(5,2) DEFAULT '0.00' COMMENT '上级分佣',
  `anget_lev2` decimal(5,2) DEFAULT '0.00' COMMENT '上上级分佣',
  `name` varchar(300) NOT NULL COMMENT '产品名称',
  `status` tinyint(1) DEFAULT '1' COMMENT '状态:1=正常,2=下架	',
  `price` decimal(10,2) NOT NULL COMMENT '售价',
  `price_market` decimal(10,2) NOT NULL COMMENT '原价',
  `face_image` varchar(300) DEFAULT NULL COMMENT '封面图',
  `img_images` varchar(600) DEFAULT NULL COMMENT '图片集',
  `createtime` datetime NOT NULL COMMENT '创建时间',
  `updatetime` datetime DEFAULT NULL COMMENT '更新时间',
  `weigh` int(10) DEFAULT '100' COMMENT '排序',
  `body_con` text COMMENT '图文详情',
  `view_times` int(10) DEFAULT '0' COMMENT '浏览次数',
  `sale_times` int(10) DEFAULT '0' COMMENT '销量',
  `fake_sale_times` int(10) DEFAULT '0' COMMENT '基础销量',
  `vip_discount` tinyint(1) DEFAULT '2' COMMENT '会员折扣:1=是,2=否',
  `item_show` tinyint(1) DEFAULT '1' COMMENT '产品页展示:1=是,2=否',
  `time_area` tinyint(1) DEFAULT '1' COMMENT '有效期:1=永久,2=月卡,3=季卡,4=年卡',
  `is_home` tinyint(1) DEFAULT '1' COMMENT '首页:1=是,2=否'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='套餐次卡';

-- --------------------------------------------------------

--
-- 表的结构 `__PREFIX__deerhome_card_items`
--

CREATE TABLE `__PREFIX__deerhome_card_items` (
  `id` int(10) NOT NULL,
  `deerhome_card_id` int(10) NOT NULL,
  `deerhome_items_id` int(10) NOT NULL DEFAULT '0' COMMENT '产品id',
  `deerhome_items_gg_hash` varchar(70) NOT NULL COMMENT '产品规格标识hash',
  `price` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '单价',
  `num` int(10) NOT NULL COMMENT '次数'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='套餐内产品';

-- --------------------------------------------------------

--
-- 表的结构 `__PREFIX__deerhome_card_order`
--

CREATE TABLE `__PREFIX__deerhome_card_order` (
  `id` int(10) NOT NULL,
  `deerhome_user_id` int(10) NOT NULL COMMENT '用户id',
  `sn` varchar(50) NOT NULL COMMENT '订单号',
  `status` tinyint(1) DEFAULT '1' COMMENT '状态:1=待支付,2=使用中,3=已用完',
  `deerhome_card_id` int(10) NOT NULL COMMENT '套餐id',
  `deerhome_card_name` varchar(300) NOT NULL COMMENT '套餐名称',
  `price` decimal(10,2) NOT NULL COMMENT '原价',
  `price_yh` decimal(10,2) NOT NULL COMMENT '优惠金额',
  `price_need_pay` decimal(10,2) NOT NULL COMMENT '订单金额',
  `price_payed` decimal(10,2) DEFAULT '0.00' COMMENT '实际支付',
  `add_time` datetime NOT NULL COMMENT '创建时间',
  `pay_time` datetime DEFAULT NULL COMMENT '支付时间',
  `done_time` datetime DEFAULT NULL COMMENT '完成时间',
  `agent_lev1_uid` int(10) DEFAULT '0' COMMENT '上级uid',
  `agent_lev1_percent` decimal(10,2) DEFAULT '0.00' COMMENT '上级分佣百分比',
  `agent_lev1_price` decimal(10,2) DEFAULT '0.00' COMMENT '上级分佣',
  `agent_lev1_price_note` varchar(300) DEFAULT NULL COMMENT '上级分佣备注',
  `agent_lev1_price_js` tinyint(1) DEFAULT '2' COMMENT '上级是否结算:1=是,2=否',
  `agent_lev2_uid` int(10) DEFAULT '0' COMMENT '上上级uid',
  `agent_lev2_percent` decimal(10,2) DEFAULT '0.00' COMMENT '上上级分佣百分比',
  `agent_lev2_price` decimal(10,2) DEFAULT '0.00' COMMENT '上上级分佣',
  `agent_lev2_price_note` varchar(300) DEFAULT NULL COMMENT '上上级分佣备注',
  `agent_lev2_price_js` tinyint(1) DEFAULT '2' COMMENT '上上级是否结算:1=是,2=否',
  `start_time` datetime DEFAULT NULL COMMENT '开始时间',
  `end_time` datetime DEFAULT NULL COMMENT '结束时间',
  `time_area` tinyint(1) DEFAULT '0' COMMENT '套餐时长:同card表',
  `num_left` int(10) DEFAULT '0' COMMENT '剩余次数',
  `num_total` int(10) DEFAULT '0' COMMENT '总次数',
  `price_yh_note` varchar(300) DEFAULT NULL COMMENT '优惠说明'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='套餐订单';

-- --------------------------------------------------------

--
-- 表的结构 `__PREFIX__deerhome_card_order_items`
--

CREATE TABLE `__PREFIX__deerhome_card_order_items` (
  `id` int(10) NOT NULL,
  `deerhome_card_order_id` int(10) NOT NULL COMMENT '套餐订单id',
  `deerhome_items_id` int(10) NOT NULL COMMENT '产品id',
  `deerhome_items_name` varchar(300) NOT NULL COMMENT '产品名称',
  `gg_name` varchar(300) NOT NULL COMMENT '规格产品名称',
  `gg_price` decimal(10,2) NOT NULL COMMENT '规格产品价格',
  `gg_dw` varchar(100) NOT NULL COMMENT '规格产品单位',
  `deerhome_items_gg_hash` varchar(100) NOT NULL COMMENT '产品规格标识',
  `price` decimal(10,2) NOT NULL COMMENT '套餐内售价',
  `num` int(10) NOT NULL COMMENT '数量',
  `num_left` int(10) NOT NULL COMMENT '剩余数量'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='套餐订单产品';

-- --------------------------------------------------------

--
-- 表的结构 `__PREFIX__deerhome_cate`
--

CREATE TABLE `__PREFIX__deerhome_cate` (
  `id` int(10) NOT NULL,
  `can_apply` tinyint(1) DEFAULT '1' COMMENT '是否支持入驻:1=是，2否',
  `home` tinyint(1) DEFAULT '2' COMMENT '首页展示:1=是,2否',
  `face_image` varchar(300) DEFAULT NULL COMMENT '封面图',
  `name` varchar(300) NOT NULL COMMENT '名称',
  `cate_id` int(10) DEFAULT '0' COMMENT '上级类目',
  `status` enum('1','2') DEFAULT '1' COMMENT '状态:1=正常,2=停用',
  `weigh` int(10) DEFAULT '100',
  `ad_image` varchar(300) DEFAULT NULL COMMENT '广告图',
  `ad_image_ac` varchar(300) DEFAULT NULL COMMENT '广告图事件',
  `createtime` bigint(16) DEFAULT '0' COMMENT '创建时间	',
  `updatetime` bigint(16) DEFAULT '0' COMMENT '更新时间'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='服务类目';

-- --------------------------------------------------------

--
-- 表的结构 `__PREFIX__deerhome_design`
--

CREATE TABLE `__PREFIX__deerhome_design` (
  `id` int(10) NOT NULL,
  `page_title` varchar(100) NOT NULL,
  `page` varchar(20) NOT NULL,
  `con` text NOT NULL,
  `weigh` int(10) NOT NULL,
  `update_time` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='页面设计';

--
-- 转存表中的数据 `__PREFIX__deerhome_design`
--

INSERT INTO `__PREFIX__deerhome_design` (`id`, `page_title`, `page`, `con`, `weigh`, `update_time`) VALUES
(1, '首页', 'home', '{\"tags\":[\"保洁\",\"家电清洗\",\"家电维修\",\"管道疏通\",\"家居维修\",\"家电安装\"],\"slide\":{\"img\":\"\\/assets\\/addons\\/deerhome\\/img\\/home_banner1.png,\\/assets\\/addons\\/deerhome\\/img\\/home_banner2.png\",\"json\":\"[{\\\"type\\\":\\\"item\\\",\\\"id\\\":\\\"35\\\",\\\"desc\\\":\\\"空调加氟\\\"},{\\\"type\\\":\\\"yhq\\\",\\\"id\\\":\\\"\\\",\\\"desc\\\":\\\"\\\"}]\"},\"block\":{\"show\":\"1\",\"title\":\"立即上门\",\"desc\":\"极速接单\",\"img\":\"\\/assets\\/addons\\/deerhome\\/img\\/icon_home.png,\\/assets\\/addons\\/deerhome\\/img\\/icon_bx.png,\\/assets\\/addons\\/deerhome\\/img\\/icon_gd.png,\\/assets\\/addons\\/deerhome\\/img\\/icon_dn.png\",\"json\":\"[{\\\"type\\\":\\\"item\\\",\\\"id\\\":\\\"46\\\",\\\"desc\\\":\\\"房屋维修\\\"},{\\\"type\\\":\\\"item\\\",\\\"id\\\":\\\"30\\\",\\\"desc\\\":\\\"家电维修\\\"},{\\\"type\\\":\\\"item\\\",\\\"id\\\":\\\"34\\\",\\\"desc\\\":\\\"管道疏通\\\"},{\\\"type\\\":\\\"item\\\",\\\"id\\\":\\\"110\\\",\\\"desc\\\":\\\"电脑维修\\\"}]\"},\"banner_center\":{\"img\":\"\\/assets\\/addons\\/deerhome\\/img\\/home_banner_c.png\",\"json\":\"[{\\\"type\\\":\\\"yhq\\\",\\\"id\\\":\\\"\\\",\\\"desc\\\":\\\"\\\"}]\"},\"banner_bottom\":{\"img\":\"\",\"json\":\"[]\"}}', 1, '2023-12-01 20:12:26'),
(2, '分类', 'cate', '', 2, '2023-07-07 12:11:54'),
(3, '免费领券', 'yhq', '{\"banner\":{\"img\":\"\\/assets\\/addons\\/deerhome\\/img\\/home_banner2.png\",\"json\":\"[{\\\"type\\\":\\\"no\\\",\\\"id\\\":\\\"\\\",\\\"desc\\\":\\\"\\\"}]\"}}', 3, '2023-08-01 20:51:46'),
(4, '技师入驻', 'apply', '{\"banner\":{\"img\":\"\\/assets\\/addons\\/deerhome\\/img\\/bg_apply.png\",\"json\":\"[{\\\"type\\\":\\\"no\\\",\\\"id\\\":\\\"\\\",\\\"desc\\\":\\\"\\\"}]\"}}', 4, '2023-07-11 16:36:47'),
(5, '常见问题', 'wenti', '{\"banner\":{\"img\":\"\\/assets\\/addons\\/deerhome\\/img\\/bg_kefu.png\",\"json\":\"[{\\\"type\\\":\\\"no\\\",\\\"id\\\":\\\"\\\",\\\"desc\\\":\\\"\\\"}]\"}}', 5, '2023-07-31 17:21:38');

-- --------------------------------------------------------

--
-- 表的结构 `__PREFIX__deerhome_fapiao`
--

CREATE TABLE `__PREFIX__deerhome_fapiao` (
  `id` int(10) NOT NULL,
  `jz_user_id` int(10) NOT NULL COMMENT '用户',
  `status` tinyint(1) DEFAULT '1' COMMENT '状态:1=待开票,2=已开票',
  `orders` varchar(500) NOT NULL COMMENT '关联订单',
  `price` decimal(10,2) NOT NULL COMMENT '开票金额',
  `type` tinyint(1) NOT NULL COMMENT '类型:1=个人,2=企业',
  `name` varchar(300) NOT NULL COMMENT '发票抬头',
  `code` varchar(60) DEFAULT NULL COMMENT '信用代码',
  `file` varchar(300) DEFAULT NULL COMMENT '下载地址',
  `add_time` datetime NOT NULL COMMENT '申请时间',
  `res_time` datetime DEFAULT NULL COMMENT '开票时间'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='发票管理';

-- --------------------------------------------------------

--
-- 表的结构 `__PREFIX__deerhome_items`
--

CREATE TABLE `__PREFIX__deerhome_items` (
  `id` int(10) NOT NULL,
  `cate_id` int(10) NOT NULL COMMENT '类目',
  `anget` tinyint(1) DEFAULT '2' COMMENT '参与分销:1=是,2=否',
  `anget_lev1` decimal(5,2) DEFAULT '0.00' COMMENT '上级分佣',
  `anget_lev2` decimal(5,2) DEFAULT '0.00' COMMENT '上上级分佣',
  `item_type` tinyint(1) DEFAULT '1' COMMENT '产品类型:1=服务,2=百货',
  `name` varchar(300) NOT NULL COMMENT '服务名称',
  `status` enum('1','2') DEFAULT '1' COMMENT '状态:1=正常,2=下架',
  `price` decimal(10,2) DEFAULT '0.00' COMMENT '售价',
  `dw` varchar(100) DEFAULT NULL COMMENT '单位',
  `face_image` varchar(300) DEFAULT NULL COMMENT '封面图',
  `img_images` varchar(600) DEFAULT NULL COMMENT '图片',
  `video_file` varchar(300) DEFAULT NULL COMMENT '视频',
  `video_face_image` varchar(300) DEFAULT NULL COMMENT '视频封面图',
  `createtime` bigint(16) DEFAULT NULL,
  `updatetime` bigint(16) DEFAULT NULL,
  `deletetime` bigint(16) DEFAULT NULL,
  `weigh` int(10) DEFAULT NULL COMMENT '排序',
  `note` text COMMENT '说明',
  `body_con` text COMMENT '图文详情',
  `worker_fc_bl` decimal(5,0) NOT NULL COMMENT '分成比例',
  `view_times` int(10) DEFAULT '0' COMMENT '浏览次数',
  `sale_times` int(10) DEFAULT '0' COMMENT '销量',
  `home` tinyint(1) DEFAULT '2' COMMENT '首页:1=是,2=否',
  `recommend` tinyint(1) DEFAULT '2' COMMENT '精选:1=是,2=否',
  `fake_sale_times` int(10) DEFAULT '0' COMMENT '基础销量'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='服务项目';

-- --------------------------------------------------------

--
-- 表的结构 `__PREFIX__deerhome_items_gg`
--

CREATE TABLE `__PREFIX__deerhome_items_gg` (
  `id` int(10) NOT NULL,
  `jz_items_id` int(10) NOT NULL,
  `name` varchar(300) NOT NULL COMMENT '名称',
  `price` decimal(10,2) NOT NULL COMMENT '售价',
  `dw` varchar(50) NOT NULL COMMENT '单位',
  `weigh` int(10) DEFAULT '100' COMMENT '排序',
  `hash` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='服务规格';

--
-- 表的结构 `__PREFIX__deerhome_msg`
--

CREATE TABLE `__PREFIX__deerhome_msg` (
  `id` int(10) NOT NULL,
  `utype` tinyint(1) NOT NULL COMMENT '类型:1=消费者,2=服务人员',
  `uid` int(10) NOT NULL COMMENT '接收人',
  `msg` varchar(600) NOT NULL COMMENT '消息内容',
  `is_read` tinyint(1) DEFAULT '2' COMMENT '已读:1=是,2=否',
  `msg_type` tinyint(2) NOT NULL COMMENT '已读:1=系统消息,2=服务信息',
  `send_time` datetime NOT NULL COMMENT '发送时间',
  `read_time` datetime DEFAULT NULL COMMENT '阅读时间'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='消息管理';

-- --------------------------------------------------------

--
-- 表的结构 `__PREFIX__deerhome_open_city`
--

CREATE TABLE `__PREFIX__deerhome_open_city` (
  `id` int(10) NOT NULL,
  `cityname` varchar(100) NOT NULL COMMENT '城市',
  `province` varchar(100) NOT NULL COMMENT '省份'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='开放城市';

--
-- 转存表中的数据 `__PREFIX__deerhome_open_city`
--

INSERT INTO `__PREFIX__deerhome_open_city` (`id`, `cityname`, `province`) VALUES
(5, '深圳市', '广东省'),
(6, '广州市', '广东省');

-- --------------------------------------------------------

--
-- 表的结构 `__PREFIX__deerhome_order`
--

CREATE TABLE `__PREFIX__deerhome_order` (
  `id` int(10) NOT NULL,
  `jz_user_id` int(10) NOT NULL COMMENT '用户id',
  `order_type` tinyint(1) DEFAULT '1' COMMENT '订单类型:1=服务订单',
  `is_card` tinyint(1) DEFAULT '2' COMMENT '使用次卡:1=是,2=否',
  `card_order_id` int(10) DEFAULT '0' COMMENT '次卡订单ID',
  `status` tinyint(1) DEFAULT '1' COMMENT '订单状态:1=待付款,2=待派单,3=待服务,4=待验收,5=已完成,6=退款中,7=已退款,8=已取消',
  `sn` varchar(20) NOT NULL COMMENT '订单编号',
  `jz_items_id` int(10) DEFAULT '0' COMMENT '产品id',
  `gg_id` varchar(32) NOT NULL COMMENT '服务hash',
  `item_name` varchar(300) NOT NULL COMMENT '服务项目',
  `item_gg_name` varchar(300) NOT NULL COMMENT '服务规格',
  `num` tinyint(2) NOT NULL COMMENT '服务数量',
  `price_item_total` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '服务金额',
  `price_bcj` decimal(10,2) DEFAULT '0.00' COMMENT '补差价',
  `price_total` decimal(10,2) NOT NULL COMMENT '订单总金额',
  `price_light` decimal(10,2) NOT NULL COMMENT '夜间交通费',
  `price_yh` decimal(10,2) NOT NULL COMMENT '优惠金额',
  `price_discount_bl` decimal(5,2) DEFAULT '1.00' COMMENT '会员折扣比例',
  `price_discount` decimal(10,2) DEFAULT '0.00' COMMENT '会员折后总价',
  `price_need_pay` decimal(10,2) NOT NULL COMMENT '应支付金额',
  `price_payed` decimal(10,2) DEFAULT '0.00' COMMENT '已支付金额',
  `price_pre_fc` decimal(10,2) DEFAULT '0.00' COMMENT '技师预计分成',
  `pay_way` varchar(60) DEFAULT NULL COMMENT '废弃：支付方式',
  `user_name` varchar(100) NOT NULL COMMENT '联系人姓名',
  `user_phone` varchar(11) NOT NULL COMMENT '手机号',
  `address_title` varchar(100) NOT NULL COMMENT '地址名称',
  `address_detail` varchar(200) NOT NULL COMMENT '门牌号',
  `address_address` varchar(300) NOT NULL COMMENT '详细地址',
  `latitude` varchar(50) NOT NULL,
  `longitude` varchar(50) NOT NULL,
  `date_day` date NOT NULL COMMENT '预约日期',
  `date_time` time NOT NULL COMMENT '预约时间',
  `note` varchar(600) NOT NULL COMMENT '备注',
  `imgs` varchar(600) DEFAULT NULL COMMENT '故障图片',
  `worker_id` int(10) DEFAULT '0' COMMENT '师傅id',
  `worker_get_time` datetime DEFAULT NULL COMMENT '师傅接单时间',
  `worker_apply_time` datetime DEFAULT NULL COMMENT '申请验收时间',
  `worker_last_price` decimal(10,2) DEFAULT '0.00' COMMENT '差价',
  `worker_imgs` varchar(600) DEFAULT NULL COMMENT '服务图片',
  `worker_note` varchar(600) DEFAULT NULL COMMENT '服务人员备注',
  `worker_name` varchar(100) DEFAULT NULL COMMENT '师傅姓名',
  `worker_price` decimal(10,2) DEFAULT '0.00' COMMENT '师傅分成',
  `worker_price_note` varchar(300) DEFAULT NULL COMMENT '分成说明',
  `worker_price_to_wallet` tinyint(1) DEFAULT '0' COMMENT '是否结算到师傅钱包',
  `worker_pj_star` tinyint(1) DEFAULT '0' COMMENT '师傅评价星级',
  `worker_pj_con` varchar(300) DEFAULT NULL COMMENT '评价内容',
  `worker_pj_con_images` varchar(500) DEFAULT NULL COMMENT '评价图片',
  `worker_pj_nm` tinyint(1) DEFAULT '0' COMMENT '1=匿名评价',
  `worker_pj_time` datetime DEFAULT NULL COMMENT '评价时间',
  `worker_pj_star_status` tinyint(1) DEFAULT '1' COMMENT '评价是否显示:1=显示,2=隐藏',
  `worker_pj_star_good` tinyint(1) DEFAULT '2' COMMENT '精选:1=是,2=否',
  `time_add` datetime NOT NULL COMMENT '添加时间',
  `time_payed` datetime DEFAULT NULL COMMENT '支付时间',
  `time_done` datetime DEFAULT NULL COMMENT '完成时间',
  `fapiao` tinyint(1) DEFAULT '0' COMMENT '发票批次',
  `agent_lev1_uid` int(10) DEFAULT '0' COMMENT '上级uid',
  `agent_lev1_percent` decimal(6,2) DEFAULT '0.00' COMMENT '分佣百分比',
  `agent_lev1_price` decimal(10,2) DEFAULT '0.00' COMMENT '上级分佣',
  `agent_lev1_price_note` varchar(300) DEFAULT NULL COMMENT '上级分佣备注',
  `agent_lev1_price_js` tinyint(1) DEFAULT '2' COMMENT '上级是否结算:1=是,2=否',
  `agent_lev2_uid` int(10) DEFAULT '0' COMMENT '上上级uid',
  `agent_lev2_percent` decimal(6,2) DEFAULT '0.00' COMMENT '分佣百分比',
  `agent_lev2_price` decimal(10,2) DEFAULT '0.00' COMMENT '上上级分佣',
  `agent_lev2_price_note` varchar(300) DEFAULT NULL COMMENT '上上级分佣备注',
  `agent_lev2_price_js` tinyint(1) DEFAULT '2' COMMENT '上上级是否结算:1=是,2=否',
  `jf_js` tinyint(1) DEFAULT '0' COMMENT '1已结算'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='订单表';

-- --------------------------------------------------------

--
-- 表的结构 `__PREFIX__deerhome_order_log`
--

CREATE TABLE `__PREFIX__deerhome_order_log` (
  `id` int(10) NOT NULL,
  `order_id` int(10) NOT NULL COMMENT '订单id',
  `ac_user` varchar(100) NOT NULL COMMENT '操作者',
  `note` varchar(300) NOT NULL COMMENT '内容',
  `add_time` datetime NOT NULL COMMENT '发生时间'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='订单日志';

-- --------------------------------------------------------

--
-- 表的结构 `__PREFIX__deerhome_order_pay_log`
--

CREATE TABLE `__PREFIX__deerhome_order_pay_log` (
  `id` int(10) NOT NULL,
  `deerhome_user_id` int(10) DEFAULT '0' COMMENT '用户id',
  `type` tinyint(1) DEFAULT '1' COMMENT '类型:1=服务订单,2=充值,3=次卡订单',
  `is_wallet` tinyint(1) DEFAULT '2' COMMENT '钱包资金:1=是,2=否',
  `is_card` tinyint(1) DEFAULT '2' COMMENT '使用次卡:1=是,2=否',
  `order_sn` varchar(50) DEFAULT NULL COMMENT '订单号',
  `status` tinyint(1) DEFAULT '1' COMMENT '状态:1=待支付,2=已支付,3=已取消',
  `price` decimal(10,2) NOT NULL COMMENT '金额',
  `give` decimal(10,2) DEFAULT '0.00' COMMENT '该笔交易是否需要赠款',
  `note` varchar(300) DEFAULT NULL COMMENT '备注',
  `payway_type` tinyint(1) DEFAULT NULL COMMENT '类型:1=线上支付,2=线下支付',
  `pay_way` varchar(100) DEFAULT NULL COMMENT '支付方式',
  `pay_time` datetime DEFAULT NULL COMMENT '支付时间',
  `add_time` datetime NOT NULL COMMENT '添加时间',
  `prepay_id` varchar(70) DEFAULT NULL COMMENT '微信支付prepay_id'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='支付日志';

-- --------------------------------------------------------

--
-- 表的结构 `__PREFIX__deerhome_order_refund`
--

CREATE TABLE `__PREFIX__deerhome_order_refund` (
  `id` int(11) NOT NULL,
  `status` tinyint(1) DEFAULT '1' COMMENT '状态:1=待处理,2=已退款,3=已拒绝',
  `jz_user_id` int(10) NOT NULL COMMENT '用户id',
  `order_sn` varchar(50) NOT NULL COMMENT '订单号',
  `lx` varchar(80) NOT NULL COMMENT '退款类型',
  `price` decimal(10,2) NOT NULL COMMENT '订单金额',
  `price_refund` decimal(10,2) NOT NULL COMMENT '退款金额',
  `note` varchar(600) NOT NULL COMMENT '退款原因',
  `addtime` datetime NOT NULL COMMENT '申请时间',
  `ac_admin` varchar(80) DEFAULT NULL COMMENT '处理人',
  `ac_admin_time` datetime DEFAULT NULL COMMENT '处理时间',
  `ac_admin_note` varchar(600) DEFAULT NULL COMMENT '审核人备注',
  `order_old_status` tinyint(1) DEFAULT '0' COMMENT '申请退款时订单状态'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='售后管理';

-- --------------------------------------------------------

--
-- 表的结构 `__PREFIX__deerhome_payway`
--

CREATE TABLE `__PREFIX__deerhome_payway` (
  `id` int(10) NOT NULL,
  `status` tinyint(1) NOT NULL COMMENT '状态:1=开启,2=停用',
  `name` varchar(100) NOT NULL COMMENT '支付名称'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='支付方式';

--
-- 转存表中的数据 `__PREFIX__deerhome_payway`
--

INSERT INTO `__PREFIX__deerhome_payway` (`id`, `status`, `name`) VALUES
(3, 1, '支付宝收款码'),
(8, 1, '微信收款码'),
(9, 1, '现金');

-- --------------------------------------------------------

--
-- 表的结构 `__PREFIX__deerhome_shop`
--

CREATE TABLE `__PREFIX__deerhome_shop` (
  `id` int(10) NOT NULL,
  `mdname` varchar(100) NOT NULL COMMENT '门店名称',
  `address` varchar(300) NOT NULL COMMENT '地址',
  `latitude` varchar(20) NOT NULL,
  `longitude` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='门店管理';


-- --------------------------------------------------------

--
-- 表的结构 `__PREFIX__deerhome_sys_charge`
--

CREATE TABLE `__PREFIX__deerhome_sys_charge` (
  `id` int(10) NOT NULL,
  `price` decimal(5,0) NOT NULL COMMENT '充值金额',
  `give` decimal(5,0) NOT NULL DEFAULT '0' COMMENT '赠款'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='充值配置';

--
-- 转存表中的数据 `__PREFIX__deerhome_sys_charge`
--

INSERT INTO `__PREFIX__deerhome_sys_charge` (`id`, `price`, `give`) VALUES
(1, '100', '0'),
(2, '200', '0');

-- --------------------------------------------------------

--
-- 表的结构 `__PREFIX__deerhome_tag`
--

CREATE TABLE `__PREFIX__deerhome_tag` (
  `id` int(10) NOT NULL,
  `name` varchar(100) NOT NULL COMMENT '标签名称'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='标签管理';

--
-- 转存表中的数据 `__PREFIX__deerhome_tag`
--

INSERT INTO `__PREFIX__deerhome_tag` (`id`, `name`) VALUES
(1, '热情服务');

-- --------------------------------------------------------

--
-- 表的结构 `__PREFIX__deerhome_user`
--

CREATE TABLE `__PREFIX__deerhome_user` (
  `id` int(10) NOT NULL,
  `user_lev_id` int(10) DEFAULT '0' COMMENT '会员等级',
  `jz_qd_id` int(10) DEFAULT '0' COMMENT '来源渠道',
  `face_image` varchar(300) DEFAULT NULL COMMENT '头像',
  `uname` varchar(100) DEFAULT NULL COMMENT '用户姓名',
  `utel` varchar(11) DEFAULT NULL COMMENT '手机号码',
  `note` varchar(300) DEFAULT NULL COMMENT '备注',
  `token` varchar(150) DEFAULT NULL,
  `wxid` varchar(200) DEFAULT NULL COMMENT '微信id',
  `regtime` datetime NOT NULL COMMENT '注册时间',
  `saas_hash` varchar(32) DEFAULT NULL COMMENT 'md5,utel',
  `last_time` datetime DEFAULT NULL COMMENT '最近打开',
  `agent_lev_id` int(10) DEFAULT '0' COMMENT '分销等级',
  `agent_lev1_uid` int(10) DEFAULT '0' COMMENT '上级id',
  `agent_lev2_uid` int(10) DEFAULT '0' COMMENT '上上级id',
  `wallet_left` decimal(10,2) DEFAULT '0.00' COMMENT '可用佣金',
  `wallet_tx` decimal(10,2) DEFAULT '0.00' COMMENT '已提现佣金',
  `agent` tinyint(1) DEFAULT '2' COMMENT '分销员:1=是,2=否',
  `agent_qr` varchar(300) DEFAULT NULL COMMENT '推广二维码',
  `wallet_charge` decimal(10,2) DEFAULT '0.00' COMMENT '充值余额',
  `jf` int(10) DEFAULT '0' COMMENT '积分'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='客户管理';

-- --------------------------------------------------------

--
-- 表的结构 `__PREFIX__deerhome_user_address`
--

CREATE TABLE `__PREFIX__deerhome_user_address` (
  `id` int(10) NOT NULL,
  `user_id` int(10) NOT NULL,
  `address` varchar(600) NOT NULL,
  `detail_address` varchar(300) NOT NULL,
  `lable_name` varchar(50) NOT NULL,
  `latitude` varchar(50) NOT NULL,
  `longitude` varchar(50) NOT NULL,
  `sex` enum('男','女','未知','') NOT NULL,
  `address_title` varchar(200) NOT NULL,
  `user_name` varchar(100) NOT NULL,
  `user_phone` varchar(11) NOT NULL,
  `is_default` tinyint(1) DEFAULT '0',
  `add_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='用户地址';

-- --------------------------------------------------------

--
-- 表的结构 `__PREFIX__deerhome_user_collected`
--

CREATE TABLE `__PREFIX__deerhome_user_collected` (
  `id` int(10) NOT NULL,
  `type` tinyint(1) DEFAULT '1' COMMENT '类型:1=收藏,2=足迹,3=页面',
  `jz_user_id` int(10) NOT NULL COMMENT '用户',
  `jz_items_id` int(10) DEFAULT '0' COMMENT '服务id',
  `note` varchar(200) DEFAULT NULL COMMENT '说明',
  `ip` varchar(30) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `province` varchar(100) DEFAULT NULL,
  `add_time` datetime NOT NULL COMMENT '操作时间'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户收藏';

-- --------------------------------------------------------

--
-- 表的结构 `__PREFIX__deerhome_user_jf_log`
--

CREATE TABLE `__PREFIX__deerhome_user_jf_log` (
  `id` int(10) NOT NULL,
  `deerhome_user_id` int(10) NOT NULL,
  `jf` int(10) NOT NULL,
  `order_sn` varchar(100) DEFAULT NULL COMMENT '关联订单',
  `note` varchar(600) DEFAULT NULL,
  `addtime` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户积分';

-- --------------------------------------------------------

--
-- 表的结构 `__PREFIX__deerhome_user_lev`
--

CREATE TABLE `__PREFIX__deerhome_user_lev` (
  `id` int(10) NOT NULL,
  `name` varchar(300) NOT NULL COMMENT '等级名称',
  `lev` int(2) NOT NULL COMMENT '等级权重',
  `discount` decimal(5,2) NOT NULL COMMENT '会员折扣比例',
  `task` text NOT NULL COMMENT '升级条件',
  `task_type` tinyint(1) DEFAULT '1' COMMENT '条件类型:1=全部满足,2=任意一个',
  `note` varchar(600) DEFAULT NULL COMMENT '描述',
  `bg_image` varchar(300) DEFAULT NULL COMMENT '背景图'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='会员等级';


-- --------------------------------------------------------

--
-- 表的结构 `__PREFIX__deerhome_worker`
--

CREATE TABLE `__PREFIX__deerhome_worker` (
  `id` int(10) NOT NULL,
  `status` tinyint(1) DEFAULT '1' COMMENT '状态:1=正常,2=停用',
  `type` tinyint(1) DEFAULT '1' COMMENT '类型:1=内部,2=入驻',
  `jz_shop_id` int(10) DEFAULT '0' COMMENT '所属门店',
  `jz_worker_lev_id` int(10) NOT NULL COMMENT '等级',
  `face_image` varchar(300) DEFAULT NULL COMMENT '头像',
  `uname` varchar(100) NOT NULL COMMENT '姓名',
  `utel` varchar(11) NOT NULL COMMENT '手机号',
  `times` int(5) DEFAULT '0' COMMENT '服务次数',
  `money_left` decimal(10,2) DEFAULT '0.00' COMMENT '可提现金额',
  `money_dj` decimal(10,2) DEFAULT '0.00' COMMENT '冻结金额',
  `money_tx` decimal(10,2) DEFAULT '0.00' COMMENT '累计提现',
  `jz_cate_ids` varchar(100) DEFAULT NULL COMMENT '服务类目',
  `jz_tag_ids` varchar(100) DEFAULT NULL COMMENT '标签',
  `sfz_a_image` varchar(150) DEFAULT NULL COMMENT '身份证正面',
  `sfz_b_image` varchar(150) DEFAULT NULL COMMENT '身份证反面',
  `zs_image` varchar(150) DEFAULT NULL COMMENT '技能证书',
  `address` varchar(200) DEFAULT NULL COMMENT '详细地址',
  `latitude` varchar(30) DEFAULT NULL,
  `longitude` varchar(30) DEFAULT NULL,
  `addtime` datetime NOT NULL COMMENT '添加时间',
  `token` varchar(100) DEFAULT NULL,
  `is_working` tinyint(1) DEFAULT '1' COMMENT '接单中:1=是,2=否',
  `wxid` varchar(100) DEFAULT NULL COMMENT '微信id'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='服务人员管理';

-- --------------------------------------------------------

--
-- 表的结构 `__PREFIX__deerhome_worker_card`
--

CREATE TABLE `__PREFIX__deerhome_worker_card` (
  `id` int(10) NOT NULL,
  `jz_worker_id` int(10) NOT NULL COMMENT '服务人员',
  `deerhome_user_id` int(10) DEFAULT '0' COMMENT '分销用户',
  `uname` varchar(100) NOT NULL COMMENT '收款人',
  `card` varchar(30) NOT NULL COMMENT '银行卡号',
  `bank` varchar(100) NOT NULL COMMENT '开户行',
  `add_time` datetime NOT NULL COMMENT '添加时间'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='银行卡管理';


-- --------------------------------------------------------

--
-- 表的结构 `__PREFIX__deerhome_worker_day`
--

CREATE TABLE `__PREFIX__deerhome_worker_day` (
  `id` int(10) NOT NULL,
  `jz_worker_id` int(10) NOT NULL,
  `day` date NOT NULL COMMENT '日期',
  `pb_rq` varchar(180) NOT NULL COMMENT '时间；0为全天'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='服务人员排班';


-- --------------------------------------------------------

--
-- 表的结构 `__PREFIX__deerhome_worker_lev`
--

CREATE TABLE `__PREFIX__deerhome_worker_lev` (
  `id` int(10) NOT NULL,
  `name` varchar(100) NOT NULL COMMENT '等级名称',
  `fybl` decimal(4,2) NOT NULL COMMENT '返佣比例'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='服务人员等级';

--
-- 转存表中的数据 `__PREFIX__deerhome_worker_lev`
--

INSERT INTO `__PREFIX__deerhome_worker_lev` (`id`, `name`, `fybl`) VALUES
(5, '默认', '0.00');

-- --------------------------------------------------------

--
-- 表的结构 `__PREFIX__deerhome_worker_money_log`
--

CREATE TABLE `__PREFIX__deerhome_worker_money_log` (
  `id` int(10) NOT NULL,
  `type` varchar(100) NOT NULL COMMENT '类型:分销分佣,服务分成,分销提现,服务提现',
  `status` tinyint(1) DEFAULT '1' COMMENT '状态:1=待处理,2=已处理,3=拒绝',
  `jz_worker_id` int(10) NOT NULL COMMENT '服务人员',
  `deerhome_user_id` int(10) DEFAULT '0' COMMENT '客户id',
  `jz_order_sn` varchar(100) DEFAULT NULL COMMENT '关联订单号',
  `price` decimal(10,2) NOT NULL COMMENT '金额',
  `note` varchar(300) NOT NULL COMMENT '备注',
  `skr` varchar(150) DEFAULT NULL COMMENT '收款人',
  `bank` varchar(100) DEFAULT NULL COMMENT '开户行',
  `bankcard` varchar(60) DEFAULT NULL COMMENT '银行卡',
  `sh_ren` varchar(100) DEFAULT NULL COMMENT '审核人',
  `addtime` datetime NOT NULL COMMENT '提交时间',
  `donetime` datetime DEFAULT NULL COMMENT '处理时间'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='资金明细';

-- --------------------------------------------------------

--
-- 表的结构 `__PREFIX__deerhome_worker_sh`
--

CREATE TABLE `__PREFIX__deerhome_worker_sh` (
  `id` int(10) NOT NULL,
  `jz_user_id` int(10) DEFAULT '0' COMMENT '用户id',
  `status` tinyint(1) DEFAULT '1' COMMENT '状态:1=待审核,2=通过,3=拒绝',
  `face_image` varchar(100) DEFAULT NULL COMMENT '头像',
  `uname` varchar(100) NOT NULL COMMENT '姓名',
  `utel` varchar(11) NOT NULL COMMENT '手机号码',
  `idcard` varchar(50) NOT NULL COMMENT '身份证号',
  `jz_worker_lev_id` varchar(100) DEFAULT '0' COMMENT '等级',
  `jz_cate_ids` varchar(100) DEFAULT NULL COMMENT '服务类目',
  `jz_tag_ids` varchar(100) DEFAULT NULL COMMENT '标签',
  `sfz_a_image` varchar(150) NOT NULL COMMENT '身份证正面',
  `sfz_b_image` varchar(150) NOT NULL COMMENT '身份证反面',
  `zs_image` varchar(300) DEFAULT NULL COMMENT '技能证书',
  `note` varchar(300) DEFAULT NULL COMMENT '申请说明',
  `city` varchar(100) DEFAULT NULL COMMENT '城市',
  `address_title` varchar(300) NOT NULL COMMENT '地址名称',
  `address` varchar(300) DEFAULT NULL COMMENT '详细地址',
  `latitude` varchar(30) DEFAULT NULL,
  `longitude` varchar(30) DEFAULT NULL,
  `add_time` datetime NOT NULL COMMENT '提交时间',
  `sh_ren` varchar(100) DEFAULT NULL COMMENT '审核人',
  `sh_con` varchar(500) DEFAULT NULL COMMENT '审核意见',
  `sh_time` datetime DEFAULT NULL COMMENT '审核时间',
  `wx_id` varchar(300) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='服务人员审核';

-- --------------------------------------------------------

--
-- 表的结构 `__PREFIX__deerhome_xcxmsg`
--

CREATE TABLE `__PREFIX__deerhome_xcxmsg` (
  `id` int(10) NOT NULL,
  `title` varchar(300) NOT NULL COMMENT '模板标题',
  `tid` varchar(300) NOT NULL COMMENT '模板ID',
  `keyword` varchar(600) NOT NULL COMMENT '关键词',
  `kidListDesc` varchar(300) NOT NULL COMMENT '关键词',
  `pushed` tinyint(1) DEFAULT '2' COMMENT '是否推送到微信后台：1是，2否',
  `tplid` varchar(100) DEFAULT NULL COMMENT '微信模板id'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='小程序订阅消息';

--
-- 转存表中的数据 `__PREFIX__deerhome_xcxmsg`
--

INSERT INTO `__PREFIX__deerhome_xcxmsg` (`id`, `title`, `tid`, `keyword`, `kidListDesc`, `pushed`, `tplid`) VALUES
(1, '新订单通知', '1022', '3,4,10,5,9', '订单编号,服务内容,订单金额,预约时间,备注', 2, NULL),
(2, '提现审核通知', '7142', '1,2,3', '审核结果,提现金额,温馨提示', 2, NULL),
(3, '订单取消通知', '1023', '3,4,5,6', '订单编号,订单状态,服务内容,取消理由', 2, NULL),
(4, '服务人员变更通知', '2236', '7,6,4', '服务项目,服务时间,变更后服务人员', 2, NULL),
(5, '审核未通过提醒', '2626', '7,6,8', '审核状态,申请内容,备注', 2, NULL),
(6, '审核通过提醒', '2631', '6,5', '审核结果,申请内容', 2, NULL),
(7, '上门时间变更通知', '748', '7,3,4,8', '服务名称,原上门时间,变更后时间,备注', 2, NULL),
(8, '服务派单通知', '2411', '2,3,4,8,12', '服务项目,服务信息,服务时间,服务人员,备注', 2, NULL);

-- --------------------------------------------------------

--
-- 表的结构 `__PREFIX__deerhome_xcxpz`
--

CREATE TABLE `__PREFIX__deerhome_xcxpz` (
  `id` int(10) NOT NULL,
  `platform` varchar(30) NOT NULL COMMENT '标识',
  `con` text NOT NULL COMMENT '配置',
  `note` varchar(100) DEFAULT NULL COMMENT '说明',
  `update_time` datetime NOT NULL COMMENT '更新时间'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='系统配置';

--
-- 转存表中的数据 `__PREFIX__deerhome_xcxpz`
--

INSERT INTO `__PREFIX__deerhome_xcxpz` (`id`, `platform`, `con`, `note`, `update_time`) VALUES
(1, 'xcx_config', '{\"appid\":\"\",\"appsecret\":\"\",\"mch_id\":\"\",\"mch_v3_key\":\"\",\"cert_public\":\"\",\"cert_private\":\"\"}', '小程序配置', '2023-07-11 18:44:20'),
(4, 'sys', '{\"xcxtitle\":\"宇鹿家政\",\"login_logo\":\"\\/assets\\/addons\\/deerhome\\/img\\/logo.png\",\"jtf\":\"10\",\"time_start\":\"08:30\",\"time_end\":\"21:30\",\"item_bz\":\"准时上门,未服务全额退,闪电退款\",\"user_cj\":\"on\",\"worker_cj\":\"on\"}', '系统基础配置', '2023-08-18 19:42:09'),
(8, 'agent', '{\"on\":\"on\",\"fxms\":\"1\",\"lev\":\"2\",\"zgfy\":\"off\",\"hb\":\"\\/assets\\/addons\\/deerhome\\/img\\/qr_bg1.jpeg\",\"tx\":\"10\"}', '分销设置', '2023-09-08 12:53:40');

-- --------------------------------------------------------

--
-- 表的结构 `__PREFIX__deerhome_yhq`
--

CREATE TABLE `__PREFIX__deerhome_yhq` (
  `id` int(10) NOT NULL,
  `status` tinyint(1) DEFAULT '1' COMMENT '状态:1=待领取,2=已领取,3=已消费,4=已过期',
  `name` varchar(300) NOT NULL COMMENT '名称',
  `type` tinyint(1) DEFAULT '1' COMMENT '类型:1=满减券',
  `jz_cate_ids` varchar(100) NOT NULL COMMENT '使用范围',
  `money_lev` decimal(10,2) NOT NULL COMMENT '消费满金额',
  `money_yh` decimal(10,2) NOT NULL COMMENT '减免金额',
  `start_day` date NOT NULL COMMENT '有效日期',
  `end_day` date NOT NULL COMMENT '失效日期',
  `code` varchar(30) NOT NULL COMMENT '券码',
  `addtime` datetime NOT NULL COMMENT '创建时间',
  `jz_user_id` int(10) DEFAULT '0' COMMENT '领取用户',
  `order_sn` varchar(20) DEFAULT NULL COMMENT '消费订单号',
  `get_time` datetime DEFAULT NULL COMMENT '领取时间',
  `use_time` datetime DEFAULT NULL COMMENT '消费时间'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='优惠券';
--
-- 转储表的索引
--

--
-- 表的索引 `__PREFIX__deerhome_agent_lev`
--
ALTER TABLE `__PREFIX__deerhome_agent_lev`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `__PREFIX__deerhome_article`
--
ALTER TABLE `__PREFIX__deerhome_article`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `__PREFIX__deerhome_bank`
--
ALTER TABLE `__PREFIX__deerhome_bank`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `__PREFIX__deerhome_card`
--
ALTER TABLE `__PREFIX__deerhome_card`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `__PREFIX__deerhome_card_items`
--
ALTER TABLE `__PREFIX__deerhome_card_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `deerhome_card_id` (`deerhome_card_id`),
  ADD KEY `deerhome_items_gg_id` (`deerhome_items_gg_hash`);

--
-- 表的索引 `__PREFIX__deerhome_card_order`
--
ALTER TABLE `__PREFIX__deerhome_card_order`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `sn` (`sn`),
  ADD KEY `deerhome_user_id` (`deerhome_user_id`),
  ADD KEY `status` (`status`),
  ADD KEY `deerhome_card_id` (`deerhome_card_id`);

--
-- 表的索引 `__PREFIX__deerhome_card_order_items`
--
ALTER TABLE `__PREFIX__deerhome_card_order_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `deerhome_card_order_id` (`deerhome_card_order_id`);

--
-- 表的索引 `__PREFIX__deerhome_cate`
--
ALTER TABLE `__PREFIX__deerhome_cate`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `__PREFIX__deerhome_design`
--
ALTER TABLE `__PREFIX__deerhome_design`
  ADD PRIMARY KEY (`id`);


--
-- 表的索引 `__PREFIX__deerhome_fapiao`
--
ALTER TABLE `__PREFIX__deerhome_fapiao`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `__PREFIX__deerhome_items`
--
ALTER TABLE `__PREFIX__deerhome_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `cate_id` (`cate_id`);

--
-- 表的索引 `__PREFIX__deerhome_items_gg`
--
ALTER TABLE `__PREFIX__deerhome_items_gg`
  ADD PRIMARY KEY (`id`),
  ADD KEY `items_id` (`jz_items_id`);

--
-- 表的索引 `__PREFIX__deerhome_msg`
--
ALTER TABLE `__PREFIX__deerhome_msg`
  ADD PRIMARY KEY (`id`),
  ADD KEY `utype` (`utype`),
  ADD KEY `msg_type` (`msg_type`);

--
-- 表的索引 `__PREFIX__deerhome_open_city`
--
ALTER TABLE `__PREFIX__deerhome_open_city`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `__PREFIX__deerhome_order`
--
ALTER TABLE `__PREFIX__deerhome_order`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `sn` (`sn`),
  ADD KEY `status` (`status`),
  ADD KEY `gg_id` (`gg_id`),
  ADD KEY `worker_id` (`worker_id`);

--
-- 表的索引 `__PREFIX__deerhome_order_log`
--
ALTER TABLE `__PREFIX__deerhome_order_log`
  ADD PRIMARY KEY (`id`),
  ADD KEY `order_id` (`order_id`);

--
-- 表的索引 `__PREFIX__deerhome_order_pay_log`
--
ALTER TABLE `__PREFIX__deerhome_order_pay_log`
  ADD PRIMARY KEY (`id`),
  ADD KEY `type` (`type`),
  ADD KEY `deerhome_user_id` (`deerhome_user_id`);

--
-- 表的索引 `__PREFIX__deerhome_order_refund`
--
ALTER TABLE `__PREFIX__deerhome_order_refund`
  ADD PRIMARY KEY (`id`),
  ADD KEY `uid` (`jz_user_id`);

--
-- 表的索引 `__PREFIX__deerhome_payway`
--
ALTER TABLE `__PREFIX__deerhome_payway`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `__PREFIX__deerhome_shop`
--
ALTER TABLE `__PREFIX__deerhome_shop`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `__PREFIX__deerhome_sys_charge`
--
ALTER TABLE `__PREFIX__deerhome_sys_charge`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `__PREFIX__deerhome_tag`
--
ALTER TABLE `__PREFIX__deerhome_tag`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `__PREFIX__deerhome_user`
--
ALTER TABLE `__PREFIX__deerhome_user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `saas_hash` (`saas_hash`),
  ADD UNIQUE KEY `token` (`token`),
  ADD KEY `user_lev_id` (`user_lev_id`);

--
-- 表的索引 `__PREFIX__deerhome_user_address`
--
ALTER TABLE `__PREFIX__deerhome_user_address`
  ADD PRIMARY KEY (`id`),
  ADD KEY `uid` (`user_id`);

--
-- 表的索引 `__PREFIX__deerhome_user_collected`
--
ALTER TABLE `__PREFIX__deerhome_user_collected`
  ADD PRIMARY KEY (`id`),
  ADD KEY `type` (`type`);

--
-- 表的索引 `__PREFIX__deerhome_user_jf_log`
--
ALTER TABLE `__PREFIX__deerhome_user_jf_log`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `__PREFIX__deerhome_user_lev`
--
ALTER TABLE `__PREFIX__deerhome_user_lev`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `__PREFIX__deerhome_worker`
--
ALTER TABLE `__PREFIX__deerhome_worker`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `token` (`token`);

--
-- 表的索引 `__PREFIX__deerhome_worker_card`
--
ALTER TABLE `__PREFIX__deerhome_worker_card`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `__PREFIX__deerhome_worker_day`
--
ALTER TABLE `__PREFIX__deerhome_worker_day`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `__PREFIX__deerhome_worker_lev`
--
ALTER TABLE `__PREFIX__deerhome_worker_lev`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `__PREFIX__deerhome_worker_money_log`
--
ALTER TABLE `__PREFIX__deerhome_worker_money_log`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `__PREFIX__deerhome_worker_sh`
--
ALTER TABLE `__PREFIX__deerhome_worker_sh`
  ADD PRIMARY KEY (`id`),
  ADD KEY `jz_user_id` (`jz_user_id`);

--
-- 表的索引 `__PREFIX__deerhome_xcxmsg`
--
ALTER TABLE `__PREFIX__deerhome_xcxmsg`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `__PREFIX__deerhome_xcxpz`
--
ALTER TABLE `__PREFIX__deerhome_xcxpz`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `__PREFIX__deerhome_yhq`
--
ALTER TABLE `__PREFIX__deerhome_yhq`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `code` (`code`),
  ADD KEY `jz_user_id` (`jz_user_id`);

--
-- 在导出的表使用AUTO_INCREMENT
--

--
-- 使用表AUTO_INCREMENT `__PREFIX__deerhome_agent_lev`
--
ALTER TABLE `__PREFIX__deerhome_agent_lev`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- 使用表AUTO_INCREMENT `__PREFIX__deerhome_article`
--
ALTER TABLE `__PREFIX__deerhome_article`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- 使用表AUTO_INCREMENT `__PREFIX__deerhome_bank`
--
ALTER TABLE `__PREFIX__deerhome_bank`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- 使用表AUTO_INCREMENT `__PREFIX__deerhome_card`
--
ALTER TABLE `__PREFIX__deerhome_card`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `__PREFIX__deerhome_card_items`
--
ALTER TABLE `__PREFIX__deerhome_card_items`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `__PREFIX__deerhome_card_order`
--
ALTER TABLE `__PREFIX__deerhome_card_order`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `__PREFIX__deerhome_card_order_items`
--
ALTER TABLE `__PREFIX__deerhome_card_order_items`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `__PREFIX__deerhome_cate`
--
ALTER TABLE `__PREFIX__deerhome_cate`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `__PREFIX__deerhome_design`
--
ALTER TABLE `__PREFIX__deerhome_design`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=78;

--
-- 使用表AUTO_INCREMENT `__PREFIX__deerhome_fapiao`
--
ALTER TABLE `__PREFIX__deerhome_fapiao`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `__PREFIX__deerhome_items`
--
ALTER TABLE `__PREFIX__deerhome_items`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `__PREFIX__deerhome_items_gg`
--
ALTER TABLE `__PREFIX__deerhome_items_gg`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `__PREFIX__deerhome_msg`
--
ALTER TABLE `__PREFIX__deerhome_msg`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `__PREFIX__deerhome_open_city`
--
ALTER TABLE `__PREFIX__deerhome_open_city`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- 使用表AUTO_INCREMENT `__PREFIX__deerhome_order`
--
ALTER TABLE `__PREFIX__deerhome_order`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `__PREFIX__deerhome_order_log`
--
ALTER TABLE `__PREFIX__deerhome_order_log`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `__PREFIX__deerhome_order_pay_log`
--
ALTER TABLE `__PREFIX__deerhome_order_pay_log`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `__PREFIX__deerhome_order_refund`
--
ALTER TABLE `__PREFIX__deerhome_order_refund`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `__PREFIX__deerhome_payway`
--
ALTER TABLE `__PREFIX__deerhome_payway`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- 使用表AUTO_INCREMENT `__PREFIX__deerhome_shop`
--
ALTER TABLE `__PREFIX__deerhome_shop`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `__PREFIX__deerhome_sys_charge`
--
ALTER TABLE `__PREFIX__deerhome_sys_charge`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- 使用表AUTO_INCREMENT `__PREFIX__deerhome_tag`
--
ALTER TABLE `__PREFIX__deerhome_tag`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- 使用表AUTO_INCREMENT `__PREFIX__deerhome_user`
--
ALTER TABLE `__PREFIX__deerhome_user`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `__PREFIX__deerhome_user_address`
--
ALTER TABLE `__PREFIX__deerhome_user_address`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `__PREFIX__deerhome_user_collected`
--
ALTER TABLE `__PREFIX__deerhome_user_collected`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `__PREFIX__deerhome_user_jf_log`
--
ALTER TABLE `__PREFIX__deerhome_user_jf_log`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `__PREFIX__deerhome_user_lev`
--
ALTER TABLE `__PREFIX__deerhome_user_lev`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- 使用表AUTO_INCREMENT `__PREFIX__deerhome_worker`
--
ALTER TABLE `__PREFIX__deerhome_worker`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `__PREFIX__deerhome_worker_card`
--
ALTER TABLE `__PREFIX__deerhome_worker_card`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `__PREFIX__deerhome_worker_day`
--
ALTER TABLE `__PREFIX__deerhome_worker_day`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `__PREFIX__deerhome_worker_lev`
--
ALTER TABLE `__PREFIX__deerhome_worker_lev`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- 使用表AUTO_INCREMENT `__PREFIX__deerhome_worker_money_log`
--
ALTER TABLE `__PREFIX__deerhome_worker_money_log`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `__PREFIX__deerhome_worker_sh`
--
ALTER TABLE `__PREFIX__deerhome_worker_sh`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `__PREFIX__deerhome_xcxmsg`
--
ALTER TABLE `__PREFIX__deerhome_xcxmsg`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- 使用表AUTO_INCREMENT `__PREFIX__deerhome_xcxpz`
--
ALTER TABLE `__PREFIX__deerhome_xcxpz`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- 使用表AUTO_INCREMENT `__PREFIX__deerhome_yhq`
--
ALTER TABLE `__PREFIX__deerhome_yhq`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;

--
-- 旧版升级
--
ALTER TABLE `__PREFIX__deerhome_order`
CHANGE `order_type` `order_type` TINYINT(1) NULL DEFAULT '1' COMMENT '订单类型:1=服务订单'
,CHANGE `jz_items_id` `jz_items_id` INT(10) NULL DEFAULT '0' COMMENT '产品id'
,ADD `is_card` TINYINT(1) DEFAULT '2' COMMENT '使用次卡:1=是,2=否' AFTER `order_type`
,ADD `card_order_id` INT(10) DEFAULT '0' COMMENT '次卡订单ID' AFTER `is_card`;

ALTER TABLE `__PREFIX__deerhome_order_pay_log`
CHANGE `type` `type` TINYINT(1) NULL DEFAULT '1' COMMENT '类型:1=服务订单,2=充值,3=次卡订单'
,ADD `is_card` TINYINT(1) DEFAULT '2' COMMENT '使用次卡:1=是,2=否' AFTER `is_wallet`;


COMMIT;
