<?php
return [
    [
        'name'    => '__tips__',
        'title'    => '温馨提示',
        'type'    => 'string',
        'value'   => 'IP转城市，阿里云市场API：https://market.aliyun.com/products/57002003/cmapi021970.html',
        'tip'     => '',
        'extend'  => '',
        'rule'    => '',
    ],
    [
        'name'    => 'ip2city',
        'title'    => 'IP转城市密钥',
        'type'    => 'string',
        'value'   => '7a71919f24764ddaa9c1c3670b04df79',
        'tip'     => '不配置小程序端则不显示城市',
        'extend'  => '',
        'rule'    => '',
    ],
    [
        'name'    => 'mapkey',
        'title'    => '腾讯地图Key',
        'type'    => 'string',
        'value'   => 'SOBBZ-PSJ6X-TRS4I-ZLLJ5-K7ZA2-66FN5',
        'tip'  => '不配置后台订单详情则不显示地图',
        'extend'  => '',
        'rule'    => '',
    ]
];
