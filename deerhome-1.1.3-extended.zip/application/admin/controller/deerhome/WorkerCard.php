<?php

namespace app\admin\controller\deerhome;

use app\common\controller\Backend;

/**
 * 银行卡管理
 *
 * @icon fa fa-circle-o
 */
class WorkerCard extends Backend
{

    /**
     * WorkerCard模型对象
     * @var \app\admin\model\deerhome\WorkerCard
     */
    protected $model = null;
    protected $searchFields = 'uname';
    protected $relationSearch = true;

    public function _initialize()
    {
        parent::_initialize();
        $this->model = new \app\admin\model\deerhome\WorkerCard;

    }


    public function index()
    {
        if (!$this->request->isAjax())
        {
            return $this->view->fetch();
        }
        $filter = json_decode($this->request->get("filter"),true);
        $op = json_decode($this->request->get("op"),true);
        $key="";
        if(isset($filter['key'])){
            $key=$filter['key'];
            unset($filter['key'],$op['key']);
            $this->request->get(["filter"=>json_encode($filter),'op'=>json_encode($op)]);
        }
        list($where, $sort, $order, $offset, $limit) = $this->buildparams();
        
        $where2=[];
        if($key!=""){
            $where2["worker.uname|user.uname"]=["like","%{$key}%"];
        }
        $list = $this->model
                ->with(["worker","user"])
                ->where($where)
                ->where($where2)
                ->order($sort, $order)
                ->paginate($limit);
        $result = ['total' => $list->total(), 'rows' => $list->items()];

        return json($result);
    }
    /**
     * 默认生成的控制器所继承的父类中有index/add/edit/del/multi五个基础方法、destroy/restore/recyclebin三个回收站方法
     * 因此在当前控制器中可不用编写增删改查的代码,除非需要自己控制这部分逻辑
     * 需要将application/admin/library/traits/Backend.php中对应的方法复制到当前控制器,然后进行修改
     */


}
