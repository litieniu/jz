<?php

namespace app\admin\controller\deerhome;

use app\common\controller\Backend;
use think\Db;
use Exception;
use think\exception\PDOException;
use think\exception\ValidateException;
/**
 * 分销订单
 *
 * @icon fa fa-circle-o
 */
class AgentOrder extends Backend
{

    protected $model = null;
    protected $searchFields = 'sn';

    /**
     * 查看
     *
     * @return string|Json
     * @throws \think\Exception
     * @throws DbException
     */
    public function index()
    {
        if (false === $this->request->isAjax()) {
            return $this->view->fetch();
        }
        $where=[];
        $where['o.status']=['in',[2,3,4,5]];
        $where['o.agent_lev1_uid|o.agent_lev2_uid']=['>',0];
        $list=Db::name("deerhome_order")
        ->alias('o')
        ->join('deerhome_user u','o.jz_user_id=u.id','left')
        ->join('deerhome_user u1','o.agent_lev1_uid=u1.id','left')
        ->join('deerhome_user u2','o.agent_lev2_uid=u2.id','left')
        ->field("o.id,o.sn,o.status,o.price_payed
        ,o.price_payed
        ,o.jz_user_id
        ,o.agent_lev1_uid
        ,o.agent_lev1_price
        ,o.agent_lev1_price_note
        ,o.agent_lev2_uid
        ,o.agent_lev2_price
        ,o.agent_lev2_price_note
        ,u.uname,u1.uname as lev1_name,u2.uname as lev2_name")
        ->where($where)->order('o.id desc')->paginate(10);
        
        $result = ['total' => $list->total(), 'rows' => $list->items()];
        return json($result);
    }

   
}
