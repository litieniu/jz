<?php

namespace app\admin\controller\deerhome;

use app\common\controller\Backend;

/**
 * 服务人员排班
 *
 * @icon fa fa-circle-o
 */
class WorkerDay extends Backend
{

    /**
     * WorkerDay模型对象
     * @var \app\admin\model\deerhome\WorkerDay
     */
    protected $model = null;

    public function _initialize()
    {
        parent::_initialize();
        $this->model = new \app\admin\model\deerhome\WorkerDay;

    }

    public function add()
    {
        if (false === $this->request->isPost()) {
            $id=$this->request->param("jz_worker_id");
            $this->assign("id", $id);
            $dayTimes=[];
            //从8点开始到22点，每隔半个小时生成一个元素
            for($i=8;$i<=22;$i++){
                $time1=str_pad($i,2,"0",STR_PAD_LEFT).":00";
                $time2=str_pad($i,2,"0",STR_PAD_LEFT).":30";
                //c=1表示已经约满
                $dayTimes[]=$time1;
                $dayTimes[]=$time2;
            }
            $this->assign("dayTimes", $dayTimes);
            return $this->view->fetch();
        }
        parent::add();
   }
}
