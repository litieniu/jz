<?php

namespace app\admin\controller\deerhome;

use app\common\controller\Backend;
use think\Db;
use Exception;
use think\exception\PDOException;
use think\exception\ValidateException;
/**
 * 小程序配置
 *
 * @icon fa fa-circle-o
 */
class Xcxpz extends Backend
{

    /**
     * Evaluate模型对象
     * @var \app\admin\model\deerhome\Xcxpz
     */
    protected $model = null;

    public function _initialize()
    {
        parent::_initialize();
        $this->model = new \app\admin\model\deerhome\Xcxpz;

    }
    /**
     * 小程序授权
    */
    public function sq()
    {
        $pageData=$this->model->where('platform',"xcx_config")->find();
        if(!$pageData){
            die('<div style="margin:10px;">没有小程序配置信息</div>');
        }
        $pageData=\json_decode($pageData['con'],true);
        if (!$this->request->isAjax())
        {
            $this->assign("appid", $pageData['appid']);
            return $this->view->fetch();
        }
        $this->success();
    }
    public function index()
    {
        $pageData=$this->model->where('platform',"xcx_config")->find();
        if(!$pageData){
            die('<div style="margin:10px;">没有小程序配置信息</div>');
        }
        $pageData=\json_decode($pageData['con'],true);
        if(!isset($pageData['auto_cert'])){
            $pageData['auto_cert']=1;
        }
        if(!isset($pageData['mp_cert_serial'])){
            $pageData['mp_cert_serial']="";
        }
        if(!isset($pageData['mp_cert_content'])){
            $pageData['mp_cert_content']="";
        }
        if (!$this->request->isAjax())
        {
            $pageData['appsecret']=$pageData['appsecret'] ? \substr_replace($pageData['appsecret'],'********',3,-3):'';
            $pageData['mch_v3_key']=$pageData['mch_v3_key'] ? \substr_replace($pageData['mch_v3_key'],'********',3,-3):'';
            $pageData['cert_public']=$pageData['cert_public'] ? \substr_replace($pageData['cert_public'],'****************',50,-40):'';
            $pageData['cert_private']=$pageData['cert_private'] ? \substr_replace($pageData['cert_private'],'****************',50,-40):'';
            $pageData['auto_cert']= isset($pageData['auto_cert']) ?$pageData['auto_cert']:1 ;
            $pageData['mp_cert_serial']=isset($pageData['mp_cert_serial']) ? \substr_replace($pageData['mp_cert_serial'],'********',10,-3):'';
            $pageData['mp_cert_content']=isset($pageData['mp_cert_content']) ? \substr_replace($pageData['mp_cert_content'],'****************',50,-40):'';
            $this->assign("pageData", $pageData);
            return $this->view->fetch();
        }
        $platform=$this->request->param('platform','');
        $row=$this->request->param('row/a',[]);
        if($platform==""){
            $this->error("不支持的操作");
        }
        foreach ($row as $key => &$value) {
            $value=\trim($value);
            if(\strstr($value,'*')){
                $row[$key]=$pageData[$key];
            }
        }
        $update=$pageData;
        foreach($update as $k=>&$v){
            if(isset($row[$k])){
                $v=$row[$k];
            }
        }
        
        $edit=[];
        $edit['con']=\json_encode($update,JSON_UNESCAPED_UNICODE);
        $this->model->where('platform',$platform)->update($edit);
        $this->success();
    }


}
