<?php

namespace app\admin\controller\deerhome;

use app\common\controller\Backend;
use think\Db;
use Exception;
use think\exception\PDOException;
use think\exception\ValidateException;
/**
 * 基本配置
 *
 * @icon fa fa-circle-o
 */
class Sys extends Backend
{

    /**
     * Evaluate模型对象
     * @var \app\admin\model\deerhome\Xcxpz
     */
    protected $model = null;

    public function _initialize()
    {
        parent::_initialize();
        $this->model = new \app\admin\model\deerhome\Xcxpz;

    }
    public function index()
    {
        $pageData=$this->model->where('platform',"sys")->find();
        if(!$pageData){
            die('<div style="margin:10px;">没有小程序配置信息</div>');
        }
        $pageData=\json_decode($pageData['con'],true);
        if (!$this->request->isAjax())
        {
            $this->assign("pageData", $pageData);
            return $this->view->fetch();
        }
        $platform=$this->request->param('platform','');
        $row=$this->request->param('row/a',[]);
        if($platform==""){
            $this->error("不支持的操作");
        }
        foreach ($row as $key => &$value) {
            if($value==""){
                $this->error("{$key}不能为空！");
            }
            $value=\trim($value);
            $value=\str_ireplace("，",",",$value);
        }
        $edit=[];
        $edit['con']=\json_encode($row,JSON_UNESCAPED_UNICODE);
        $this->model->where('platform',$platform)->update($edit);
        $this->success();
    }


}
