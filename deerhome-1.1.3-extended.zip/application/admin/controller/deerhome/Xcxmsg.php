<?php

namespace app\admin\controller\deerhome;

use app\common\controller\Backend;
use think\Db;
/**
 * 小程序订阅消息
 *
 * @icon fa fa-circle-o
 */
class Xcxmsg extends Backend
{

    /**
     * Xcxmsg模型对象
     * @var \app\admin\model\deerhome\Xcxmsg
     */
    protected $model = null;

    public function _initialize()
    {
        parent::_initialize();
        $this->model = new \app\admin\model\deerhome\Xcxmsg;
        $this->view->assign("typeList", $this->model->getTypeList());
    }

    /**
     * 推送到微信
    */
    public function push_to_wx(){
        $id=$this->request->param("id");
        $title=$this->request->param("title");
        $tid=$this->request->param("tid");
        $kidList=$this->request->param("kidList");
        $kidList=explode(",",$kidList);
        if(count($kidList)>5 || count($kidList)<2){
            $this->error("关键词只能是2-5个");
        }
        $config=Db::name("deerhome_xcxpz")->where("platform","xcx_config")->find();
        if(!$config){
            $this->err("请先配置微信小程序appid等参数");
        }
        $config=\json_decode($config['con'],true);
        $res=[];
        try{
            $mini = \WeMini\Newtmpl::instance($config);
            $res=$mini->addTemplate($tid,$kidList,$title);
            if(!isset($res['priTmplId'])){
                throw new \Exception($res['errmsg']);
            }
            Db::name("deerhome_xcxmsg")->where("id",$id)->update(
                [
                    "pushed"=>1
                    ,"tplid"=>$res['priTmplId']
                ]
            );
        }catch(\Exception $e){
            $this->error($e->getMessage());
        }
        $this->success('ok',null,$res);
    }


    /**
     * 默认生成的控制器所继承的父类中有index/add/edit/del/multi五个基础方法、destroy/restore/recyclebin三个回收站方法
     * 因此在当前控制器中可不用编写增删改查的代码,除非需要自己控制这部分逻辑
     * 需要将application/admin/library/traits/Backend.php中对应的方法复制到当前控制器,然后进行修改
     */


}
