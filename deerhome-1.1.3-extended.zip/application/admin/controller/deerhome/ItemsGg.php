<?php

namespace app\admin\controller\deerhome;

use app\common\controller\Backend;
use think\Db;
use Exception;
use think\exception\PDOException;
use think\exception\ValidateException;
/**
 * 产品规格
 *
 * @icon fa fa-circle-o
 */
class ItemsGg extends Backend
{

    /**
     * ItemsGg模型对象
     * @var \app\admin\model\deerhome\ItemsGg
     */
    protected $model = null;
    protected $relationSearch = true;

    public function _initialize()
    {
        parent::_initialize();
        $this->model = new \app\admin\model\deerhome\ItemsGg;
    }

    public function index()
    {
        if (!$this->request->isAjax())
        {
            $multiple=$this->request->param('multiple','','trim');
            $this->assignconfig("multiple",$multiple);
            $this->assign("multiple", $multiple);
            return $this->view->fetch();
        }
        list($where, $sort, $order, $offset, $limit) = $this->buildparams();
        $total = $this->model
                ->with(["items"])
                ->where($where)
                ->count();
        $list = $this->model
                ->with(["items"])
                ->where($where)
                ->order($sort, $order)
                ->limit($offset, $limit)
                ->select();
        $result = array("total" => $total, "rows" => $list);

        return json($result);
    }

 

}
