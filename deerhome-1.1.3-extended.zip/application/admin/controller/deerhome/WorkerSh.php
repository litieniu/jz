<?php

namespace app\admin\controller\deerhome;

use app\common\controller\Backend;
use think\Db;
use Exception;
use think\exception\PDOException;
use think\exception\ValidateException;
/**
 * 服务人员审核
 *
 * @icon fa fa-circle-o
 */
class WorkerSh extends Backend
{

    /**
     * WorkerSh模型对象
     * @var \app\admin\model\deerhome\WorkerSh
     */
    protected $model = null;

    public function _initialize()
    {
        parent::_initialize();
        $this->model = new \app\admin\model\deerhome\WorkerSh;
        $this->view->assign("statusList", $this->model->getStatusList());
    }

    public function edit($ids = null)
    {
        $row = $this->model->get($ids);
        if (!$row) {
            $this->error(__('No Results were found'));
        }
      
        if (false === $this->request->isPost()) {
            $this->view->assign('row', $row);
            $list=db('deerhome_cate')->field('id,name')->where('cate_id',0)->where('status',1)->column('name','id');
            $this->assign("cateData", $list);
            return $this->view->fetch();
        }
        $params = $this->request->post('row/a');
        if (empty($params)) {
            $this->error(__('Parameter %s can not be empty', ''));
        }
        if(!\in_array($params['status'],[2,3])){
            $this->error('请选择审核状态');
        }
        if($params['status']==2){
            $params['jz_worker_lev_id']=(int)$params['jz_worker_lev_id'];
            if($params['jz_worker_lev_id']==0){
                $this->error('请选择等级');
            }
            $params['jz_cate_ids']=$this->request->post("jz_cate_ids/a");
            $params['jz_cate_ids']=array_filter($params['jz_cate_ids']);
            if(count($params['jz_cate_ids'])==0){
                $this->error('请选择服务类别');
            }
            $params['jz_cate_ids']='0,'.implode(',',$params['jz_cate_ids']).',0';
            
        }
        if($params['status']==3){
            if(empty($params['sh_con'])){
                $this->error('请在审核意见填写拒绝原因');
            }
        }
        $admin=$this->auth->getUserInfo();
        $params['sh_ren']=$admin['username'];
        $params['sh_time']=date('Y-m-d H:i:s');
        $params = $this->preExcludeFields($params);
        $result = false;
        Db::startTrans();
        try {
            //插入worker表
            if($params['status']==2){
                $workerArr=[];
                $workerArr['type']=2;
                $workerArr['jz_worker_lev_id']=$params['jz_worker_lev_id'];
                $workerArr['uname']=$params['uname'];
                $workerArr['utel']=$row['utel'];
                $workerArr['jz_cate_ids']=$params['jz_cate_ids'];
                $workerArr['face_image']=$params['face_image'];
                $workerArr['sfz_a_image']=$params['sfz_a_image'];
                $workerArr['sfz_b_image']=$params['sfz_b_image'];
                $workerArr['zs_image']=$params['zs_image'];
                $workerArr['address']=$params['address'];
                $workerArr['latitude']=$params['latitude'];
                $workerArr['longitude']=$params['longitude'];
                $workerArr['addtime']=date('Y-m-d H:i:s');
                $workerModel=new \app\admin\model\deerhome\Worker;
                $workerModel->validateFailException()->validate(
                    ['utel' => ['unique'=>'deerhome_worker,utel']],
                    ['utel.unique'=> '无法通过审核，该手机号已经是服务人员']
                );
                $workerModel->allowField(true)->save($workerArr);
            }
            $result = $row->allowField(true)->save($params);
            Db::commit();
        } catch (ValidateException|PDOException|Exception $e) {
            Db::rollback();
            $this->error($e->getMessage());
        }
        if (false === $result) {
            $this->error(__('No rows were updated'));
        }
        try{
            \Tools\Msg::toUserApply($row['jz_user_id'],$params['status']==2?'已通过':'未通过',$params['sh_con']);
        }catch(\Exception $e){
            \think\Log::error("[审核服务人员]消息提醒失败：".$e->getMessage()."\n".json_encode($params,JSON_UNESCAPED_UNICODE));
        }
        $this->success();

    }

    /**
     * 默认生成的控制器所继承的父类中有index/add/edit/del/multi五个基础方法、destroy/restore/recyclebin三个回收站方法
     * 因此在当前控制器中可不用编写增删改查的代码,除非需要自己控制这部分逻辑
     * 需要将application/admin/library/traits/Backend.php中对应的方法复制到当前控制器,然后进行修改
     */


}
