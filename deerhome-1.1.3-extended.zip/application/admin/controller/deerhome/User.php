<?php

namespace app\admin\controller\deerhome;

use app\common\controller\Backend;
use think\Db;
/**
 * 客户管理
 *
 * @icon fa fa-circle-o
 */
class User extends Backend
{

    /**
     * User模型对象
     * @var \app\admin\model\deerhome\User
     */
    protected $model = null;
    protected $searchFields = 'id,uname,utel';
    protected $selectpageFields = 'id,uname,utel';
    protected $relationSearch = true; 
    public function _initialize()
    {
        parent::_initialize();
        $this->model = new \app\admin\model\deerhome\User;

    }
    /**
     * 充值
    */
    public function wallet_charge()
    {
        $id=$this->request->param("deerhome_user_id",0,'intval');
        $user=$this->model->where("id",$id)->find();
        if(!$user){
            $this->error("用户不存在");
        }
        $cateList=Db::name("deerhome_payway")->where("status",1)->column("name","id");
        if (!$this->request->isAjax())
        {
            $this->assign("user",$user);
            $this->assign("cateList",$cateList);
            return $this->view->fetch();
        }
        $cate=$this->request->param("cate",0,'intval');
        $price=$this->request->param("price",0,'floatval');
        $give=$this->request->param("give",0,'floatval');
        $note=$this->request->param("note","",'trim');
        $pay_time=$this->request->param("pay_time","",'trim');
        if($price==0){
            $this->error("充值金额不能为0");
        }
        if($give<0){
            $this->error("赠款不能小于0");
        }
        if($pay_time==""){
            $pay_time=date("Y-m-d H:i:s");
        }
        if(!preg_match("/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/",$pay_time)){
            $this->error("请选择充值时间");
        }
        if(!isset($cateList[$cate])){
            $this->error("线下收款方式");
        }
        if($price<0 && $give>0){
            $this->error("充值金额小于0时，赠款只能为0，请检查");
        }
        if($price>50000 || $price<-50000){
            $this->error("单笔充值金额不能大于50000");
        }
        $money=bcadd($price,$give,2);
        $edit=[];
        $edit['wallet_charge']=bcadd($user->wallet_charge,$money,2);
        if($edit['wallet_charge']<0){
            $this->error("请检查，操作后余额不能小于0！");
        }
        if($note==""){
            $note="充值￥{$price}，赠款￥{$give}，实际到账￥{$money}";
        }
        $log=[];
        array_push($log,[
            'deerhome_user_id'=>$user->id,
            'type'=>2,
            'is_wallet'=>1,
            'status'=>2,
            'price'=>$price,
            'give'=>$give,
            'payway_type'=>2,
            'pay_way'=>$cateList[$cate],
            'pay_time'=>$pay_time,
            'add_time'=>\date("Y-m-d H:i:s"),
            'note'=>$note,
        ]);

        Db::startTrans();
        try{
            Db::name("deerhome_user")->where("id",$id)->update($edit);
            Db::name("deerhome_order_pay_log")->insertAll($log);
            Db::commit();
        }catch(\Exception $e){
            Db::rollback();
            $this->error($e->getMessage());
        }
        $this->success("充值成功");
    }
    public function index()
    {
        if (!$this->request->isAjax())
        {
            $levList=Db::name("deerhome_user_lev")->field("id,name,lev")->order("lev asc")->select();
            $this->view->assign('levList', $levList);
            $this->assignconfig('levList', $levList);
            return $this->view->fetch();
        }
        if ($this->request->request('keyField')) {
            return $this->selectpage();
        }
        list($where, $sort, $order, $offset, $limit) = $this->buildparams();
        $total = $this->model
                ->with(["lev"])
                ->where($where)
                ->count();
        $list = $this->model
                ->with(["lev"])
                ->where($where)
                ->order($sort, $order)
                ->limit($offset, $limit)
                ->select();
        foreach($list as $k=>&$v){
            $v['order_num']=0;
            $v['order_price']=0;
            $order=Db::name("deerhome_order")->where('jz_user_id',$v['id'])->where("status","in",[2,3,4,5])->field("count(id) as order_num,SUM(price_payed) as order_price")->find();
            if($order){
                $v['order_num']=$order['order_num'];
                $v['order_price']=$order['order_price'];
            }

            $v['order_price'] = number_format($v['order_price'],2);
            $v['user_sc']=Db::name("deerhome_user_collected")->where("type",1)->where('jz_user_id',$v['id'])->count();
            $v['user_zj']=Db::name("deerhome_user_collected")->where("type",2)->where('jz_user_id',$v['id'])->count();
            $v['user_pages']=Db::name("deerhome_user_collected")->where("type",3)->where('jz_user_id',$v['id'])->count();
        }
        $result = array("total" => $total, "rows" => $list);
        return json($result);
    }

    /**
     * 默认生成的控制器所继承的父类中有index/add/edit/del/multi五个基础方法、destroy/restore/recyclebin三个回收站方法
     * 因此在当前控制器中可不用编写增删改查的代码,除非需要自己控制这部分逻辑
     * 需要将application/admin/library/traits/Backend.php中对应的方法复制到当前控制器,然后进行修改
     */


}
