<?php

namespace app\admin\controller\deerhome;

use app\common\controller\Backend;

/**
 * 评价管理
 *
 * @icon fa fa-circle-o
 */
class Evaluate extends Backend
{

    /**
     * Evaluate模型对象
     */
    protected $model = null;
    protected $relationSearch = true; 
    protected $searchFields = 'sn';
    protected $multiFields="worker_pj_star_status,worker_pj_star_good";
    public function _initialize()
    {
        parent::_initialize();
        $this->model = new \app\admin\model\deerhome\Order;
    }

    public function index()
    {
        if ($this->request->isAjax())
        {
            list($where, $sort, $order, $offset, $limit) = $this->buildparams();
            $total = $this->model
                    ->where($where)
                    ->where("worker_pj_star",">",0)
                    ->count();
            $list = $this->model
                    ->where($where)
                    ->where("worker_pj_star",">",0)
                    ->order($sort, $order)
                    ->limit($offset, $limit)
                    ->select();
            $result = array("total" => $total, "rows" => $list);
            return json($result);
        }
        return $this->view->fetch();
    }

}
