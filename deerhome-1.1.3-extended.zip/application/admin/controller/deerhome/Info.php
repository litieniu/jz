<?php

namespace app\admin\controller\deerhome;

use app\common\controller\Backend;
use fast\Date;
use think\Db;
/**
 * 概览面板
 *
 * @icon fa fa-circle-o
 */
class Info extends Backend
{

    protected $model = null;
    public function _initialize()
    {
        parent::_initialize();
    }

    /**
     * 检查信息是否配置完整
     *
     * @return string|Json
     * @throws \think\Exception
     * @throws DbException
     */
    public function checkErr()
    {
        $this->success();
    }
    /**
     * 查看
     *
     * @return string|Json
     * @throws \think\Exception
     * @throws DbException
     */
    public function index()
    {
        if (false === $this->request->isAjax()) {
            return $this->view->fetch();
        }
        if($this->request->param("action")=="checkErr"){
            $this->checkErr();
            return;
        }
        $trade=$this->request->param("trade",0,"intval");
        $column = [];
        $starttime = strtotime(date("Y-m-01"));
        $endtime = strtotime(date("Y-m-t"));
        if($trade==1){
            $starttime = strtotime(date("Y-m-01",strtotime("-1 month")));
            $endtime = strtotime(date("Y-m-t",strtotime("-1 month")));
        }
        $trade = Db::name("deerhome_order")
            ->where('time_add', 'between time', [$starttime, $endtime])
            ->where("status","in",[2,3,4,5])
            ->field('ANY_VALUE(time_add) as time_add,  COUNT(*) AS nums, SUM(price_payed) AS price, DATE_FORMAT(`time_add`, "%m-%d") AS add_date')
            ->group('add_date')
            ->select();

        for ($time = $starttime; $time <= $endtime;) {
            $column[] = date("m-d", $time);
            $time += 86400;
        }
        $trade_chart_price = array_fill_keys($column, 0);
        $trade_chart_num = array_fill_keys($column, 0);
        foreach ($trade as $k => $v) {
            $trade_chart_num[$v['add_date']] = (int)$v['nums'];
            $trade_chart_price[$v['add_date']] = $v['price'];
        }

        if($trade==1){
            $out=[];
            $out['trade_chart']['price'] = array_values($trade_chart_price);
            $out['trade_chart']['num'] = array_values($trade_chart_num);
            $out['trade_chart']['x'] = $column;
            $this->success('','',$out);
        }

        //用户图表
        $starttime = Date::unixtime('day', -31);
        $starttime_user = Date::unixtime('day', -10);
        $column_user = [];
        $trade_user = Db::name("deerhome_user")->where('regtime', 'between time', [$starttime_user, $endtime])
            ->field('ANY_VALUE(regtime) as regtime,  COUNT(*) AS nums, DATE_FORMAT(regtime, "%m-%d") AS add_date')
            ->group('add_date')
            ->select();
        for ($time = $starttime_user; $time <= $endtime;) {
            $column_user[] = date("m-d", $time);
            $time += 86400;
        }
        $user_chart_num = array_fill_keys($column_user, 0);
        foreach ($trade_user as $k => $v) {
            $user_chart_num[$v['add_date']] = (int)$v['nums'];
        }
        // foreach ($user_chart_num as $k => $v) {
        //     $user_chart_num[$k] = rand(10,50);
        // }

        //热销->where("sale_times",">",0)
        $hot_sale=Db::name("deerhome_items")->field("name,sale_times")->order('sale_times desc')->limit(8)->select();
        $total_sale=Db::name("deerhome_items")->sum("sale_times");
        foreach ($hot_sale as $k=>$v){
            if($total_sale==0){
                $hot_sale[$k]['percent']="0%";
                continue;
            }
            $hot_sale[$k]['percent']=round($v['sale_times']/$total_sale,2)*100 . "%";
        }
  
        //接单排行
        $worker_rank=Db::name("deerhome_order")->alias('o')->join("deerhome_worker w","o.worker_id=w.id")->field("w.face_image,w.uname, COUNT(o.id) AS nums")->where('o.status','<=',5)->where('o.worker_id','>',0)->group('o.worker_id')->limit(8)->order('nums desc')->select();
        //最近服务记录
        $fw_log=Db::name("deerhome_order_log")->alias('l')->join("deerhome_order o","o.id=l.order_id")->field("o.sn,l.ac_user,l.note,l.add_time")->limit(12)->order('l.id desc')->select();
  
        $out=[];
        $out['trade_chart']['price'] = array_values($trade_chart_price);
        $out['trade_chart']['num'] = array_values($trade_chart_num);
        $out['trade_chart']['x'] = $column;

        $out['use_chart']['num'] = array_values($user_chart_num);
        $out['use_chart']['x'] = $column_user;

        $out['hot_sale'] = $hot_sale;
        $out['xs_list'] =[];
        $out['worker_rank'] = $worker_rank;
        $out['fw_log'] = $fw_log;
        $out['tpl_ids'] = [];
        $saasInfo=$this->auth->getGroups($this->auth->id);
        $saasInfo=$saasInfo[0];
        
        //入驻审核
        $out['tpl_ids']['rzsh'] = Db::name("deerhome_worker_sh")->where('status',1)->count();
        //提现审核
        $out['tpl_ids']['txsh'] = Db::name("deerhome_worker_money_log")->where('type','like','%提现')->where('status',1)->count();
        $out['tpl_ids']['fapiao'] = Db::name("deerhome_fapiao")->where('status',1)->count();
        $out['tpl_ids']['shouhou'] = Db::name("deerhome_order_refund")->where('status',1)->count();
        //待完成订单
        $status2=0;
        $status3=0;
        $status4=0;
        $dwc_orders=Db::name("deerhome_order")->field("status,COUNT(id) as num")->where('status','in',[2,3,4])->group('status')->select();
        if(count($dwc_orders)>0){
            foreach($dwc_orders as $k=>$v){
                if($v['status']==2){
                    $status2=$v['num'];
                }elseif($v['status']==3){
                    $status3=$v['num'];
                }elseif($v['status']==4){
                    $status4=$v['num'];
                }
            }
        }
        $out['tpl_ids']['dwc_orders'] = "{$status2} / {$status3} / {$status4}";

        //数据概况
        $out['tpl_ids']['info_today_price'] = Db::name("deerhome_order")->where("status","in",[2,3,4,5])->whereTime('time_add',"today")->sum('price_payed');
        $out['tpl_ids']['info_today_price'] = "￥".number_format($out['tpl_ids']['info_today_price'],2);

        $out['tpl_ids']['info_month_price'] = Db::name("deerhome_order")->where("status","in",[2,3,4,5])->whereTime('time_add',"month")->sum('price_payed');
        $out['tpl_ids']['info_month_price'] = "￥".number_format($out['tpl_ids']['info_month_price'],2);

        $out['tpl_ids']['info_today_num'] = Db::name("deerhome_order")->whereTime('time_add',"today")->where("price_payed",">",0)->count();
        $out['tpl_ids']['info_month_num'] = Db::name("deerhome_order")->whereTime('time_add',"month")->where("price_payed",">",0)->count();

        $out['tpl_ids']['info_day_user'] = Db::name("deerhome_user")->whereTime('regtime',"today")->count();
        $out['tpl_ids']['info_total_user'] = Db::name("deerhome_user")->count();

        $out['tpl_ids']['info_total_worker'] = Db::name("deerhome_worker")->count();
        $out['tpl_ids']['info_total_shop'] = Db::name("deerhome_shop")->count();

        $this->success('','',$out);
    }

}
