<?php

return [
    'Status'      => '状态',
    'Status 1'    => '已发布',
    'Set status to 1'=> '设为已发布',
    'Status 2'    => '草稿箱',
    'Set status to 2'=> '设为草稿箱',
    'Cate'        => '分类',
    'Cate 1'      => '首页',
    'Cate 2'      => '自定义页面',
    'Page_title'  => '页面名称',
    'Con'         => 'json内容',
    'Update_time' => '更新时间',
    'Can_del'     => '可删除',
    'Can_del 1'   => '是',
    'Can_del 2'   => '否'
];
