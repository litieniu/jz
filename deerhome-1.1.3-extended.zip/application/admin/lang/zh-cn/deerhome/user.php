<?php

return [
    'Jz_qd_id' => '来源渠道',
    'Uname'    => '用户姓名',
    'Utel'     => '手机号码',
    'Note'     => '备注',
    'Wxid'     => '微信id',
    'Regtime'  => '注册时间'
];
