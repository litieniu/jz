<?php

return [
    'Status'      => '状态',
    'Status 1'    => '待审核',
    'Status 2'    => '通过',
    'Status 3'    => '拒绝',
    'Face_image'  => '头像',
    'Uname'       => '姓名',
    'Utel'        => '手机号码',
    'Sfz_a_image' => '身份证正面',
    'Sfz_b_image' => '身份证反面',
    'Address'     => '详细地址',
    'Add_time'    => '提交时间',
    'Sh_ren'      => '审核人',
    'Sh_con'      => '审核意见',
    'Sh_time'     => '审核时间'
];
