<?php

return [
    'Price'     => '金额',
    'Status'                 => '订单状态',
    'Status 1'               => '待付款',
    'Status 2'               => '待派单',
    'Status 3'               => '待服务',
    'Status 4'               => '待验收',
    'Status 5'               => '已完成',
    'Status 6'               => '退款中',
    'Status 7'               => '已退款',
    'Status 8'               => '已取消',
    'Sn'                     => '订单编号'
];
