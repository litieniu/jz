<?php

return [
    'Latitude'  => '纬度',
    'Longitude'  => '经度',
    'Mdname'  => '门店名称',
    'Address' => '地址'
];
