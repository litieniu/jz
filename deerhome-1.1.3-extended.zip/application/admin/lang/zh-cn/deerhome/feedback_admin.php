<?php

return [
    'Admin_name' => '租户',
    'Cate'       => '分类',
    'Con'        => '反馈内容',
    'Add_time'   => '提交时间',
    'Status'     => '状态',
    'Status 1'   => '待处理',
    'Set status to 1'=> '设为待处理',
    'Status 2'   => '已处理',
    'Set status to 2'=> '设为已处理',
    'Res_time'   => '处理时间'
];
