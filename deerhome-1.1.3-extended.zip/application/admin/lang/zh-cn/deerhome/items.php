<?php

return [
    'Cate_id'     => '类目',
    'Name'        => '服务名称',
    'Worker_fc_bl'        => '服务分成',
    'View_times'        => '浏览次数',
    'Sale_times'        => '销量',
    'Status'      => '状态',
    'Status 1'    => '正常',
    'Status 2'    => '下架',
    'Home'      => '首页',
    'Recommend'      => '精选',
    'Price'       => '售价',
    'Face_image'  => '封面图',
    'Video_file' => '视频',
    'Weigh'       => '排序',
    'Note'        => '说明'
];
