<?php

return [
    'Name' => '渠道名称'
];
