<?php

return [
    'Status'           => '状态',
    'Status 1'         => '待处理',
    'Status 2'         => '已退款',
    'Status 3'         => '已拒绝',
    'Jz_user_id'       => '用户id',
    'Order_sn'         => '订单号',
    'Lx'               => '退款类型',
    'Price'            => '订单金额',
    'Price_refund'     => '退款金额',
    'Note'             => '退款原因',
    'Addtime'          => '申请时间',
    'Ac_admin'         => '处理人',
    'Ac_admin_time'    => '处理时间',
    'Order_old_status' => '申请退款时订单状态'
];
