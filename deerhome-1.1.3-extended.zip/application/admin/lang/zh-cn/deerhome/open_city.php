<?php

return [
    'Cityname' => '城市',
    'Province' => '省份',
];
