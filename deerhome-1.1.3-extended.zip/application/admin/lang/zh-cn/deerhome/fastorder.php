<?php

return [
    'Status'     => '状态',
    'Status 1'   => '待处理',
    'Status 2'   => '已下单',
    'Status 3'   => '已流失',
    'Jz_user_id' => '用户',
    'Cate'       => '需求',
    'Tel'        => '手机号码',
    'Note'       => '留言',
    'Res_time'       => '处理时间',
    'Add_time'   => '提交时间'
];
