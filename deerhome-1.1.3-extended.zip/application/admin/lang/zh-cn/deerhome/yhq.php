<?php

return [
    'Status'     => '状态',
    'Status 1'   => '待领取',
    'Status 2'   => '已领取',
    'Status 3'   => '已消费',
    'Status 4'   => '已过期',
    'Name'       => '活动名称',
    'Type'       => '类型',
    'Money_lev'  => '消费满金额',
    'Money_yh'   => '减免金额',
    'Start_day'  => '生效日期',
    'End_day'    => '失效日期',
    'Jz_user_id' => '领取用户',
    'Code'       => '券码',
    'Jz_cate_ids'       => '使用范围',
    'Order_sn'       => '消费订单号',
    'Get_time'       => '领取时间',
    'Use_time'       => '消费时间',
    'Addtime'    => '创建时间'
];
