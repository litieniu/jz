<?php

return [
    'Face_image' => '图片',
    'Home' => '首页展示',
    'Name'       => '名称',
    'Cate_id'    => '上级类目',
    'Status'     => '状态',
    'Status 1'   => '正常',
    'Status 2'   => '停用',
    'Createtime' => '创建时间	',
    'Updatetime' => '更新时间'
];
