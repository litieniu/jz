<?php

return [
    'Anget'           => '参与分销',
    'Anget 1'         => '是',
    'Anget 2'         => '否',
    'Anget_lev1'      => '上级分佣',
    'Anget_lev2'      => '上上级分佣',
    'Name'            => '套餐名称',
    'Status'          => '状态',
    'Status 1'        => '正常',
    'Set status to 1' => '设为正常',
    'Status 2'        => '下架	',
    'Set status to 2' => '设为下架	',
    'Price'           => '售价',
    'Price_market'    => '原价',
    'Face_image'      => '封面图',
    'Img_images'      => '图片集',
    'Createtime'      => '创建时间',
    'Updatetime'      => '更新时间',
    'Weigh'           => '排序',
    'Body_con'        => '图文详情',
    'View_times'      => '浏览次数',
    'Sale_times'      => '销量',
    'Fake_sale_times' => '基础销量',
    'Items.num'       => '次数'
];
