<?php

return [
    'Type'    => '平台',
    'Type 1'  => '用户端',
    'Type 2'  => '服务端',
    'Title'   => '模板标题',
    'Tplid'   => '模板ID',
    'Keyword' => '关键词'
];
