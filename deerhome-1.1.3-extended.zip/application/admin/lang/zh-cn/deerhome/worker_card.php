<?php

return [
    'Jz_worker_id' => '服务人员',
    'Uname'        => '收款人',
    'Card'         => '银行卡号',
    'Bank'         => '开户行',
    'Add_time'     => '添加时间'
];
