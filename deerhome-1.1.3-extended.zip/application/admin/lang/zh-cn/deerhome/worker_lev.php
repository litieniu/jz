<?php

return [
    'Name' => '等级名称',
    'Fybl' => '返佣比例'
];
