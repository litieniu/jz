<?php

return [
    'Con' => '评价内容'
];
