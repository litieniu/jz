<?php

return [
    'Order_sn'      => '订单号',
    'Status'        => '状态',
    'Status 1'      => '待支付',
    'Status 2'      => '已支付',
    'Status 3'      => '已取消',
    'Price'         => '金额',
    'Note'          => '备注',
    'Payway_type'   => '类型',
    'Payway_type 1' => '线上支付',
    'Payway_type 2' => '线下支付',
    'Pay_way'       => '支付方式',
    'Pay_time'      => '支付时间',
    'Add_time'      => '添加时间'
];
