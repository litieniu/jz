<?php

return [
    'Name'        => '等级名称',
    'Lev'         => '等级权重',
    'Discount'    => '会员折扣比例',
    'Task'        => '升级条件',
    'Task_type'   => '条件类型',
    'Task_type 1' => '全部满足',
    'Task_type 2' => '任意一个',
    'Note'        => '描述',
    'Bg_image'    => '背景图'
];
