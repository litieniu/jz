<?php

return [
    'Status'           => '状态',
    'Status 1'         => '正常',
    'Status 2'         => '停用',
    'Type'             => '类型',
    'Type 1'           => '内部',
    'Type 2'           => '入驻',
    'Jz_shop_id'       => '所属门店',
    'Jz_worker_lev_id' => '等级',
    'Uname'            => '姓名',
    'Utel'             => '手机号',
    'Times'            => '服务次数',
    'Money_left'       => '可提现金额',
    'Money_dj'         => '冻结金额',
    'Money_tx'         => '累计提现',
    'Addtime'          => '添加时间'
];
