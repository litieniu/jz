<?php

return [
    'Type'         => '类型',
    'Status'       => '状态',
    'Status 1'     => '待处理',
    'Status 2'     => '已处理',
    'Status 3'     => '拒绝',
    'Jz_worker_id' => '服务人员',
    'Jz_order_sn'  => '关联订单号',
    'Price'        => '金额',
    'Note'         => '备注',
    'Addtime'      => '提交时间',
    'Donetime'     => '处理时间'
];
