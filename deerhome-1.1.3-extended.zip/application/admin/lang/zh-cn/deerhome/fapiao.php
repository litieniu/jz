<?php

return [
    'Jz_user_id' => '用户',
    'Status'     => '状态',
    'Status 1'   => '待开票',
    'Status 2'   => '已开票',
    'Status 3'   => '已拒绝',
    'Orders'     => '关联订单',
    'Price'      => '开票金额',
    'Type'       => '类型',
    'Type 1'     => '个人',
    'Type 2'     => '企业',
    'Name'       => '发票抬头',
    'Code'       => '信用代码',
    'File'       => '下载地址',
    'Add_time'   => '申请时间',
    'Res_time'   => '开票时间'
];
