<?php

return [
    'Cate'     => '分类',
    'Name'     => '标题',
    'Con'      => '内容',
    'Add_time' => '添加时间'
];
