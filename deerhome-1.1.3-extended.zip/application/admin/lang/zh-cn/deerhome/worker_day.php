<?php

return [
    'Day'      => '日期',
    'Day_time' => '时间'
];
