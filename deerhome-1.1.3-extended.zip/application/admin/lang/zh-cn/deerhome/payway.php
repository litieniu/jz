<?php

return [
    'Status'   => '状态',
    'Status 1' => '开启',
    'Status 2' => '停用',
    'Name'     => '线下收款方式'
];
