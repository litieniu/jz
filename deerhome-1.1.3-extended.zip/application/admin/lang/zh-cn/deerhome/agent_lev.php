<?php

return [
    'Name'          => '等级名称',
    'Lev'           => '等级权重',
    'Task_type'           => '条件类型',
    'Bg_image'           => '背景图',
    'Lev1'          => '一级额外返佣比例',
    'Lev2'          => '二级额外返佣比例',
    'Task'          => '升级条件',
    'Note'          => '描述'
];
