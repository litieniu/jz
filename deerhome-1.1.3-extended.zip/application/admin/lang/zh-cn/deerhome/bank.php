<?php

return [
    'Bank'      => '银行',
    'Status'    => '状态',
    'Status 1'  => '启用',
    'Set status to 1'=> '设为启用',
    'Status 2'  => '停用',
    'Set status to 2'=> '设为停用',
    'Saas_hash' => 'md5,bank'
];
