<?php

return [
    'Price'    => '充值金额',
    'Give'     => '赠款'
];
