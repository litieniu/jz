<?php

namespace app\admin\validate;

use think\Validate;

class Items extends Validate
{
    /**
     * 验证规则
     */
    protected $rule = [
        'name'  =>  'require|unique:jz_items'
    ];
    /**
     * 提示消息
     */
    protected $message = [
        'name.unique'  =>  '服务名称已经存在，请更换',
    ];
    /**
     * 验证场景
     */
    protected $scene = [
        'add'  => [],
        'edit' => [],
    ];
    
}
