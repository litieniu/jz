<?php

namespace app\admin\model\deerhome;

use think\Model;


class Fwtx extends Model
{

    

    

    // 表名
    protected $name = 'deerhome_worker_money_log';
    
    // 自动写入时间戳字段
    protected $autoWriteTimestamp = false;

    // 定义时间戳字段名
    protected $createTime = false;
    protected $updateTime = false;
    protected $deleteTime = false;

    // 追加属性
    protected $append = [
        'status_text'
    ];
    

    
    public function getStatusList()
    {
        return ['1' => __('Status 1'), '2' => __('Status 2'), '3' => __('Status 3')];
    }


    public function getStatusTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['status']) ? $data['status'] : '');
        $list = $this->getStatusList();
        return isset($list[$value]) ? $list[$value] : '';
    }

    public function worker()
    {
        return $this->belongsTo('Worker', 'jz_worker_id','id','c2','LEFT')->setEagerlyType(0);
    }
    public function user()
    {
        return $this->belongsTo('User', 'deerhome_user_id','id','c3','LEFT')->setEagerlyType(0);
    }


}
