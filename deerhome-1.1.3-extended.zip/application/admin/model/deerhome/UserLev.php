<?php

namespace app\admin\model\deerhome;

use think\Model;


class UserLev extends Model
{

    

    

    // 表名
    protected $name = 'deerhome_user_lev';
    
    // 自动写入时间戳字段
    protected $autoWriteTimestamp = false;

    // 定义时间戳字段名
    protected $createTime = false;
    protected $updateTime = false;
    protected $deleteTime = false;

    // 追加属性
    protected $append = [
        'task_type_text'
    ];
    

    
    public function getTaskTypeList()
    {
        return ['1' => __('Task_type 1'), '2' => __('Task_type 2')];
    }


    public function getTaskTypeTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['task_type']) ? $data['task_type'] : '');
        $list = $this->getTaskTypeList();
        return isset($list[$value]) ? $list[$value] : '';
    }




}
