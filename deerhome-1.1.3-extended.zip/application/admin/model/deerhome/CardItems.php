<?php

namespace app\admin\model\deerhome;

use think\Model;

class CardItems extends Model
{
    // 表名
    protected $name = 'deerhome_card_items';

    public function items()
    {
        return $this->belongsTo('app\admin\model\deerhome\Items', 'deerhome_items_id', 'id', [], 'LEFT')->setEagerlyType(0);
    }
    public function card()
    {
        return $this->belongsTo('app\admin\model\deerhome\Card', 'deerhome_card_id', 'id', [], 'LEFT')->setEagerlyType(0);
    }
}
