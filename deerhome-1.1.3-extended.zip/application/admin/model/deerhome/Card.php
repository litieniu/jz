<?php

namespace app\admin\model\deerhome;

use think\Model;
use app\admin\model\deerhome\CardItems;


class Card extends Model
{

    // 表名
    protected $name = 'deerhome_card';
    
    // 自动写入时间戳字段
    protected $autoWriteTimestamp = 'int';

    // 定义时间戳字段名
    protected $createTime = 'createtime';
    protected $updateTime = 'updatetime';
    protected $deleteTime = false;

    // 追加属性
    protected $append = [
        'img_images_arr',
        'anget_text',
        'time_area_text',
        'status_text'
    ];

    protected static function init()
    {
        self::afterInsert(function ($row) {
            $pk = $row->getPk();
            $row->getQuery()->where($pk, $row[$pk])->update(['weigh' => $row[$pk]]);
        });
        self::afterDelete(function ($row) {
            $pk = $row->getPk();
            CardItems::where('deerhome_card_id', $row[$pk])->delete();
        });
        self::beforeInsert(function ($row) {
            $row->createtime=date('Y-m-d H:i:s');
            $row->updatetime=date('Y-m-d H:i:s');
            $imgs=explode(',',$row->img_images);
            if(count($imgs)>0){
                $row->face_image = trim($imgs[0]);
            }
        });
        self::beforeUpdate(function ($row) {
            $row->updatetime=date('Y-m-d H:i:s');
            $imgs=explode(',',$row->img_images);
            if(count($imgs)>0){
                $row->face_image = trim($imgs[0]);
            }
        });
    }

    
    public function getTimeAreaList()
    {
        return ['1' => '永久', '2' => '月卡','3'=>'季卡','4'=>'年卡'];
    }
    public function getYesNoList()
    {
        return ['1' => '是', '2' => '否'];
    }
    public function getAngetList()
    {
        return ['1' => __('Anget 1'), '2' => __('Anget 2')];
    }

    public function getStatusList()
    {
        return ['1' => __('Status 1'), '2' => __('Status 2')];
    }


    public function getFaceImageAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['face_image']) ? $data['face_image'] : '');
        if(empty($value)){
            return '';
        }
        return cdnurl($value,true);
    }
    public function getImgImagesArrAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['img_images']) ? $data['img_images'] : '');
        if(empty($value)){
            return [];
        }
        $value=explode(",",$value);
        $arr=[];
        foreach ($value as $v){
            if($v!=""){
                $arr[]=cdnurl($v,true);
            }
        }
        return $arr;
    }
    public function getAngetTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['anget']) ? $data['anget'] : '');
        $list = $this->getAngetList();
        return isset($list[$value]) ? $list[$value] : '';
    }
    public function getTimeAreaTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['time_area']) ? $data['time_area'] : '');
        $list = $this->getTimeAreaList();
        return isset($list[$value]) ? $list[$value] : '';
    }
    public function getTimeAreaDesc($value)
    {
        $arr=[];
        $arr['1']="永久有效";
        $arr['2']="购买后30天内有效";
        $arr['3']="购买后90天内有效";
        $arr['4']="购买后365天内有效";
        return $arr[$value];
    }
    public function getTimeAreaEndTime($startTime,$timeArea)
    {
        if($timeArea==1){
            return "2199-12-31 23:59:59";
        }
        if($timeArea==2){
            return date("Y-m-d H:i:s",strtotime("+29 day",strtotime($startTime)));
        }
        if($timeArea==3){
            return date("Y-m-d H:i:s",strtotime("+89 day",strtotime($startTime)));
        }
        if($timeArea==4){
            return date("Y-m-d H:i:s",strtotime("+364 day",strtotime($startTime)));
        }
        return '';
    }


    public function getStatusTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['status']) ? $data['status'] : '');
        $list = $this->getStatusList();
        return isset($list[$value]) ? $list[$value] : '';
    }

    public function cardItems()
    {
        return $this->hasMany('CardItems',  'deerhome_card_id')
        ->alias('card_items')
        ->join('deerhome_items_gg items_gg', 'items_gg.hash = card_items.deerhome_items_gg_hash', 'LEFT')
        ->join('deerhome_items items', 'items.id = items_gg.jz_items_id', 'LEFT')
        ->field('card_items.*
            ,items_gg.name as items_gg_name,items_gg.price as items_gg_price,items_gg.dw as items_gg_dw
            ,items.name as items_name,items.id as items_id
        ');
    }
}
