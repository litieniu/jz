<?php

namespace app\admin\model\deerhome;

use think\Model;

class ItemsGg extends Model
{
    // 表名
    protected $name = 'deerhome_items_gg';


    protected static function init()
    {
        self::afterInsert(function ($row) {
            $pk = $row->getPk();
            $row->getQuery()->where($pk, $row[$pk])->update(['weigh' => $row[$pk],"hash"=>md5($row['jz_items_id'].$row['name'])]);
        });
    }

    public function items()
    {
        return $this->belongsTo('app\admin\model\deerhome\Items', 'jz_items_id', 'id', [], 'LEFT')->setEagerlyType(0);
    }


}
