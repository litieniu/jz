<?php

namespace app\admin\model\deerhome;

use think\Model;


class User extends Model
{

    

    

    // 表名
    protected $name = 'deerhome_user';
    
    // 自动写入时间戳字段
    protected $autoWriteTimestamp = false;

    // 定义时间戳字段名
    protected $createTime = false;
    protected $updateTime = false;
    protected $deleteTime = false;

    // 追加属性
    protected $append = [

    ];
    

    public function lev()
    {
        return $this->belongsTo('UserLev', 'user_lev_id','id','c1','LEFT')->setEagerlyType(0);
    }

    public function getUtelAttr($value, $data=[])
    {
        $value = $value ? $value : (isset($data['utel']) ? $data['utel'] : '');
        return \Tools\Config::tel($value);
    }

}
