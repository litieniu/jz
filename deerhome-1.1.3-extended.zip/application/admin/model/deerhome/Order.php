<?php

namespace app\admin\model\deerhome;

use think\Model;


class Order extends Model
{

    

    

    // 表名
    protected $name = 'deerhome_order';
    
    // 自动写入时间戳字段
    protected $autoWriteTimestamp = false;

    // 定义时间戳字段名
    protected $createTime = false;
    protected $updateTime = false;
    protected $deleteTime = false;

    // 追加属性
    protected $append = [
        'status_text'
    ];
    

    
    public function getStatusList()
    {
        return [
            '1' => '待付款'
            , '2' => '待派单'
            , '3' => '待服务'
            , '4' => '待验收'
            , '5' => '已完成'
            , '6' => '退款中'
            , '7' => '已退款'
            , '8' => '已取消'
        ];
    }


    public function getStatusTextAttr($value, $data=[])
    {
        $value = $value ? $value : (isset($data['status']) ? $data['status'] : '');
        $list = $this->getStatusList();
        return isset($list[$value]) ? $list[$value] : '';
    }
    public function getUserPhoneAttr($value, $data=[])
    {
        $value = $value ? $value : (isset($data['user_phone']) ? $data['user_phone'] : '');
        return \Tools\Config::tel($value);
    }




}
