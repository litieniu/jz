<?php

namespace app\admin\model\deerhome;

use think\Model;


class CardOrderItems extends Model
{

    // 表名
    protected $name = 'deerhome_card_order_items';
    
    // 自动写入时间戳字段
    protected $autoWriteTimestamp = false;

    // 定义时间戳字段名
    protected $createTime = false;
    protected $updateTime = false;
    protected $deleteTime = false;

    protected static function init()
    {
        self::beforeWrite(function ($row) {
            if(isset($row->num_left) && $row->num_left<0){
                $row->num_left=0;
            }
        });
    }

    public function cardOrder()
    {
        return $this->belongsTo('app\admin\model\deerhome\CardOrder', 'deerhome_card_order_id', 'id', [], 'LEFT')->setEagerlyType(0);
    }

    public function items()
    {
        return $this->belongsTo('app\admin\model\deerhome\Items', 'deerhome_items_id', 'id', [], 'LEFT')->setEagerlyType(0);
    }
    public function itemsGg()
    {
        return $this->belongsTo('app\admin\model\deerhome\ItemsGg', 'deerhome_items_gg_hash', 'hash', [], 'LEFT')->setEagerlyType(0);
    }
}
