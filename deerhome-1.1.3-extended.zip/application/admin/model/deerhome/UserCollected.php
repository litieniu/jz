<?php

namespace app\admin\model\deerhome;

use think\Model;


class UserCollected extends Model
{

    

    

    // 表名
    protected $name = 'deerhome_user_collected';
    
    // 自动写入时间戳字段
    protected $autoWriteTimestamp = false;

    // 定义时间戳字段名
    protected $createTime = false;
    protected $updateTime = false;
    protected $deleteTime = false;

    // 追加属性
    protected $append = [

    ];
    
    public function items()
    {
        return $this->belongsTo('Items', 'jz_items_id','id','c2','LEFT')->setEagerlyType(0);
    }
}
