<?php

namespace app\admin\model\deerhome;

use think\Model;


class Shop extends Model
{

    // 表名
    protected $name = 'deerhome_shop';
    
    // 自动写入时间戳字段
    protected $autoWriteTimestamp = false;

    // 定义时间戳字段名
    protected $createTime = false;
    protected $updateTime = false;
    protected $deleteTime = false;

    // 追加属性
    protected $append = [

    ];
    

    public function Worker(){
        return $this->hasMany('Worker','jz_shop_id') ;
    }







}
