<?php

namespace app\admin\model\deerhome;

use think\Model;


class WorkerCard extends Model
{

    

    

    // 表名
    protected $name = 'deerhome_worker_card';
    
    // 自动写入时间戳字段
    protected $autoWriteTimestamp = false;

    // 定义时间戳字段名
    protected $createTime = false;
    protected $updateTime = false;
    protected $deleteTime = false;

    // 追加属性
    protected $append = [

    ];
    

    public function worker()
    {
        return $this->belongsTo('Worker', 'jz_worker_id','id','c2','LEFT')->setEagerlyType(0);
    }


    public function user()
    {
        return $this->belongsTo('User', 'deerhome_user_id','id','u','LEFT')->setEagerlyType(0);
    }




}
