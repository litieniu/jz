<?php
namespace app\api\controller\deerhome\worker;

use app\common\controller\Api;
use think\Db;
/**
 * 基础类
*/
class Base extends Api
{
	protected $noNeedLogin = ['*']; 
    protected $_user;
    protected $_token;
    protected $_deviceType;
    protected $_version;
    protected $_allowedDeviceTypes=["wxapp","ios","android","h5"];

	public function __construct() {
        parent::__construct();
        $this->_token = $this->request->header('Deer-Api-Token');
        $this->_version = $this->request->header('Deer-Api-Version');
        $this->_deviceType = strtolower($this->request->header('Deer-Device-Type'));

        $this->_initUser();
    }
	private function _initUser(){
        if (empty($this->_token)) {
            return ;
        }
        $user=Db::name("deerhome_worker")
        ->where("token",$this->_token)->find();
        if($user){
            $this->_user = $user;
        }
    }

	public function ok($data = [],$msg = 'success'){
        $arr=[];
        $arr['code']=0;
        $arr['msg']=$msg;
        $arr['data']=$data;
		echo json_encode($arr);
		exit;
	}
	public function err($msg = 'error',$alert=0,$data = [],$code = 1){
        $arr=[];
        $arr['code']=$code;
        $arr['msg']=$msg;
        $arr['data']=$data;
        $arr['alert']=$alert;
		echo json_encode($arr);
		exit;
	}
    protected function fixImg($img,$face=false){
        if($img==""){
            return '';
        }
   
        if(strpos($img,"http")===0){
            return $img;
        }
        return cdnurl($img, true);
        // return $this->request->domain().$img;
    }
    //返回周几
    protected function getWeek($date,$dw="周"){
        $weekarray=array("日","一","二","三","四","五","六");
        return $dw.$weekarray[date("w",strtotime($date))];
    }
    //获取小程序名称
    protected function getXcxName(){
        $xcx=$this->getConfig("sys");
        if(isset($xcx['xcxtitle']) && $xcx['xcxtitle']!=""){
            return $xcx['xcxtitle'];
        }
        return "未设置名称";
    }
    //微信配置
    protected function getWeixinConfig(){
        return $this->getConfig("xcx_config");
    }
    //获取系统配置
    protected function getConfig($platform){
        $data=Db::name("deerhome_xcxpz")->where("platform",$platform)->find();
        if(!$data){
            $this->err("没有配置信息");
        }
        return \json_decode($data['con'],true);
    }
}
