<?php
namespace app\api\controller\deerhome\worker;

use app\api\controller\deerhome\worker\BaseAuth;
use think\Db;
use think\Validate;

/**
 * 消息相关
 */
class Msg extends BaseAuth
{
     /**
     * 消息列表
    */
    public function index()
    {
        if(!$this->_user){
            $this->ok(['sys'=>0,'fw'=>0]);
        }
        $utype=$this->request->param("utype",1,"intval");
        $list=Db::name("deerhome_msg")->where("is_read",2)->where("utype",$utype)->where("uid",$this->_user['id'])->field('count(id) as num,msg_type')->group("msg_type")->select();
        $out=[];
        $out['sys']=0;
        $out['fw']=0;
        foreach ($list as $key => $value) {
            if($value['msg_type']==1){
                $out['sys']=$value['num'];
            }else{
                $out['fw']=$value['num'];
            }
        }
        $this->ok($out);
    }
    /**
     * 消息详情
    */
    public function detail()
    {
        if(!$this->_user){
            $this->ok();
        }
        $mtype=$this->request->param("mtype",1,"intval");
        $list=Db::name("deerhome_msg")->where("utype",2)->where("uid",$this->_user['id'])->where("msg_type",$mtype)->order("id desc")->paginate(10);
        $ids=[];
        foreach ($list as $key => $value) {
            $ids[]=$value['id'];
        }
        Db::name("deerhome_msg")->where("id","in",$ids)->update(["is_read"=>1,"read_time"=>date("Y-m-d H:i:s")]);
        $this->ok($list);
    }
     /**
     * 获取微信模板id
    */
    public function get_wx_ids()
    {
        $type=$this->request->param("type","worker");
        $titleArr=[];
        $titleArr['worker']=["新订单通知","提现审核通知","订单取消通知"];
        if(!isset($titleArr[$type])){
            $this->err("不支持的操作");
        }
        $data=Db::name("deerhome_xcxmsg")->field("tplid")->where("title","in",$titleArr[$type])->select();
        if(count($data)==0){
            $this->ok();
        }
        $out=[];
        foreach ($data as $key => $value) {
            $out[]=$value['tplid'];
        }
        $this->ok($out);
    }

}
