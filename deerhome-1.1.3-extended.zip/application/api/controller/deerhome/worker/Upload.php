<?php
namespace app\api\controller\deerhome\worker;

use app\api\controller\deerhome\worker\BaseAuth;
use think\Db;
use app\common\exception\UploadException;
use app\common\library\Upload as UploadLib;
use app\common\model\Attachment;
/**
 * 上传
 */
class Upload extends BaseAuth
{
    
    public function index()
    {
        $file = $this->request->file('file');
        try {
            $upload = new \app\common\library\Upload($file);
            $attachment = $upload->upload();
        } catch (UploadException $e) {
            $this->err($e->getMessage());
        }

        $data=[
            'url2' => $attachment->url
            , 'url' => cdnurl($attachment->url, true)
        ];
        $this->ok($data);
    }
}
