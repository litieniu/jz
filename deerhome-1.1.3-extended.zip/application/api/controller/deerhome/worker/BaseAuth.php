<?php
namespace app\api\controller\deerhome\worker;

use app\api\controller\deerhome\worker\Base;
use think\Db;
/**
 * 登录鉴权
*/
class BaseAuth extends Base
{

	public function __construct() {
        parent::__construct();
		if (!in_array($this->_deviceType, $this->_allowedDeviceTypes)) {
            $this->err('Unsupported devices');
        }
		if(!$this->_user){
			$this->err('登录失效，请重新进入',0,[],100);
		}
		if($this->_user['status']==2){
			$this->err('账号已被禁用',0,[],100);
		}
    }

}
