<?php
namespace app\api\controller\deerhome\worker;

use app\api\controller\deerhome\worker\BaseAuth;
use think\Db;
use think\Validate;

/**
 * 银行卡
 */
class Card extends BaseAuth
{
    
    public function index()
    {
        $data=[];
        $data['uname']=$this->_user['uname'];
        $data['list']=Db::name("deerhome_bank")->where("status",1)->column("bank");
        $data['bank']="";
        $data['card']="";

        $has=Db::name("deerhome_worker_card")->where("jz_worker_id",$this->_user['id'])->find();
        if($has){
            $data['uname']=$has['uname'];
            $data['bank']=$has['bank'];
            $data['card']=$has['card'];
        }
       
        $this->ok($data);
    }
    public function add(){
        $bankTip=$this->request->param("bankTip","",'trim');
        $card=$this->request->param("card","",'trim');
        if($bankTip==""){
            $this->err("请选择银行");
        }
        if(!preg_match("/^\d{10,19}$/",$card)){
            $this->err("请输入正确的银行卡号");
        }
        $isExist=Db::name("deerhome_bank")->where("status",1)->where("bank",$bankTip)->find();
        if(!$isExist){
            $this->err("银行不存在");
        }
        $has=Db::name("deerhome_worker_card")->where("jz_worker_id",$this->_user['id'])->find();
        if($has){
            $this->err("已经绑定过银行卡");
        }
        Db::name("deerhome_worker_card")->insert([
            "jz_worker_id"=>$this->_user['id'],
            "uname"=>$this->_user['uname'],
            "bank"=>$bankTip,
            "card"=>$card,
            "add_time"=>\date("Y-m-d H:i:s")
        ]);
        $this->ok();
    }
}
