<?php
namespace app\api\controller\deerhome\worker;

use app\api\controller\deerhome\worker\BaseAuth;
use think\Db;
use think\Validate;

/**
 * 用户
 */
class User extends BaseAuth
{
    
    public function index()
    {
        $data=[];
        $data['face']=$this->fixImg($this->_user['face_image']);
        $data['uname']=$this->_user['uname'];
        $data['utel']=\substr_replace($this->_user['utel'],'****',3,4);
        $data['has_card']=0;
        $data['msg']=Db::name("deerhome_msg")->where("is_read",2)->where("utype",2)->where("uid",$this->_user['id'])->count();
        $data['rz']=1;
        $data['lev']="";
        $has=Db::name("deerhome_worker_card")->where("jz_worker_id",$this->_user['id'])->find();
        if($has){
            $data['has_card']=1;
        }
        $lev=Db::name("deerhome_worker_lev")->where("id",$this->_user['jz_worker_lev_id'])->find();
        if($lev){
            $data['lev']=$lev['name']. ($lev['fybl']>0?" +".$lev['fybl']."%":"");
        }
        $this->ok($data);
    }
    public function profile(){
        $data=[];
        $data['face']=$this->fixImg($this->_user['face_image']);
        $data['uname']=$this->_user['uname'];
        $data['utel']=$this->_user['utel'];
        $data['lev']="";
        $data['regtime']=$this->_user['addtime'];
        $lev=Db::name("deerhome_worker_lev")->where("id",$this->_user['jz_worker_lev_id'])->find();
        if($lev){
            $data['lev']=$lev['name']. ($lev['fybl']>0?" +".$lev['fybl']."%":"");
        }
        $this->ok($data);
    }
    public function set_name(){
        $uname=$this->request->param("uname","",'trim');
        if($uname==""){
            $this->err("姓名不能为空");
        }
        Db::name("deerhome_worker")->where("id",$this->_user['id'])->update(["uname"=>$uname]);
        $this->ok();
    }
    public function set_face(){
        $face=$this->request->param("face","",'trim');
        if($face==""){
            $this->err("请上传头像");
        }
        Db::name("deerhome_worker")->where("id",$this->_user['id'])->update(["face_image"=>$face]);
        $this->ok();
    }
}
