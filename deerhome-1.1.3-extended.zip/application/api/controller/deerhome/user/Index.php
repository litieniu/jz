<?php
namespace app\api\controller\deerhome\user;

use app\api\controller\deerhome\user\Base;
use think\Db;
use app\admin\model\deerhome\Card as CardModel;
/**
 * 首页接口
 */
class Index extends Base
{
    /**
     * 首页
     *
     */
    public function index()
    {
        $home=Db::name("deerhome_design")->where("page","home")->find();
        $home=json_decode($home['con'],true);
        
        foreach ($home as $k => &$v) {
            if(isset($v['json'])){
                $v['json']=\json_decode($v['json'],true);
            }
        }
        // dump($home);
        $data=[];
        $data['keyword']=$home['tags'];
        $data['slide']=[];
        $ad_imgs=explode(",",$home['slide']['img']);
        foreach ($ad_imgs as $key => $value) {
            $ad_slide=[];
            $ad_slide=$home['slide']['json'][$key];
            $ad_slide['img']=$this->fixImg($value)."?s2023";
            array_push($data['slide'],$ad_slide);
        }
        $data['fastac']=[];
        $data['fastac']['show']=(int)$home['block']['show'];
        $data['fastac']['title']=$home['block']['title'];
        $data['fastac']['desc']=$home['block']['desc'];
        $data['fastac']['list']=[];
        $fastac_imgs=explode(",",$home['block']['img']);
        foreach ($fastac_imgs as $key => $value) {
            $fastac=[];
            $fastac=$home['block']['json'][$key];
            $fastac['img']=$this->fixImg($value);
            array_push($data['fastac']['list'],$fastac);
        }
        $data['banner_center']=["img"=>""];
        if(count($home['banner_center']['json'])>0){
            $data['banner_center']=$home['banner_center']['json'][0];
            $data['banner_center']['img']=$this->fixImg($home['banner_center']['img']);
        }
        $data['banner_bottom']=["img"=>""];
        if(count($home['banner_bottom']['json'])>0){
            $data['banner_bottom']=$home['banner_bottom']['json'][0];
            $data['banner_bottom']['img']=$this->fixImg($home['banner_bottom']['img']);
        }
  
        $data['category']=Db::name("deerhome_cate")->field("id,name,face_image as img")->where("cate_id",0)->where("home",1)->where("status",1)->order("weigh asc")->limit(15)->select();
        foreach ($data['category'] as &$item) {
            $item['img']=$this->fixImg($item['img']);
            $item['son']=Db::name("deerhome_cate")->where("cate_id",$item['id'])->where("status",1)->column("id");
        }
        $data['list']=[];
        foreach ($data['category'] as $value) {
            $arr=[];
            $arr['id']=$value['id'];
            $arr['name']=$value['name'];
            $arr['items']=Db::name("deerhome_items")->field("id,name,face_image,price,dw")->where("cate_id","in",$value['son'])->where("home",1)->where("status",1)->order("weigh asc")->limit(6)->select();
            foreach ($arr['items'] as &$v) {
                $v['face_image']=$this->fixImg($v['face_image'],true);
                $v['price']=$v['price']*1;
                $v['dw']=$v['dw']?"/".$v['dw']:"";
            }
            array_push($data['list'],$arr);
        }
        $data['hide_copy']=0;
        $data['title']=$this->getXcxName();

         //判断是否有会员折扣
         $discount=1;

        if($this->_user && isset($this->_user['id'])){
            Db::name("deerhome_user")->where("id",$this->_user['id'])->update(['last_time'=>date("Y-m-d H:i:s")]);

            if($this->_user['user_lev_id']>0){
                $discount=Db::name("deerhome_user_lev")->where("id",$this->_user['user_lev_id'])->value("discount");
                if(!$discount){
                    $discount=1;
                }else{
                    $discount=bcdiv($discount,100,2);
                }
            }
        }
        $data['card']=CardModel::where("is_home",1)->where("status",1)->limit(6)->select();
        foreach($data['card'] as &$v){
            if($v['vip_discount']==1){
                $v['price']=bcmul($v['price'],$discount,2);
            }
            $v['price_save']=bcsub($v['price_market'],$v['price'],0);
        }
        $this->xcxLog("首页");
        $this->ok($data);
    }
    /**
     * ip转城市
     *
     */
    public function city()
    {
        $config = get_addon_config('deerhome');
        if(!isset($config['ip2city']) || $config['ip2city']==""){
            $this->ok(['city'=>'hide']);
        }
        $appCode=$config['ip2city'];
        $ip=$this->request->ip();
        $url="https://c2ba.api.huachen.cn/ip?ip=".$ip;
        $header = array();
        $header[]="Authorization: APPCODE ".$appCode;
        $header[]="Content-Type: application/json; charset=utf-8";

        $curl = curl_init();
        curl_setopt($curl, CURLOPT_CUSTOMREQUEST, 'GET');
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_HTTPHEADER, $header);
        curl_setopt($curl, CURLOPT_FAILONERROR, false);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_HEADER, false);
        if (1 == strpos("$".$url, "https://"))
        {
            curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
        }
        $tmpInfo = curl_exec($curl);
        if (curl_errno($curl)) {
            \think\Log::write('IP转城市失败：Errno'.curl_error($curl),'error');
            $this->err('定位失败');
        }
        curl_close($curl);
        $tmpInfo=json_decode($tmpInfo,true);
        if(!is_array($tmpInfo)){
            \think\Log::write('IP转城市失败：'.$tmpInfo,'error');
            $this->err('定位失败');
        }
        if($tmpInfo['ret']!=200){
            \think\Log::write('IP转城市失败：'.$tmpInfo['msg'],'error');
            $this->err('定位失败');
        }
        $this->ok($tmpInfo['data']);
    }
   
}
