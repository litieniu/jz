<?php
namespace app\api\controller\deerhome\user;

use app\api\controller\deerhome\user\Base;
use think\Db;
/**
 * 自定义页面
 */
class Design extends Base
{
    public function index()
    {
        $id=$this->request->param('id',0,'intval');
        $preview=$this->request->param('p',0,'intval');
        $where=[];
        if($preview==0){
            $where['status']=1;
        }
        if($id==0){
            //默认首页
            $where['cate']=1;
        }else{
            $where['id']=$id;
        }
        $pageData=Db::name("deerhome_design_pages")->field('con_preview,con')->where($where)->find();
        if(!$pageData){
            $this->err("页面不存在");
        }
        $data=json_decode($pageData['con'],true);
        if($preview==1){
            $data=json_decode($pageData['con_preview'],true);
        }
        //是否隐藏版权信息
        $data['hide_copy']=0;
        //首页
        if(isset($where['cate']) && $where['cate']==1){
            $this->xcxLog("首页");
            if($this->_user && isset($this->_user['id'])){
                Db::name("deerhome_user")->where("id",$this->_user['id'])->update(['last_time'=>date("Y-m-d H:i:s")]);
            }
        }
        $this->ok($data);
    }
}