<?php
namespace app\api\controller\deerhome\user;

use app\api\controller\deerhome\user\BaseAuth;
use think\Db;
use think\Validate;

/**
 * 订单接口
 */
class Order extends BaseAuth
{
    public function index()
    {
        $gg_id = $this->request->param("gg_id","");
        $day = $this->request->param("day","");
        $time = $this->request->param("time","");
        $num = $this->request->param("num",1,"intval");
        $data=[];
        $data['address']=Db::name("deerhome_user_address")->where("user_id",$this->_user['id'])->order("is_default desc")->find();
        if(!$data['address']){
            $data['address']['id']=0;
        }
        $data['info']=Db::name("deerhome_items_gg")->alias("g")
        ->join("deerhome_items i","i.id=g.jz_items_id","left")
        ->field("g.*,i.name as b_name,i.face_image,i.cate_id")
        ->where("g.hash",$gg_id)
        ->where("i.status",1)
        ->find();
        if(!$data['info']){
            $this->err('商品不存在或已下架');
        }
        $data['info']['face_image']=$this->fixImg($data['info']['face_image']);

        $config=$this->getConfig("sys");
        $price_yj=(float)$config['jtf'];
        //夜间交通费
        $data['price_yj']=0;
        if($time){
            $time=(int)\str_replace(":","",$time);
            if($time>=1800){
                $data['price_yj']=$price_yj;
            }
        }
        //会员折扣
        if($this->_user['user_lev_id']>0){
            $discount=Db::name("deerhome_user_lev")->where("id",$this->_user['user_lev_id'])->value("discount");
            if($discount){
                $discount=bcdiv($discount,100,2);
                $data['info']['price']=bcmul($data['info']['price'],$discount,2);
            }
        }
        $data['price']=bcadd($data['info']['price'],$data['price_yj'],2);
        $data['price']=bcmul($data['price'],$num,2);



        //服务类目父级id
        $cate_pid=Db::name("deerhome_cate")->where("id",$data['info']['cate_id'])->value("cate_id");
        if($cate_pid==0){
            $cate_pid=$data['info']['cate_id'];
        }
        $data['yhq_tip']="无可用";
        //优惠券
        $data['coupon']=Db::name("deerhome_yhq")->where("status",2)->where("jz_user_id",$this->_user['id'])->field("id,name,start_day,end_day,money_lev,money_yh,type,jz_cate_ids,addtime")->order("money_yh desc")->limit(50)->select();
        foreach($data['coupon'] as &$v){
            $v['canuse']=0;
            $v['money_lev']=intval($v['money_lev']);
            $v['money_yh']=intval($v['money_yh']);
            
            if($v['jz_cate_ids']=='0'){
                $v['cate']='全场券';
                $v['cateDesc']='全场通用';
                //校验金额是否达到
                if($data['price']>=$v['money_lev']){
                    $v['canuse']=1;
                }
                continue;
            }
            $v['cate']='指定类目';
            $cate=Db::name("deerhome_cate")->field("name")->where("id","in",$v['jz_cate_ids'])->select();
            $v['cateDesc']="仅限".implode(",",array_column($cate,"name"));
            //校验类目是否可用优惠券
            if(strpos($v['jz_cate_ids'],",".$cate_pid.",")!==false){
                $v['canuse']=1;
                //校验金额是否达到
                if($data['price']<$v['money_lev']){
                    $v['canuse']=0;
                }
            }
         
            if($v['canuse']==1){
                $data['yhq_tip']="选择优惠券";
            }
        }
        $data['wallet']='1';
        $data['wallet_left']=$this->_user['wallet_charge'];
        $this->ok($data);
    }
    /**
     * 创建订单
    */
    public function creat()
    {
        $wallet=$this->request->param("wallet",0,'intval');
        $address=$this->request->param("address",0,'intval');
        $gg_id=$this->request->param("gg_id","",'trim');
        $num=$this->request->param("num",1,'intval');
        $day=$this->request->param("day",'');
        $time=$this->request->param("time",'');
        $note=$this->request->param("note","","trim");
        $imgs=$this->request->param("imgs/a",[]);

        if(!preg_match("/^\d{4}-\d{2}-\d{2}$/",$day)){
            $this->err("请选择日期");
        }
        if(!preg_match("/^\d{2}:\d{2}$/",$time)){
            $this->err("请选择时间");
        }
        if(($day." ".$time.":00") <date("Y-m-d H:i:s")){
            $this->err("已过去的时间不可选择");
        }
        $addressData=Db::name("deerhome_user_address")->where("user_id",$this->_user['id'])->where("id",$address)->find();
        if(!$addressData){
            $this->err("地址不存在");
        }

        $item=Db::name("deerhome_items_gg")->alias("g")
        ->join("deerhome_items i","i.id=g.jz_items_id","left")
        ->field("g.*,i.name as b_name,i.face_image,i.worker_fc_bl,i.id as jz_items_id,i.cate_id,i.anget,i.anget_lev1,i.anget_lev2")
        ->where("g.hash",$gg_id)
        ->where("i.status",1)
        ->find();
        if(!$item){
            $this->err('商品不存在或已下架');
        }

        $priceItem=bcmul($item['price'],$num,2);

        //计算夜间服务费
        $price_light=0;
        $config=$this->getConfig("sys");
        $price_yj=(float)$config['jtf'];
        if($time){
            $time2=(int)\str_replace(":","",$time);
            if($time2>=1800){
                $price_light=$price_yj;
            }
        }

        $add=[];
        $add['jz_user_id']=$this->_user['id'];
        //用户id补全成6位，根据用户id生成20位唯一订单号
        $add['sn']= date('ymd').str_pad($this->_user['id'],8,"0",STR_PAD_LEFT).rand(100000,999999);
        $add['price_light']=$price_light;
        $add['price_item_total']=$priceItem;
        $add['price_total']=bcadd($add['price_light'],$priceItem,2);

        if(count($imgs)>0){
            $add['imgs']=implode(",",$imgs);
        }

        $add['price_yh']=0;

        //校验优惠券
        $yhq_id=$this->request->param("yhq_id",0,'intval');
        if($yhq_id>0){
            $yhq=Db::name("deerhome_yhq")->where("id",$yhq_id)->where("status",2)->where("jz_user_id",$this->_user['id'])->find();
            if(!$yhq){
                $this->err("优惠券不存在");
            }
            //服务类目父级id
            $cate_pid=Db::name("deerhome_cate")->where("id",$item['cate_id'])->value("cate_id");
            if($cate_pid==0){
                $cate_pid=$item['cate_id'];
            }
            //校验类目是否可用优惠券
            if($yhq['jz_cate_ids']!='0'){
                if(strpos($yhq['jz_cate_ids'],",".$cate_pid.",")===false){
                    $this->err("该优惠券不可用于该服务");
                }
            }
            //校验是否在有效期
            if($yhq['start_day']>date('Y-m-d') || $yhq['end_day']<date('Y-m-d')){
                $this->err("该优惠券不在可用期限内");
            }
            //校验金额是否达到
            if($add['price_total']<$yhq['money_lev']){
                $this->err("该优惠券不满足最低消费");
            }

            $add['price_yh']=$yhq['money_yh'];
        }
        $add['price_need_pay']=bcsub($add['price_total'],$add['price_yh'],2);
        $add['price_discount']=$add['price_total'];
        //会员折扣
        if($this->_user['user_lev_id']>0){
            $lev_discount=Db::name("deerhome_user_lev")->where("id",$this->_user['user_lev_id'])->value("discount");
            if($lev_discount>0){
                $add['price_discount_bl']=bcdiv($lev_discount,100,2);
                $add['price_discount']=bcmul($add['price_total'],$add['price_discount_bl'],2);
                $add['price_need_pay']=bcsub($add['price_discount'],$add['price_yh'],2);
            }
        }
        $add['time_add']=date("Y-m-d H:i:s");
        $add['user_name']=$addressData['user_name'];
        $add['user_phone']=$addressData['user_phone'];
        $add['address_detail']=$addressData['detail_address'];
        $add['address_title']=$addressData['address_title'];
        $add['address_address']=$addressData['address'];
        $add['latitude']=$addressData['latitude'];
        $add['longitude']=$addressData['longitude'];
        $add['note']=$note;
        $add['jz_items_id']=$item['jz_items_id'];
        $add['gg_id']=$gg_id;
        $add['item_name']=$item['b_name'];
        $add['item_gg_name']=$item['name']."/".$item['dw'];
        $add['num']=$num;

        $add['date_day']=$day;
        $add['date_time']=$time;

        $add['price_pre_fc']=\bcmul($add['price_need_pay'],$item['worker_fc_bl']/100,2);

        $add['agent_lev1_percent']=0;
        $add['agent_lev2_percent']=0;

        $fx=[];
        try{
            $fx=\Tools\AgentOrder::res($item,$this->_user);
        }catch(\Exception $e){
            $this->err($e->getMessage());
        }
        if(count($fx)>0){
            $add=array_merge($add,$fx);
        }

        $orderLog=[
            'add_time'=>date("Y-m-d H:i:s"),
            'ac_user'=>'用户',
            'note'=>"等待您付款"
        ];
        $payLog=[
            'deerhome_user_id'=>$this->_user['id'],
            'order_sn'=>$add['sn'],
            'price'=>$add['price_need_pay'],
            'add_time'=>date("Y-m-d H:i:s"),
            'payway_type'=>1
        ];
        $wallet_left=$this->_user['wallet_charge'];
        //是否使用钱包
        if($wallet==1){
            if(bccomp($wallet_left,$add['price_need_pay'],2)==-1){
                $this->err("储值卡余额不足");
            }
            $wallet_left=bcsub($wallet_left,$add['price_need_pay'],2);

            $orderLog['note']="支付成功，等待派单";

            $payLog['is_wallet']=1;
            $payLog['status']=2;
            $payLog['pay_time']=date("Y-m-d H:i:s");
            $payLog['pay_way']="储值卡支付";
            $payLog['note']="订单{$add['sn']}";
            $payLog['price']*=-1;

            $add['price_payed']=$add['price_need_pay'];
            $add['status']=2;
            //更新分佣
            if($add['agent_lev1_percent']>0){
                $add['agent_lev1_price']=bcdiv(bcmul($add['price_need_pay'],$add['agent_lev1_percent'],2),100,2);
            }
            if($add['agent_lev2_percent']>0){
                $add['agent_lev2_price']=bcdiv(bcmul($add['price_need_pay'],$add['agent_lev2_percent'],2),100,2);
            }

        }

        $orderId=0;
        Db::startTrans();
        try{
            $orderId=Db::name("deerhome_order")->insertGetId($add);
            $orderLog['order_id']=$orderId;
            Db::name("deerhome_order_log")->insert($orderLog);
            Db::name("deerhome_order_pay_log")->insert($payLog);
            //更新优惠券状态
            if($add['price_yh']>0 && $yhq_id>0){
                Db::name("deerhome_yhq")->where("id",$yhq_id)->update(['status'=>3,'order_sn'=>$add['sn'],'use_time'=>date("Y-m-d H:i:s")]);
            }
            //更新钱包余额
            if($wallet==1){
                Db::name("deerhome_user")->where("id",$add['jz_user_id'])->update([
                    "wallet_charge"=>$wallet_left
                ]);
                Db::name("deerhome_items")->where("id",$add['jz_items_id'])->setInc("sale_times",$add['num']);
            }
            Db::commit();
        }catch(\Exception $e){
            Db::rollback();
            $this->err($e->getMessage());
        }
        $this->ok(['id'=>$orderId]);
    }
    /**
     * 订单列表
    */
    public function rows(){
        $page=$this->request->param("page",1,'intval');
        $cate=$this->request->param("cate",0,'intval');

        \think\Lang::load(APP_PATH."admin/lang/zh-cn/deerhome/order.php");
        $orderModel = new \app\admin\model\deerhome\Order;

        $where=[];
        $where['o.jz_user_id']=$this->_user['id'];
        if($cate==1){
            $where['o.status']=1;
        }
        if($cate==2){
            $where['o.status']=["in",[2,3]];
        }
        if($cate==3){
            $where['o.status']=4;
        }
        if($cate==4){
            $where['o.status']=5;
            $where['o.worker_pj_star']=0;
        }
        $data=Db::name("deerhome_order")->alias("o")
        ->join("deerhome_items i","i.id=o.jz_items_id","left")
        ->field("o.*,i.face_image")
        ->where($where)
        ->order("o.id desc")->paginate(6)->each(function($item,$key)use($orderModel){
            $item['status_txt']=$orderModel->getStatusTextAttr($item['status'],$item);
            $item['face_image']=$this->fixImg($item['face_image'],true);
            $item['date_day_time']=$item['date_day']." ".$item['date_time'];
            $item['date_day_time']=\date("m-d H:i",strtotime($item['date_day_time']));
            $item['order_log']=Db::name("deerhome_order_log")->where("order_id",$item['id'])->order("id desc")->value("note");
            return $item;
        });
        if($page==1){
            $this->xcxLog("我的订单");
        }
        $this->ok($data);
    }

    public function detail(){
        $id=$this->request->param("id",0,'intval');

        \think\Lang::load(APP_PATH."admin/lang/zh-cn/deerhome/order.php");
        $orderModel = new \app\admin\model\deerhome\Order;

        $where=[];
        $where['o.jz_user_id']=$this->_user['id'];
        $where['o.id']=$id;

        $item=Db::name("deerhome_order")->alias("o")
        ->join("deerhome_items i","i.id=o.jz_items_id","left")
        ->field("o.*,i.face_image")
        ->where($where)
        ->find();
        if(!$item){
            $this->err("订单不存在");
        }
        $item['status_txt']=$orderModel->getStatusTextAttr($item['status'],$item);
        $item['face_image']=$this->fixImg($item['face_image'],true);
        $item['date_day_time']=$item['date_day']." ".$item['date_time'];
        $item['date_day_time']=\date("Y-m-d H:i",strtotime($item['date_day_time']));
        $item['date_day_time'].=" ".$this->getWeek($item['date_day']);

        $item['order_log']=Db::name("deerhome_order_log")->where("order_id",$item['id'])->order("id desc")->find();

        $item['price_discount_vip']=bcsub($item['price_total'],$item['price_discount'],2);

        $item['btn_pay_show']=0;//支付按钮
        $item['btn_add_tip']="请于服务人员协商一致后再支付，平台仅对在线支付的项目提供保障交易，切勿线下支付！";
        $item['btn_add_show']=1;//补差价按钮
        if($item['price_need_pay']!=$item['price_payed']){
            $item['btn_pay_show']=1;
        }
        if($item['status']>=5){
            $item['btn_pay_show']=0;
            $item['btn_add_show']=0;
        }
        if($item['btn_pay_show']==1){
            $item['btn_add_show']=0;
        }
        $item['btn_refund_show']=0;//退款按钮
        if($item['status']>1 && $item['status']<6){
            $item['btn_refund_show']=1;
        }

        $item['workerFace']='';
        $item['workerTel']='';
        $item['workerStar']=0;
        if($item['worker_id']>0){
            $worker=Db::name("deerhome_worker")->where("id",$item['worker_id'])->find();
            if($worker){
                $item['workerTel']=$worker['utel'];
                $item['workerFace']=$this->fixImg($worker['face_image']);
                $item['workerStar']=5;
            }
        }
        $item['imgs']=explode(",",$item['imgs']);
        $item['imgs']=array_filter($item['imgs']);
        $item['worker_imgs']=explode(",",$item['worker_imgs']);
        $item['worker_imgs']=array_filter($item['worker_imgs']);
        $this->ok($item);
    }
    /**
     * 支付前界面
    */
    public function order_pay_info(){
        $id=$this->request->param("id",0,'intval');
        $where=[];
        $where['jz_user_id']=$this->_user['id'];
        $where['id']=$id;
        $where['status']=['in',[1,2,3,4]];

        $item=Db::name("deerhome_order")
        ->field("price_need_pay,price_payed")
        ->where($where)
        ->find();
        if(!$item){
            $this->err("待支付的订单不存在");
        }
        $data=[];
        $data['price']=bcsub($item['price_need_pay'],$item['price_payed'],2);
        $data['wallet']=$this->_user['wallet_charge'];
        $data['can']=bccomp($data['wallet'],$data['price'],2)>0?1:0;
        $this->ok($data);
    }
    public function del(){
        $id=$this->request->param("id",0,'intval');
        $order=Db::name("deerhome_order")->where("id",$id)->where("jz_user_id",$this->_user['id'])->where("status",8)->find();
        if(!$order){
            $this->err("该订单不可删除");
        }
        Db::startTrans();
        try{
            Db::name("deerhome_order")->where("id",$id)->where("jz_user_id",$this->_user['id'])->where("status",8)->delete();
            Db::name("deerhome_order_log")->where("order_id",$id)->delete();
            Db::commit();
        }catch(\Exception $e){
            Db::rollback();
            $this->err($e->getMessage());
        }
        $this->ok();
    }

    public function log(){
        $id=$this->request->param("id",0,'intval');
        $data=Db::name("deerhome_order_log")->where("order_id",$id)->order("id desc")->select();
        $this->ok($data);
    }
    /**
     * 订单验收
    */
    public function accept(){
        $id=$this->request->param("id",0,'intval');
        $order=Db::name("deerhome_order")->where("id",$id)->where("jz_user_id",$this->_user['id'])->where("status","in",[3,4])->find();
        if(!$order){
            $this->err("该订单不可验收");
        }
        Db::startTrans();
        try{
            Db::name("deerhome_order")->where("id",$id)->where("jz_user_id",$this->_user['id'])->update(['status'=>5,'time_done'=>date("Y-m-d H:i:s")]);
            Db::name("deerhome_order_log")->insert([
                'order_id'=>$id,
                'add_time'=>date("Y-m-d H:i:s"),
                'ac_user'=>'用户',
                'note'=>"验收通过，订单已完成"
            ]);
            $worker=Db::name("deerhome_order")->where("worker_id",$order['worker_id'])->where("status",5)->where("worker_price_to_wallet",0)->field("SUM(`worker_price`) AS w_price,COUNT(`id`) AS w_nums")->find();
            $times=$worker['w_nums'];
            $money_dj=$worker['w_price'];
            Db::name("deerhome_worker")->where("id",$order['worker_id'])->update(['times'=>$times,'money_dj'=>$money_dj]);
            Db::commit();
        }catch(\Exception $e){
            Db::rollback();
            $this->err($e->getMessage());
        }
        try{
            \Tools\UserAndAgentLev::action($this->_user);
        }catch(\Exception $e){
        }

        $this->ok();
    }
    /**
     * 评价界面
    */
    public function evaluate_info(){
        $id=$this->request->param("id",0,'intval');
        $order=Db::name("deerhome_order")->where("id",$id)->where("jz_user_id",$this->_user['id'])->where("status",5)->find();
        if(!$order){
            $this->err("该订单不可评价");
        }
        if($order['worker_pj_star']>0){
            $this->err("该订单已评价");
        }
        $worker=Db::name("deerhome_worker")->where("id",$order['worker_id'])->find();
        if(!$worker){
            $this->err("服务人员不存在");
        }
        $data=[];
        $data['item_name']=$order['item_name'];
        $data['uname']=$worker['uname'];
        $data['face_image']=$this->fixImg($worker['face_image']);
        $this->ok($data);
    }
    /**
     * 提交评价
    */
    public function evaluate_add(){
        $id=$this->request->param("id",0,'intval');
        $imgs=$this->request->param("imgs/a",[]);
        $add=[];
        $add['worker_pj_star_status']=2;
        $add['worker_pj_star']=$this->request->param("star",5,'intval');
        $add['worker_pj_con']=$this->request->param("con","",'trim');
        $add['worker_pj_con_images']="";
        $add['worker_pj_nm']=$this->request->param("nm",0,'intval');
        $add['worker_pj_time']=\date("Y-m-d H:i:s");
        if($add['worker_pj_star']<1 || $add['worker_pj_star']>5){
            $this->err("评分错误");
        }
        if($add['worker_pj_con']==''){
            $this->err("评价内容不能为空");
        }
        if(count($imgs)>0){
            $add['worker_pj_con_images']=implode(",",$imgs);
        }
        if($add['worker_pj_nm']!=0){
            $add['worker_pj_nm']=1;
        }
        $order=Db::name("deerhome_order")->where("id",$id)->where("jz_user_id",$this->_user['id'])->where("status",5)->find();
        if(!$order){
            $this->err("该订单不可评价");
        }
        if($order['worker_pj_star']>0){
            $this->err("该订单已评价");
        }
        Db::name("deerhome_order")->where("id",$id)->update($add);
        $this->ok();
    }
    /**
     * 补差价
    */
    public function add(){
        $id=$this->request->param("id",0,'intval');
        $note=$this->request->param("note","","trim");
        $price=$this->request->param("price",0,'floatval');
        if($price<=0){
            $this->err("金额错误");
        }
        $order=Db::name("deerhome_order")->where("id",$id)->where("jz_user_id",$this->_user['id'])->where("status","<",5)->find();
        if(!$order){
            $this->err("该订单已不可补差价");
        }
        if($order['price_need_pay']>$order['price_payed']){
            $this->err("还有未付清的金额，请先付清！");
        }
        $update=[];
        $update['price_bcj']=bcadd($order['price_bcj'],$price,2);
        $update['price_total']=bcadd($order['price_total'],$price,2);
        $update['price_discount']=bcadd($order['price_discount'],$price,2);
        $update['price_need_pay']=bcadd($order['price_need_pay'],$price,2);

        //会员折扣，计算折扣前的价格
        $worker_last_price_discount=$price;
        if($order['price_discount_bl']<1){
            $worker_last_price_discount=bcdiv($price,$order['price_discount_bl'],2);
            $update['price_bcj']=bcadd($order['price_bcj'],$worker_last_price_discount,2);
            $update['price_total']=bcadd($order['price_total'],$worker_last_price_discount,2);
            $update['price_discount']=bcadd($order['price_discount'],$price,2);
            $update['price_need_pay']=bcadd($order['price_need_pay'],$price,2);
        }
        Db::startTrans();
        try {
            Db::name("deerhome_order")->where("id",$id)->update($update);
            Db::name("deerhome_order_pay_log")->insert([
                'order_sn'=>$order['sn'],
                'deerhome_user_id'=>$this->_user['id'],
                'payway_type'=>1,
                'price'=>$price,
                'note'=>$note,
                "add_time"=>date("Y-m-d H:i:s")
            ]);
            Db::commit();
        } catch (\Exception $e) {
            $this->err($e->getMessage());
        }
        $this->ok();
    }
}
