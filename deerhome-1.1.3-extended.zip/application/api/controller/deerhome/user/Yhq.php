<?php
namespace app\api\controller\deerhome\user;

use app\api\controller\deerhome\user\BaseAuth;
use think\Db;
use think\Validate;

/**
 * 优惠券
 */
class Yhq extends BaseAuth
{
    public function index()
    {
        $banner=Db::name("deerhome_design")->where("page","yhq")->find();
        $banner=json_decode($banner['con'],true);
        $banner=$banner['banner'];
        if(isset($banner['img'])){
            $banner=$this->fixImg($banner['img']);
        }
        $data=Db::name("deerhome_yhq")->where("status",1)->field("id,name,start_day,end_day,money_lev,money_yh,type,jz_cate_ids,addtime")->where("end_day",">=",date("Y-m-d"))->group("name")->order("id desc")->limit(30)->select();
        foreach($data as &$v){
            $v['have']=Db::name("deerhome_yhq")->where("jz_user_id",$this->_user['id'])->where("name",$v['name'])->where("addtime",$v['addtime'])->count();
            $v['money_lev']=intval($v['money_lev']);
            $v['money_yh']=intval($v['money_yh']);
            if($v['jz_cate_ids']=='0'){
                $v['cate']='全场券';
                $v['cateDesc']='全场通用';
                continue;
            }
            $v['cate']='指定类目';
            $cate=Db::name("deerhome_cate")->field("name")->where("id","in",$v['jz_cate_ids'])->select();
            $v['cateDesc']="仅限".implode(",",array_column($cate,"name"));
        }
        $this->xcxLog("领券中心");
        $out=[];
        $out['banner']=$banner;
        $out['list']=$data;
        $this->ok($out);
   }
    public function datalist()
    {
        $status=$this->request->param("status",2,'intval');
        $data=Db::name("deerhome_yhq")->where("status",$status)->where("jz_user_id",$this->_user['id'])->field("id,name,start_day,end_day,money_lev,money_yh,type,jz_cate_ids,addtime")->order("id desc")->limit(50)->select();
        foreach($data as &$v){
            $v['money_lev']=intval($v['money_lev']);
            $v['money_yh']=intval($v['money_yh']);
            if($v['jz_cate_ids']=='0'){
                $v['cate']='全场券';
                $v['cateDesc']='全场通用';
                continue;
            }
            $v['cate']='指定类目';
            $cate=Db::name("deerhome_cate")->field("name")->where("id","in",$v['jz_cate_ids'])->select();
            $v['cateDesc']="仅限".implode(",",array_column($cate,"name"));
        }
        $this->ok($data);
    }
    public function get()
    {
        $id=$this->request->param("id",0,'intval');
        $data=Db::name("deerhome_yhq")->where("id",$id)->find();
        if(!$data){
            $this->err("优惠券不存在");
        }
        if($data['end_day']<date("Y-m-d")){
            $this->err("优惠券已过期");
        }
        $isGet=Db::name("deerhome_yhq")->where("jz_user_id",$this->_user['id'])->where("name",$data['name'])->where("addtime",$data['addtime'])->find();
        if($isGet){
            $this->err("您已领取过该优惠券");
        }
        $row=Db::name("deerhome_yhq")->where("status",1)->where("name",$data['name'])->where("addtime",$data['addtime'])->limit(1)->update(["jz_user_id"=>$this->_user['id'],"get_time"=>date("Y-m-d H:i:s"),"status"=>2]);
        if(!$row){
            $this->err("优惠券已领完");
        }
        $this->ok();
    }
   
}
