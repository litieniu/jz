<?php
namespace app\api\controller\deerhome\user;

use app\api\controller\deerhome\user\BaseAuth;
use app\admin\model\deerhome\Card as CardModel;
use app\admin\model\deerhome\CardOrder as CardOrderModel;
use app\admin\model\deerhome\CardOrderItems as CardOrderItemsModel;
use app\admin\model\deerhome\OrderPayLog as OrderPayLogModel;
use app\admin\model\deerhome\User as UserModel;
use think\Db;
use think\Exception;
use think\Log;
use think\Validate;

/**
 * 套餐次卡订单支付
 */
class CardPay extends BaseAuth
{
    /**
     * 微信小程序支付
    */
    public function weixin_jsapi()
    {
        $id=$this->request->param("id",0,'intval');
        $data=CardOrderModel::where("id",$id)->where("status",1)->where("deerhome_user_id",$this->_user["id"])->find();
        if(!$data){
            $this->err("待支付的订单不存在");
        }
        $need_pay=(int)bcmul($data['price_need_pay'],100,0);
        $order_sn=$data['sn'];
        $options=[];
        try{
            $config=$this->getWeixinConfig();
            $payment = \WePayV3\Order::instance($config);
            $options = [
                'appid'             => $config['appid'],
                'mchid'             => $config['mch_id'],
                'description'             => $data['deerhome_card_name'],
                'out_trade_no'     => $order_sn,
                'notify_url'       => $this->notifyUrlWechat('card'),
                'amount'       => ['total' => $need_pay, 'currency' => 'CNY'],
                'payer'        => ['openid' => $this->_user['wxid']]
            ];
            $options = $payment->create('jsapi',$options);
            $prepayId=\str_ireplace("prepay_id=","",$options['package']);
        }catch(\Exception $e){
            Log::error('【微信支付拉起失败Card】'
            .$order_sn
            .'=>'
            .$e->getMessage()
            ."\n"
            .json_encode($options,JSON_UNESCAPED_UNICODE));
            $this->err($e->getMessage());
        }
        $this->ok($options);
   }
   /**
    * 储值卡支付
   */
   public function wallet()
   {
        $id=$this->request->param("id",0,'intval');
        $order=CardOrderModel::where("id",$id)->where("status",1)->where("deerhome_user_id",$this->_user["id"])->find();
        if(!$order){
            $this->err("待支付的订单不存在");
        }
        $wallet_left=bcsub($this->_user['wallet_charge'],$order['price_need_pay'],2);
        if($wallet_left<0){
            $this->err("储值卡余额不足",1);
        }

        Db::startTrans();
        try{
            $order->payed($order['sn'],'储值卡支付',date("Y-m-d H:i:s"));
            UserModel::where("id",$order['deerhome_user_id'])->update([
                "wallet_charge"=>$wallet_left
            ]);
            Db::commit();
        }catch(\Exception $e){
            Db::rollback();
            $this->err($e->getMessage(),1);
        }
        $this->ok('支付成功');
   }

    
}
