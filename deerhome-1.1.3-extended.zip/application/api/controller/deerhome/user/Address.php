<?php
namespace app\api\controller\deerhome\user;

use app\api\controller\deerhome\user\BaseAuth;
use think\Db;
use think\Validate;

/**
 * 用户地址
 */
class Address extends BaseAuth
{

    public function add()
    {
        $sex=$this->request->post("sexType");
        $add=[];
        $add['user_id']=$this->_user['id'];
        $add['address']=$this->request->post("address");
        $add['detail_address']=$this->request->post("detailAddress");
        $add['lable_name']=$this->request->post("lableName");
        $add['latitude']=$this->request->post("latitude");
        $add['longitude']=$this->request->post("longitude");
        $add['sex']='未知';
        $add['address_title']=$this->request->post("title");
        $add['user_name']=$this->request->post("userName");
        $add['user_phone']=$this->request->post("userPhone");
        $add['is_default']=$this->request->post("agreeState")?1:0;
        if($sex==1){
            $add['sex']="男";
        }
        if($sex==2){
            $add['sex']="女";
        }
        if($add['user_name']==""){
            $this->err('请填写联系人');
        }
        if (!Validate::regex($add['user_phone'], "^1\d{10}$")) {
            $this->err("请填写联系电话");
        }
        if($add['address']==""){
            $this->err('请选择地址');
        }
        if($add['detail_address']==""){
            $this->err('请填写门牌号详细地址');
        }
        if($add['latitude']=="" || $add['longitude']==""){
            $this->err('请重新选择地址');
        }
        Db::name("deerhome_user_address")->where("user_id",$add['user_id'])->update(['is_default'=>0]);
        Db::name("deerhome_user_address")->insert($add);
        $this->ok('ok');
    }
}
