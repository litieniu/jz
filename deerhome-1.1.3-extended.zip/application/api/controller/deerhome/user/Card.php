<?php
namespace app\api\controller\deerhome\user;

use app\api\controller\deerhome\user\Base;
use app\admin\model\deerhome\Card as CardModel;
use think\Db;
/**
 * 套餐次卡
 */
class Card extends Base
{
    public function cate()
    {
        $data=['0'=>'全部'];
        $data2=(new CardModel)->getTimeAreaList();
        $data=array_merge($data,$data2);
        $this->ok($data);
    }
    public function detail()
    {
        $id=$this->request->param("id",0,"intval");
        $data=(new CardModel)->with('cardItems')->where("status",1)->where("id",$id)->find();
        if(!$data){
            $this->err("套餐不存在");
        }
        (new CardModel)->where("id",$id)->setInc("view_times");
        $data['sale_times']=$data['sale_times']+$data['fake_sale_times'];
        $data['name_desc']=(new CardModel)->getTimeAreaDesc($data['time_area']);

        //判断是否是会员
        $data['is_vip']=0;
        $discount=1;
        if($this->_user){
            if($this->_user['user_lev_id']>0 && $data['vip_discount']==1){
                $data['is_vip']=1;
                $discount=Db::name("deerhome_user_lev")->where("id",$this->_user['user_lev_id'])->value("discount");
                if(!$discount){
                    $discount=1;
                }else{
                    $discount=bcdiv($discount,100,2);
                }
            }
        }

        $data['price']=bcmul($data['price'],$discount,2);
        $data['price_save']=bcsub($data['price_market'],$data['price'],2);

        $cdnurl=$this->request->domain();
        $data['body_con']=str_replace("src='/uploads/","src='". $cdnurl."/uploads/",$data['body_con']);
        $data['body_con']=str_replace("src=\"/uploads/","src=\"". $cdnurl."/uploads/",$data['body_con']);
        $data['body_con']=str_replace("src=\"/assets/","src=\"". $cdnurl."/assets/",$data['body_con']);
        
        unset($data['fake_sale_times']);
        $this->ok($data);
    }
    public function index()
    {
        $page=$this->request->param("page",1,"intval");
        $cate=$this->request->param("cate",0,"intval");
        $where=[];
        if($cate>0){
            $where['time_area']=$cate;
        }
        $data=(new CardModel)->field('id,name,face_image,price,price_market,time_area')->where("status",1)->where($where)->order("weigh desc")->page($page,10)->select();
        foreach($data as &$v){
            $v['face_image']=$this->fixImg($v['face_image']);
            $v['name_desc']=(new CardModel)->getTimeAreaDesc($v['time_area']);
            $v['price_save']=bcsub($v['price_market'],$v['price'],0);
            $v['price']=bcsub($v['price'],0,0);
        }
        $this->ok($data);
    }
     
}
