<?php
namespace app\api\controller\deerhome\user;

use app\api\controller\deerhome\user\Base;
use think\Db;
/**
 * 登录鉴权
*/
class BaseAuth extends Base
{

	public function __construct() {
        parent::__construct();
		if (!in_array($this->_deviceType, $this->_allowedDeviceTypes)) {
            $this->err('Unsupported devices');
        }
		if(!$this->_user){
			$this->err('请先登录',0,[],100);
		}
    }

}
