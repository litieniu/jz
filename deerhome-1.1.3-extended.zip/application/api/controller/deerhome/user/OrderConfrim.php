<?php
namespace app\api\controller\deerhome\user;

use app\api\controller\deerhome\user\BaseAuth;
use think\Db;
use think\Validate;

/**
 * 订单接口
 */
class OrderConfrim extends BaseAuth
{
    public function index()
    {
        $gg_id = $this->request->param("gg_id","");
        $day = $this->request->param("day","");
        $time = $this->request->param("time","");
        $num = $this->request->param("num",1,"intval");
        $data=[];
        $data['address']=Db::name("deerhome_user_address")->where("user_id",$this->_user['id'])->order("is_default desc")->find();
        if(!$data['address']){
            $data['address']['id']=0;
        }
        $data['info']=Db::name("deerhome_items_gg")->alias("g")
        ->join("deerhome_items i","i.id=g.jz_items_id","left")
        ->field("g.*,i.name as b_name,i.face_image,i.cate_id")
        ->where("g.hash",$gg_id)
        ->where("i.status",1)
        ->find();
        if(!$data['info']){
            $this->err('商品不存在或已下架');
        }
        $data['info']['face_image']=$this->fixImg($data['info']['face_image']);

        $config=$this->getConfig("sys");
        $price_yj=(float)$config['jtf'];
        //夜间交通费
        $data['price_yj']=0;
        if($time){
            $time=(int)\str_replace(":","",$time);
            if($time>=1800){
                $data['price_yj']=$price_yj;
            }
        }
        $data['price']=$data['info']['price'];
        $data['price']=bcmul($data['price'],$num,2);
        $data['price']=bcadd($data['price'],$data['price_yj'],2);
        $data['price_vip_zk']=0;
        //会员折扣
        if($this->_user['user_lev_id']>0){
            $discount=Db::name("deerhome_user_lev")->where("id",$this->_user['user_lev_id'])->value("discount");
            if($discount){
                $discount=bcdiv($discount,100,2);
                $leftPrice=bcmul($data['price'],$discount,2);
                $data['price_vip_zk']=bcsub($data['price'],$leftPrice,2);
                $data['price']=$leftPrice;
            }
        }
        
        

        //服务类目父级id
        $cate_pid=Db::name("deerhome_cate")->where("id",$data['info']['cate_id'])->value("cate_id");
        if($cate_pid==0){
            $cate_pid=$data['info']['cate_id'];
        }
        $data['yhq_tip']="无可用";
        //优惠券
        $data['coupon']=Db::name("deerhome_yhq")->where("status",2)->where("jz_user_id",$this->_user['id'])->field("id,name,start_day,end_day,money_lev,money_yh,type,jz_cate_ids,addtime")->order("money_yh desc")->limit(50)->select();
        foreach($data['coupon'] as &$v){
            $v['canuse']=0;
            $v['money_lev']=intval($v['money_lev']);
            $v['money_yh']=intval($v['money_yh']);
            
            if($v['jz_cate_ids']=='0'){
                $v['cate']='全场券';
                $v['cateDesc']='全场通用';
                //校验金额是否达到
                if($data['price']>=$v['money_lev']){
                    $v['canuse']=1;
                    $data['yhq_tip']="选择优惠券";
                }
                //校验是否在有效期
                if($v['start_day']>date('Y-m-d') || $v['end_day']<date('Y-m-d')){
                    $v['canuse']=0;
                }
                continue;
            }
            $v['cate']='指定类目';
            $cate=Db::name("deerhome_cate")->field("name")->where("id","in",$v['jz_cate_ids'])->select();
            $v['cateDesc']="仅限".implode(",",array_column($cate,"name"));
            //校验类目是否可用优惠券
            if(strpos($v['jz_cate_ids'],",".$cate_pid.",")!==false){
                $v['canuse']=1;
                //校验金额是否达到
                if($data['price']<$v['money_lev']){
                    $v['canuse']=0;
                }
            }
            //校验是否在有效期
            if($v['start_day']>date('Y-m-d') || $v['end_day']<date('Y-m-d')){
                $v['canuse']=0;
            }
         
            if($v['canuse']==1){
                $data['yhq_tip']="选择优惠券";
            }
        }
        $data['wallet']='1';
        $data['wallet_left']=$this->_user['wallet_charge'];
        $this->ok($data);
    }
}
