<?php
namespace app\api\controller\deerhome\user;

use app\api\controller\deerhome\user\BaseAuth;
use think\Db;
use think\Validate;
use think\Log;
/**
 * 储值卡
 */
class Wallet extends BaseAuth
{
    
    public function index()
    {
        $this->xcxLog("储值卡");
        $data=[];
        $data['wallet_left']=$this->_user['wallet_charge'];
        $data['list']=Db::name("deerhome_sys_charge")->field("id,price,give")->order("price asc")->select();
        $data['article_id']=3;
        $this->ok($data);
    }
    public function log()
    {
        $month=$this->request->param("month","",'trim');
        $where=[];
        $where['deerhome_user_id']=$this->_user['id'];
        $where['is_wallet']="1";
        $where['status']="2";
       
        if(preg_match("/^\d{4}-\d{2}$/",$month)){
            $where['pay_time']=['like',$month.'%'];
        }
        $data=Db::name("deerhome_order_pay_log")->where($where)->order("id desc")->paginate(10)->each(function($item, $key){
            $item['time']=date("m-d H:i",strtotime($item['pay_time']));
            $item['price']=bcadd($item['price'],$item['give'],2);
            $item['price']=(($item['price']>0)?"+":"") .$item['price'];
            return $item;
        });
        $this->ok($data);
    }
    public function charge(){
        $id=$this->request->post("id",0,"intval");
        $info=Db::name("deerhome_sys_charge")->where("id",$id)->find();
        if(!$info){
            $this->err("充值套餐不存在");
        }
        $give=$info['give'];
        $price=$info['price'];
        $money=bcadd($price,$give,2);
        if($price<=0){
            $this->err("充值金额不正确");
        }
        if($money<=0){
            $this->err("充值金额不正确");
        }
        $add=[
            'deerhome_user_id'=>$this->_user['id'],
            'type'=>2,
            'is_wallet'=>1,
            'status'=>1,
            'price'=>$price,
            'give'=>$give,
            'payway_type'=>1,
            'pay_way'=>"微信支付",
            'note'=>"充值￥{$price}，赠款￥{$give}，实际到账￥{$money}",
            'add_time'=>\date("Y-m-d H:i:s"),
        ];
        $res=Db::name("deerhome_order_pay_log")->insertGetId($add);
        $this->ok(['id'=>$res]);
    }
    public function weixin_jsapi()
    {
        $id=$this->request->param("id",0,'intval');
        
        $log=Db::name("deerhome_order_pay_log")->where("deerhome_user_id",$this->_user['id'])->where("id",$id)->where("payway_type",1)->where("is_wallet",1)->where("status",1)->find();
        if(!$log){
            $this->err("该比交易不存在");
        }
        $order_sn="VIP-CARD-S".$log['id'];
        $need_pay=$log['price'];
        $need_pay=(int)bcmul($need_pay,100,0);
        $options=[];
        try{
            $config=$this->getWeixinConfig();
            $payment = \WePayV3\Order::instance($config);
            $options = [
                'appid'             => $config['appid'],
                'mchid'             => $config['mch_id'],
                'description'             => "储值卡充值",
                'out_trade_no'     => $order_sn,
                'notify_url'       => $this->notifyUrlWechat('wallet'),
                'amount'       => ['total' => $need_pay, 'currency' => 'CNY'],
                'payer'        => ['openid' => $this->_user['wxid']]
            ];
            $options = $payment->create('jsapi',$options,$log['prepay_id']);
            $prepayId=\str_ireplace("prepay_id=","",$options['package']);
            Db::name("deerhome_order_pay_log")->where("id",$log['id'])->update(['prepay_id'=>$prepayId]);
        }catch(\Exception $e){
            Log::error('【微信支付拉起失败】'
            .$order_sn
            .'=>'
            .$e->getMessage()
            ."\n"
            .json_encode($options,JSON_UNESCAPED_UNICODE));
            $this->err($e->getMessage());
        }
        $this->ok($options);
    }
}
