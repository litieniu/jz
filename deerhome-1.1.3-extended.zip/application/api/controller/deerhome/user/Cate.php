<?php
namespace app\api\controller\deerhome\user;

use app\api\controller\deerhome\user\Base;
use think\Db;
/**
 * 服务分类
 */
class Cate extends Base
{

    public function index()
    {
        $res=Db::name("deerhome_cate")->field("id,name,ad_image,ad_image_ac")->where("cate_id",0)->where("status",1)->order("weigh asc")->select();
        foreach ($res as $key => &$value) {
            $value['ad']['img']="";
            $value['ad']['ac']="";
            if($value['ad_image']){
                $value['ad']['img']=$this->fixImg($value['ad_image']);
                $value['ad']['ac']=\json_decode($value['ad_image_ac'],true);
            }
            unset($value['ad_image']);
            unset($value['ad_image_ac']);
            $value['son']=Db::name("deerhome_cate")->field("id,name,face_image")->where("cate_id",$value['id'])->where("status",1)->order("weigh asc")->select();
            foreach($value['son'] as &$v){
                if($v['face_image']){
                    $v['face_image']=$this->fixImg($v['face_image']);
                }
            }
        }
        $this->xcxLog("分类页");
        $this->ok($res);
    }
    public function son()
    {
        $id=$this->request->param("id",0,'intval');
        $res=Db::name("deerhome_cate")->field("id,name,face_image")->where("cate_id",$id)->where("status",1)->order("weigh asc")->select();
        foreach ($res as $key => &$v) {
            $v['face_image']=$this->fixImg($v['face_image']);
        }
        $recommend=[
            "id"=>0,
            "name"=>"精选服务",
            "face_image"=>$this->fixImg("/assets/addons/deerhome/img/icon_jx.png")
        ];
        $res=\array_merge([$recommend],$res);
        $this->ok($res);
    }
    public function itemList()
    {
        $id = $this->request->post("id",0);
        $fid = $this->request->post("fid",0);
        $key = $this->request->post("key","");
        $sort = $this->request->post("sort","");
        $tabIndex = $this->request->post("tabIndex",0);
        $order="weigh";
        $orderWay="asc";

        if($tabIndex==0){
            if($sort=="价格升序"){
                $order="price";
                $orderWay="asc";
            }
            if($sort=="价格降序"){
                $order="price";
                $orderWay="desc";
            }
        }
        if($tabIndex==1){
            $order="sale_times";
            $orderWay="desc";
        }

        $where=[];
        
        if($id>0){
            $where["cate_id"]=$id;
            $key="";
        }else{
            if($fid>0){
                $sonIdArr=Db::name("deerhome_cate")->where("cate_id",$fid)->where("status",1)->column("id");
                $where["cate_id"]=["in",$sonIdArr];
                $key="";
            }
            if($id==0){
                $where["recommend"]=1;
            }
        }
        if($key!=""){
            $where=[];
            $where["name"]=["like","%{$key}%"];
        }
        $where["status"]=1;
        $res=Db::name("deerhome_items")->field("id,cate_id,name,face_image,price,sale_times,fake_sale_times,recommend")->where($where)->order("{$order} {$orderWay}")->paginate(10)->each(function($item,$key){
            $item['face_image']=$this->fixImg($item['face_image'],true);
            $item['sale']="已售".($item['sale_times']+$item['fake_sale_times']);
            $item['good']=$this->getItemRate($item['id'])."好评";
            return $item;
        });
        $this->ok($res);
    }
}
