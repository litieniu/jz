<?php

namespace app\api\controller\deerhome\user;

use app\api\controller\deerhome\user\Base;
use think\Db;
use app\admin\model\deerhome\Items as ItemsModel;
use app\admin\model\deerhome\Card as CardModel;
use app\admin\model\deerhome\CardItems as CardItemsModel;
/**
 * 商品详情
 */
class Item extends Base
{
    public function index()
    {
        $id = $this->request->param("id");
        $data=[];
        $data['detail']=Db::name("deerhome_items")->where("id",$id)->where("status",1)->find();
        if(!$data['detail']){
            $this->err('商品不存在或已下架',1);
        }
        $data['detail']['face_image']=$this->fixImg($data['detail']['face_image']);
        $data['video']=$this->fixImg($data['detail']['video_file']);
        $data['video_face_image']=$this->fixImg($data['detail']['video_face_image']);
        $data['video_time']="视频";//00′30″
        $data['banner']=[];
        if($data['detail']['img_images']){
            $data['banner']=explode(",",$data['detail']['img_images']);
            $data['banner']=array_filter($data['banner']);
            foreach ($data['banner'] as $key => &$value) {
                $value=$this->fixImg($value);
            }
        }
        $cdnurl=$this->request->domain();
        $data['detail_body_con']=$data['detail']['body_con'];
        $data['detail_body_con']=\htmlspecialchars_decode($data['detail_body_con']);
        $data['detail_body_con']=str_replace("src='/uploads/","src='". $cdnurl."/uploads/",$data['detail_body_con']);
        $data['detail_body_con']=str_replace("src=\"/uploads/","src=\"". $cdnurl."/uploads/",$data['detail_body_con']);
        $data['detail_body_con']=str_replace("src=\"/assets/","src=\"". $cdnurl."/assets/",$data['detail_body_con']);
        unset($data['detail']['body_con']);

        //判断是否是会员
        $data['is_vip']=0;
        $discount=1;
        if($this->_user){
            if($this->_user['user_lev_id']>0){
                $data['is_vip']=1;
                $discount=Db::name("deerhome_user_lev")->where("id",$this->_user['user_lev_id'])->value("discount");
                if(!$discount){
                    $discount=1;
                }else{
                    $discount=bcdiv($discount,100,2);
                }
            }
        }

        $data['gg']=Db::name("deerhome_items_gg")->where("jz_items_id",$id)->order("price asc")->select();
        foreach($data['gg'] as &$v6){
            $v6['price_vip']=$v6['price'];
            if($discount<1){
                $v6['price_vip']=bcmul($v6['price'],$discount,2);
            }
        }

        //查找关联次卡
        $data['card']=CardItemsModel::with(['card'=>function($query){
            $query->where("item_show",1)->where("status",1);
        }])->where("deerhome_items_id",$id)->select();
        foreach($data['card'] as &$v8){
            $v8['card']['price']=bcmul($v8['card']['price'],$discount,2);
            $v8['card']['price_save']=bcsub($v8['card']['price_market'],$v8['card']['price'],0);
        }

        $data['price']=$data['gg'][0]['price'];
        $data['gg_id']=$data['gg'][0]['hash'];
        $price=explode(".",$data['gg'][0]['price_vip']);
        $data['price1']=$price[0];
        $data['price2']=".".$price[1];

        $data['hpd']="好评度".$this->getItemRate($id);
        $data['sale']="销量".($data['detail']['sale_times']+$data['detail']['fake_sale_times']);
        $data['tags']=[];
        $config=$this->getConfig("sys");
        $item_bz=$config['item_bz'];
        $data['tags']=explode(",",$item_bz);
        $data['tags']=array_filter($data['tags']);

        $data['pj']=[];
        $pj=Db::name("deerhome_order")->alias('o')->join("deerhome_user u","u.id=o.jz_user_id","left")
        ->field("u.face_image,u.uname,o.item_name,o.worker_pj_star,o.worker_pj_con,o.worker_pj_con_images,o.worker_pj_nm")
        ->where("o.jz_items_id",$id)->where("o.worker_pj_star_status",1)->where("o.worker_pj_star",">",0)->order("o.worker_pj_time desc")->limit(3)->select();
        foreach($pj as $v){
            $v['face_image']=$this->fixImg($v['face_image']);
            $v['worker_pj_con_images']=explode(",",$v['worker_pj_con_images']);
            foreach($v['worker_pj_con_images'] as $k2=>$v2){
                $v['worker_pj_con_images'][$k2]=$this->fixImg($v2);
            }
            array_push($data['pj'],$v);
        }

        Db::name("deerhome_items")->where("id",$id)->setInc("view_times");

        $data['collected']=0;
        //是否收藏
        if($this->_user){
            $data['collected']=Db::name("deerhome_user_collected")->where("type",1)->where("jz_user_id",$this->_user['id'])->where("jz_items_id",$id)->count();

            Db::name("deerhome_user_collected")->where("type",2)->where("jz_user_id",$this->_user['id'])->where("jz_items_id",$id)->delete();
           
            Db::name("deerhome_user_collected")->insert(["jz_user_id"=>$this->_user['id'],"jz_items_id"=>$id,"add_time"=>date("Y-m-d H:i:s"),"type"=>2]);
        }

        $this->xcxLog("产品页-".$data['detail']['name']);
        $this->ok($data);
    }
    
    public function itemList()
    {
        $id = $this->request->post("id");
        $key = $this->request->post("key");
        $order="id";
        $orderWay="desc";
        $where=[];
        $where["status"]=["=","1"];
        $res=Db::name("deerhome_items")->field("id,cate_id,name,face_image,price,recommend,fake_sale_times,sale_times")->where($where)->order("{$order} {$orderWay}")->paginate(12)->each(function($item,$key){
            $item['face_image']=$this->fixImg($item['face_image'],true);
            $item['sale']="已售".($item['sale_times']+$item['fake_sale_times']);
            $item['good']=$this->getItemRate($v['id'])."好评";
            return $item;
        });
        $this->success('ok', $res);
    }
    
}
