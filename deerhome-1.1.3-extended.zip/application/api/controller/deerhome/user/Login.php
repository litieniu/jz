<?php
namespace app\api\controller\deerhome\user;
use think\Db;
use app\api\controller\deerhome\user\Base;

class Login extends Base
{

    protected $noNeedLogin = ['*']; 
	public $hash="Ta1#o%dgiP4%kpb";

    public function info()
    {
		$data=[];
		$data['logo']=$this->getXcxLogo();
		$data['title']=$this->getXcxName();
		$data['article1']=Db::name("deerhome_article")->where("cate",1)->where("name","隐私政策")->value("id");
		$data['article2']=Db::name("deerhome_article")->where("cate",1)->where("name","用户协议")->value("id");
		$this->ok($data);
	}
    public function index()
    {
		$tel = $this->request->param('tel','','trim');
		$openid = $this->request->param('openid','','trim');
		$hash = $this->request->param('hash','','trim');
		$code = $this->request->param('code','','trim');
		$token = md5($this->hash.time().$tel);
		if(!preg_match("/^1\d{10}$/", $tel)){
			$this->err('手机号格式不正确');
		}
		if($code=="" && $hash=="" && $openid==""){
			$this->err('参数错误');
		}
		if(!preg_match("/^[a-z0-9_-]{10,40}$/i", $openid)){
			$this->err('openid格式不正确');
		}
		//微信授权手机号登录
		if($hash){
			if(md5($this->hash.$tel)!=$hash){
				$this->err('非法操作，请关闭页面重试');
			}
		}else{
		//验证码登录
		}

		$res = Db::name('deerhome_user')->where('wxid',$openid)->find();
		if($res){
			$map=[];
			$map['token'] = $token ;
			if($res['utel']==""){
				$map['utel'] = $tel ;
			}
			Db::name('deerhome_user')->where('id',$res['id'])->update($map);
		}else{
			$add=Db::name("deerhome_user")->insertGetId([
				'utel'=>$tel
				,'uname'=>\substr_replace($tel,'****',3,4)
				,'face_image'=>$this->fixImg("/assets/addons/deerhome/img/defalut_face.png")
				,'token'=>$token
				,'wxid'=>$openid
				,'regtime'=>\date('Y-m-d H:i:s')
				,'last_time'=>\date('Y-m-d H:i:s')
			]);
		}
        
		$data = [
			'token'=>$token
		];
		$this->ok($data);
    }
	public function wxbd(){
		$code=$this->request->param('code','','trim');
		$wxid=$this->request->param('wxid','','trim');
		$res=[];
		try{
			$config = $this->getWeixinConfig();
			$mini = \WeMini\Crypt::instance($config);
			$res=$mini->session($code);
			if(isset($res['errcode'])){
				if($res['errcode']!=0){
					throw new \Exception($res['errmsg']);
				}
			}
		}catch(\Exception $e){
			$this->err("小程序配置错误：".$e->getMessage(),1);
		}
		$isExit = Db::name('deerhome_user')->where('wxid',$res['openid'])->find();
		if(!$isExit){
			$agent_lev1_uid=0;
			$agent_lev2_uid=0;

			//如果是分享进入
			if($wxid){
				$agent=Db::name("deerhome_user")->field("id,agent_lev1_uid")->where("wxid",$wxid)->find();
				if($agent){
					$agent_lev1_uid=$agent['id'];
					$agent_lev2_uid=$agent['agent_lev1_uid'];
				}
			}

			$add=Db::name("deerhome_user")->insertGetId([
				'uname'=>"微信用户"
				,'face_image'=>$this->fixImg("/assets/addons/deerhome/img/defalut_face.png")
				,'wxid'=>$res['openid']
				,'regtime'=>\date('Y-m-d H:i:s')
				,'last_time'=>\date('Y-m-d H:i:s')
				,'agent_lev1_uid'=>$agent_lev1_uid
				,'agent_lev2_uid'=>$agent_lev2_uid
			]);
			//自动升级推广人等级
			try{
				\Tools\UserAndAgentLev::actionAgentById($agent_lev1_uid);
			}catch(\Exception $e){
			}
		}else{
			Db::name("deerhome_user")->where("id",$isExit['id'])->update(['last_time'=>date("Y-m-d H:i:s")]);
		}
		$this->ok(["openid"=>$res['openid']]);
	}
	/**
	 * 微信手机号快捷登录
	*/
	public function bywxtel(){
		$code=$this->request->param('code','','trim');
		$encryptedData=$this->request->param('encryptedData','','trim');
		$iv=$this->request->param('iv','','trim');
		$res=[];
		try{
			$config = $this->getWeixinConfig();
			$mini = \WeMini\Crypt::instance($config);
			$res=$mini->getPhoneNumber($code);
			if($res['errcode']!=0){
				throw new \Exception($res['errmsg']);
			}
		}catch(\Exception $e){
			$this->err($e->getMessage());
		}
		$data=[];
		$data['tel']=$res['phone_info']['purePhoneNumber'];
		$data['hash']=md5($this->hash.$data['tel']);;
		$this->ok($data);
	}

}
