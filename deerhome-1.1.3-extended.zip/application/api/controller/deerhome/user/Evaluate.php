<?php
namespace app\api\controller\deerhome\user;

use app\api\controller\deerhome\user\Base;
use think\Db;
use think\Validate;

/**
 * 评价
 */
class Evaluate extends Base
{
    public function index()
    {
        $id=$this->request->param("id",0,"intval");
        $cate=$this->request->param("cate",0,"intval");
        $data=[];
        $data['info']=[];
        $data['info']['all']=Db::name("deerhome_order")->where("worker_pj_star_status",1)->where("jz_items_id",$id)->where("worker_pj_star",">",0)->count();
        $data['info']['hp']=Db::name("deerhome_order")->where("worker_pj_star_status",1)->where("jz_items_id",$id)->where("worker_pj_star",5)->count();
        $data['info']['cp']=Db::name("deerhome_order")->where("worker_pj_star_status",1)->where("jz_items_id",$id)->where("worker_pj_star",">",0)->where("worker_pj_star",'<',3)->count();
        $data['info']['pic']=Db::name("deerhome_order")->where("worker_pj_star_status",1)->where("jz_items_id",$id)->where("worker_pj_star",">",0)->where("worker_pj_con_images <> '' ")->count();
        $data['info']['hpl']="100%";
        if($data['info']['all']>0){
            $data['info']['hpl']=round($data['info']['hp']/$data['info']['all']*100,2)."%";
        }
        $where=[];
        $where['o.jz_items_id']=$id;
        $where['o.worker_pj_star_status']=1;
        if($cate==1){
            $where['o.worker_pj_star']=['=',5];
        }
        if($cate==2){
            $where['o.worker_pj_star']=[">",0];
            $where['o.worker_pj_star']=["<",3];
        }
        if($cate==3){
            $where['o.worker_pj_star']=[">",0];
            $where['o.worker_pj_con_images']=['<>',''];
        }
        $data['list']=Db::name("deerhome_order")->alias('o')->join("deerhome_user u","u.id=o.jz_user_id","left")
        ->field("u.face_image,u.uname,o.item_name,o.worker_pj_star,o.worker_pj_con,o.worker_pj_con_images,o.worker_pj_nm,o.worker_pj_time")
        ->where($where)->where("o.worker_pj_star",">",0)->order("o.worker_pj_time desc")->limit(80)->select();
        foreach($data['list'] as &$v){
            $v['face_image']=$this->fixImg($v['face_image']);
            $v['worker_pj_con_images']=explode(",",$v['worker_pj_con_images']);
            $v['worker_pj_con_images']=array_filter($v['worker_pj_con_images']);
            foreach($v['worker_pj_con_images'] as $k2=>$v2){
                $v['worker_pj_con_images'][$k2]=$this->fixImg($v2);
            }
            $v['worker_pj_time']=date("Y-m-d",strtotime($v['worker_pj_time']));
        }
        $this->ok($data);
    }
     
}
