<?php
namespace app\api\controller\deerhome\user;

use app\api\controller\deerhome\user\BaseAuth;
use think\Db;
use think\Validate;

/**
 * 发票
 */
class Fp extends BaseAuth
{
    public function index()
    {
        $type=$this->request->param("type",0,'intval');
        $where=[];
        $where['jz_user_id']=["=",$this->_user['id']];
        $where['status']=5;
        if($type==0){
            $where['fapiao']=0;
        }else{
            $where['fapiao']=[">",0];
        }
        $data=Db::name("deerhome_order")->where($where)->field("id,sn,num,item_name as gname,price_need_pay as price,fapiao")->order("id desc")->limit(50)->select();
        foreach($data as &$v){
            $v['fapiao_txt']='待开票';
            if($v['fapiao']>0){
                $fp=Db::name("deerhome_fapiao")->field("status,file")->where("id",$v['fapiao'])->find();
                if($fp){
                    if($fp['status']==1){
                        $v['fapiao_txt']="开票中";
                    }
                    if($fp['status']==2){
                        $v['fapiao_txt']="已开票";
                        $v['url']=$this->fixImg($fp['file']);
                    }
                }
            }
        }
        $this->xcxLog("开具发票");
        $this->ok($data);
   }
   public function info(){
        $ids=$this->request->param("ids","","trim");
        $ids=explode(",",$ids);
        if(count($ids)==0){
            $this->error("没有选中订单");
        }
        $where=[];
        $where['jz_user_id']=["=",$this->_user['id']];
        $where['status']=["=",5];
        $where['fapiao']=["=",0];
        $where['id']=["in",$ids];
        $price_payed=Db::name("deerhome_order")->where($where)->sum('price_need_pay');
        $price_payed=bcmul($price_payed,1,2);

        $data=[];
        $data['price']=$price_payed;
        $data['fp']=Db::name("deerhome_fapiao")->where("jz_user_id",$this->_user['id'])->order("id desc")->find();
        $this->ok($data);
    }
    public function sub(){
        $ids=$this->request->param("ids","","trim");
        $ids=explode(",",$ids);
        if(count($ids)==0){
            $this->err("没有选中订单");
        }
        $data=[];
        $data['price']=$this->request->param("price","","trim");
        $data['name']=$this->request->param("tt","","trim");
        $data['type']=$this->request->param("type","","trim");
        $data['code']=$this->request->param("code","","trim");
        $data['jz_user_id']=$this->_user['id'];
        $data['add_time']=date("Y-m-d H:i:s");

        if($data['name']==''){
            $this->err("请填写发票抬头");
        }
        if($data['type']==2 && $data['code']=="")
        {
            $this->err("请填写纳税人识别号");
        }
        $where=[];
        $where['jz_user_id']=["=",$this->_user['id']];
        $where['status']=["=",5];
        $where['fapiao']=["=",0];
        $where['id']=["in",$ids];
        $orders=Db::name("deerhome_order")->field("id,sn,price_need_pay")->where($where)->select();
       
        if(count($orders)!=count($ids)){
            $this->err("网络传输异常，请重新选择订单");
        }
        $price=0;
        $sn=[];
        foreach ($orders as $key => $value) {
            $sn[]=$value['sn'];
            $price=bcadd($price,$value['price_need_pay'],2);
        }
        $data['orders']=implode(",",$sn);
        $data['price']=$price;

        Db::startTrans();
        try {
            $id=Db::name("deerhome_fapiao")->insertGetId($data);
            Db::name("deerhome_order")->where("sn","in",$sn)->update(["fapiao"=>$id]);
            Db::commit();
        } catch (\Exception $e) {
            Db::rollback();
            $this->err($e->getMessage());
        }
        $this->ok("ok");
    }
}
