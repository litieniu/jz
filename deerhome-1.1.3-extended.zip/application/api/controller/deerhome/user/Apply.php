<?php
namespace app\api\controller\deerhome\user;

use app\api\controller\deerhome\user\BaseAuth;
use think\Db;
use think\Validate;

/**
 * 技师入驻申请
 */
class Apply extends BaseAuth
{
    
    public function index()
    {
        $this->xcxLog("申请入驻页");
        $data=[];
        $data['page']='apply';
        $data['tel']=$this->_user['utel'];
        $data['city']=[];
        $data['list']=[];
        $isExit=Db::name("deerhome_worker_sh")->where("jz_user_id",$this->_user['id'])->where("status",1)->find();
        if($isExit){
            $data['page']='wait';
            $this->ok($data);
        }
        
        $isOk=Db::name("deerhome_worker")->where("utel",$this->_user['utel'])->find();
        if($isOk){
            $data['page']='ok';
            $this->ok($data);
        }
        if($data['page']=="apply"){
            $banner=Db::name("deerhome_design")->where("page","apply")->find();
            $banner=json_decode($banner['con'],true);
            $banner=$banner['banner'];
            if(isset($banner['img'])){
                $banner=$this->fixImg($banner['img']);
            }
            $data['banner']=$banner;
            $data['city']=Db::name("deerhome_open_city")->select();
            $data['list']=Db::name("deerhome_cate")->where("can_apply",1)->where("status",1)->where("cate_id",0)->field("id,name")->select();
        }
        $this->ok($data);
    }
    public function add()
    {
        $id=$this->request->param("id",0,'intval');
        $address=$this->request->param("address/a",[]);
        $jz_cate_ids=$this->request->param("cate/a",[]);
        if(count($jz_cate_ids)==0){
            $this->err("请选择服务项目");
        }
        if(!isset($address['title']) || !isset($address['address']) || !isset($address['latitude']) || !isset($address['longitude'])){
            $this->err("请选择您的定位地址");
        }
        $jz_cate_ids='0,'.implode(",",$jz_cate_ids).',0';
        $add=[];
        $add['idcard']=$this->request->param("idcard","",'trim');
        $add['uname']=$this->request->param("name","",'trim');
        $add['jz_user_id']=$this->_user['id'];
        $add['utel']=$this->_user['utel'];
        $add['jz_cate_ids']=$jz_cate_ids;
        $add['sfz_a_image']=$this->request->param("sfz_a","",'trim');
        $add['sfz_b_image']=$this->request->param("sfz_b","",'trim');
        $add['zs_image']=$this->request->param("yszz","",'trim');
        $add['note']=$this->request->param("note","",'trim');
        $add['city']=$this->request->param("city_tip","",'trim');
        $add['address_title']=$address['title'];
        $add['address']=$address['address'];
        $add['latitude']=$address['latitude'];
        $add['longitude']=$address['longitude'];
        $add['add_time']=\date("Y-m-d H:i:s");
        if($add['uname']==''){
            $this->err("请输入姓名");
        }
        if($add['idcard']==''){
            $this->err("请输入身份证号码");
        }
        if($add['sfz_a_image']=='' || $add['sfz_b_image']==''){
            $this->err("请上传身份证照片");
        }
        if($add['city']==""){
            $this->err("请选择城市");
        }
        $isExit=Db::name("deerhome_worker_sh")->where("jz_user_id",$this->_user['id'])->where("status",1)->find();
        if($isExit){
            $this->err("您已经提交过申请，请耐心等待审核");
        }
        Db::name("deerhome_worker_sh")->insert($add);
        $this->ok();
    }
}
