<?php
namespace app\api\controller\deerhome\user;

use app\common\controller\Api;
use think\Db;
/**
 * 基础类
*/
class Base extends Api
{
	protected $noNeedLogin = ['*']; 
    protected $_user;
    protected $_token;
    protected $_openid;
    protected $_deviceType;
    protected $_version;
    protected $_allowedDeviceTypes=["wxapp","ios","android","h5"];

	public function __construct() {
        parent::__construct();
        $this->_token = $this->request->header('Deer-Api-Token');
        $this->_openid = $this->request->header('Deer-Api-Openid','');
        $this->_version = $this->request->header('Deer-Api-Version');
        $this->_deviceType = strtolower($this->request->header('Deer-Device-Type'));

        //第三方通知不校验
        if(stripos($this->request->controller(),"notify")!==false){
            return;
        }

        $this->_initUser();
    }
	private function _initUser(){
        if (empty($this->_token)) {
            return ;
        }
        $user=Db::name("deerhome_user")
        ->where("token",$this->_token)->find();
        if($user){
            $this->_user = $user;
        }
    }

	public function ok($data = [],$msg = 'success'){
        $arr=[];
        $arr['code']=0;
        $arr['msg']=$msg;
        $arr['data']=$data;
		echo json_encode($arr);
		exit;
	}
	public function err($msg = 'error',$alert=0,$data = [],$code = 1){
        $arr=[];
        $arr['code']=$code;
        $arr['msg']=$msg;
        $arr['data']=$data;
        $arr['alert']=$alert;
		echo json_encode($arr);
		exit;
	}
    protected function fixImg($img,$face=false){
        if($img==""){
            return '';
        }
        $cdnurl=\think\Config::get('upload.cdnurl');
        if(!$cdnurl){
            if(substr(strtolower($img),0,4)!="http"){
                return $this->request->domain().$img;
            }
            return $img;
        }
        if(strpos($img,$cdnurl)===0 && $face){
            return $img."!item";
        }
        if(strpos($img,"http")===0){
            return $img;
        }
        if(substr(strtolower($img),0,4)!="http" && $face){
            return $cdnurl.$img."!item";
        }
        return cdnurl($img, true);
    }
    //返回周几
    protected function getWeek($date,$dw="周"){
        $weekarray=array("日","一","二","三","四","五","六");
        return $dw.$weekarray[date("w",strtotime($date))];
    }
    //获取小程序Logo
    protected function getXcxLogo(){
        $xcx=$this->getConfig("sys");
        if(isset($xcx['login_logo']) && $xcx['login_logo']!=""){
            return $this->fixImg($xcx['login_logo']);
        }
        return "未设置名称";
    }
    //获取小程序名称
    protected function getXcxName(){
        $xcx=$this->getConfig("sys");
        if(isset($xcx['xcxtitle']) && $xcx['xcxtitle']!=""){
            return $xcx['xcxtitle'];
        }
        return "未设置名称";
    }
    //获取商品好评度
    protected function getItemRate($id){
        $total=Db::name("deerhome_order")->where("worker_pj_star",'>',0)->where("jz_items_id",$id)->count();
        if($total==0){
            return '100%';
        }
        $hp=Db::name("deerhome_order")->where("worker_pj_star",'>',2)->where("jz_items_id",$id)->count();
        return round($hp/$total*100)."%";
    }
    //支付回调地址,$type 为空表示订单支付，wallet为储值卡支付
    protected function notifyUrlWechat($type=''){
        if($type=="wallet"){
            return $this->request->domain()."/api/deerhome.user.notify_wallet/index/";
        }
        if($type=="card"){
            return $this->request->domain()."/api/deerhome.user.notify_card/index/";
        }
        return $this->request->domain()."/api/deerhome.user.notify/index/";
    }
    //微信配置
    protected function getWeixinConfig(){
        return $this->getConfig("xcx_config");
    }
    //获取系统配置
    protected function getConfig($platform){
        $data=Db::name("deerhome_xcxpz")->where("platform",$platform)->find();
        if(!$data){
            $this->err("没有配置信息");
        }
        return \json_decode($data['con'],true);
    }
    //用户页面日志
    protected function xcxLog($note,$type=3){
        if($this->_user){
            $user=$this->_user;
        }else{
            $user=Db::name("deerhome_user")
            ->where("wxid",$this->_openid)->find();
            if(!$user){
                return false;
            }
        }
        
        return Db::name("deerhome_user_collected")->insert([
            "jz_user_id"=>$user['id'],
            "type"=>$type,
            "note"=>$note,
            "ip"=>$this->request->ip(),
            "add_time"=>\date("Y-m-d H:i:s")
        ]);
    }
}
