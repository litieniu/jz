<?php
namespace app\api\controller\deerhome\user;

use app\api\controller\deerhome\user\BaseAuth;
use app\admin\model\deerhome\CardOrder as CardOrderModel;
use think\Db;
use think\Validate;

/**
 * 用户
 */
class User extends BaseAuth
{
    
    public function index()
    {
        $data=[];
        $data['num_card']=CardOrderModel::where("status",2)->where("deerhome_user_id",$this->_user['id'])->count();
        $data['face']=$this->fixImg($this->_user['face_image']);
        $data['uname']=$this->_user['uname'];
        $data['utel']=\substr_replace($this->_user['utel'],'****',3,4);
        $data['num_jf']=$this->_user['jf'];
        $data['num_sc']=Db::name("deerhome_user_collected")->where("type",1)->where("jz_user_id",$this->_user['id'])->count();
        $data['num_yhq']=Db::name('deerhome_yhq')->where('jz_user_id',$this->_user['id'])->where("status",2)->count();
        $data['num_zj']=Db::name("deerhome_user_collected")->where("type",2)->where("jz_user_id",$this->_user['id'])->count();
        $data['order_dfk']=Db::name('deerhome_order')->where(['jz_user_id'=>$this->_user['id'],'status'=>1])->count();
        $data['order_dfw']=Db::name('deerhome_order')->where(['jz_user_id'=>$this->_user['id']])->where("status","in",[2,3])->count();
        $data['order_dys']=Db::name('deerhome_order')->where(['jz_user_id'=>$this->_user['id']])->where("status",4)->count();
        $data['order_pj']=Db::name('deerhome_order')->where('jz_user_id',$this->_user['id'])->where("status",5)->where("worker_pj_star",0)->count();
        $data['order_refund']=Db::name('deerhome_order_refund')->where('jz_user_id',$this->_user['id'])->where("status",1)->count();
        $data['list']=[];
        $data['list_title']="为您推荐";

        $historyCount=Db::name("deerhome_user_collected")->where("type",2)->where("jz_user_id",$this->_user['id'])->count();
        if($historyCount>=2){
            $data['list_title']="我的足迹";
            $data['list']=Db::name("deerhome_user_collected")
            ->alias("c")
            ->join("deerhome_items i","i.id=c.jz_items_id","left")
            ->where('c.jz_user_id',$this->_user['id'])
            ->where('c.type',2)
            ->field("i.id,i.name,i.face_image,i.price,i.sale_times,i.recommend")
            ->limit(6)
            ->order("c.id desc")
            ->select();
            foreach($data['list'] as &$v){
                $v['face_image']=$this->fixImg($v['face_image'],true);
                $v['sale']="已售".$v['sale_times'];
                $v['good']="96%好评";
            }
        }
        //分销中心
        $data['agent_show']=1;
        //会员背景
        $data['vip_bg']="";
        $data['vip_tag']="";
        if($this->_user['user_lev_id']>0){
            $lev=Db::name("deerhome_user_lev")->where("id",$this->_user['user_lev_id'])->find();
            if($lev){
                $data['vip_tag']=$lev['name'];
                if($lev['bg_image']!=""){
                    $data['vip_bg']=$this->fixImg($lev['bg_image']);
                }
            }
        }

        $this->xcxLog("个人中心");
        $this->ok($data);
    }
    public function profile(){
        $this->xcxLog("个人资料");
        $data=[];
        $data['face']=$this->fixImg($this->_user['face_image']);
        $data['uname']=$this->_user['uname'];
        $data['utel']=$this->_user['utel'];
        $data['regtime']=$this->_user['regtime'];
        $data['userlev']="无";
        if($this->_user['user_lev_id']>0){
            $lev=Db::name("deerhome_user_lev")->where("id",$this->_user['user_lev_id'])->find();
            if($lev){
                $data['userlev']=$lev['name']."(享受{$lev['discount']}%折)";
            }
        }
        $this->ok($data);
    }
    public function set_name(){
        $uname=$this->request->param("uname","",'trim');
        if($uname==""){
            $this->err("姓名不能为空");
        }
        Db::name("deerhome_user")->where("id",$this->_user['id'])->update(["uname"=>$uname]);
        $this->ok();
    }
    public function set_face(){
        $face=$this->request->param("face","",'trim');
        if($face==""){
            $this->err("请上传头像");
        }
        Db::name("deerhome_user")->where("id",$this->_user['id'])->update(["face_image"=>$face]);
        $this->ok();
    }
    public function collectItems(){
        $id=$this->request->param("id",0,'intval');
        $data=0;
        $isCollect=Db::name("deerhome_user_collected")->where("type",1)->where("jz_user_id",$this->_user['id'])->where("jz_items_id",$id)->count();
        if($isCollect){
            Db::name("deerhome_user_collected")->where("type",1)->where("jz_user_id",$this->_user['id'])->where("jz_items_id",$id)->delete();
            $data=0;
        }else{
            Db::name("deerhome_user_collected")->insert(["jz_user_id"=>$this->_user['id'],"jz_items_id"=>$id,"add_time"=>date("Y-m-d H:i:s")]);
            $data=1;
        }
        $this->ok($data);
    }
    public function history_collect(){
        $type=$this->request->param("type",1,'intval');
        $data=Db::name("deerhome_user_collected")
        ->alias("c")
        ->join("deerhome_items i","i.id=c.jz_items_id","left")
        ->where('c.jz_user_id',$this->_user['id'])
        ->where('c.type',$type)
        ->field("i.id,i.name,i.face_image,i.price,i.sale_times,i.recommend")
        ->order("c.id desc")
        ->paginate(50)->each(function($item,$key){
            $item['face_image']=$this->fixImg($item['face_image']);
            $item['sale']="已售".$item['sale_times'];
            $item['good']="96%好评";
            return $item;
        });
        $this->ok($data);
    }
    public function switch_worker() {
        $worker=Db::name("deerhome_worker")->where("utel",$this->_user['utel'])->find();
        if(!$worker){
            $this->err("您还不是服务人员，请先申请入驻",1);
        }
        $token=md5($worker['id'].$worker['utel'].time());
        Db::name("deerhome_worker")->where("id",$worker['id'])->update(["token"=>$token,"wxid"=>$this->_user['wxid']]);
        $this->xcxLog("身份切换");
        $this->ok(['token'=>$token]);
    }
    public function switch_agent() {
        $fxms="";
        try{
            $fxms=\Tools\Config::getConfig(null,"agent","fxms");
        }catch(\Exception $e){
            $this->err($e->getMessage());
        }
        if($fxms==1){
            $this->ok();
        }
        if($this->_user['agent']!=1){
            $this->err("您还不是分销员，请先申请",1);
        }
        $this->ok();
    }
}
