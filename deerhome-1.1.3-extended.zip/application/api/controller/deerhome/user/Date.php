<?php

namespace app\api\controller\deerhome\user;

use app\api\controller\deerhome\user\BaseAuth;
use think\Db;
/**
 * 选择预约时间
 */
class Date extends BaseAuth
{

    public function index()
    {
        $gg_id = $this->request->post("gg_id");
        $res=[];
        $res['day']=[];
        //获取最近15天的日期
        for($i=0;$i<15;$i++){
            $res['day'][$i]['v']=date("Y-m-d",strtotime("+$i day"));
            $res['day'][$i]['n']=$this->getWeek(date("Y-m-d",strtotime("+$i day")),"星期");
            if($res['day'][$i]['v']==date("Y-m-d")){
                $res['day'][$i]['n']="今天";
            }
            if($res['day'][$i]['v']==date("Y-m-d",strtotime("+1 day"))){
                $res['day'][$i]['n']="明天";
            }
        }
   
        $res['time']=$this->timeCreat($res['day'][0]['v']);
        $this->ok($res);
    }
    public function getTime()
    {
        $day=$this->request->param("day","");
        $timeArr=$this->timeCreat($day);
        $this->ok($timeArr);
    }
    private function timeCreat($day){
        $timeArr=[];
        //从8点开始到22点，每隔半个小时生成一个元素
        for($i=8;$i<=22;$i++){
            $time1=str_pad($i,2,"0",STR_PAD_LEFT).":00";
            $time2=str_pad($i,2,"0",STR_PAD_LEFT).":30";
            //c=1表示已经约满
            $timeArr[]=['n'=>$time1,'c'=>0,'yw'=>0,'d'=>$day];
            $timeArr[]=['n'=>$time2,'c'=>0,'yw'=>0,'d'=>$day];
        }
        //取出时间段配置
        $config=$this->getConfig("sys");
        $time_start=(int)\str_replace(":","",$config['time_start']);
        $time_end=(int)\str_replace(":","",$config['time_end']);
        foreach($timeArr as $k=>&$v){
            $time=(int)\str_replace(":","",$v['n']);
            if($time<$time_start || $time>$time_end){
                unset($timeArr[$k]);
            }
            //如果是今天，判断当前时间是否已经过去
            if($v['d']==date("Y-m-d")){
                if($time<date("Hi")){
                    unset($timeArr[$k]);
                }
                //且只能约1个小时后的
                if($time<date("Hi",strtotime("+1 hour"))){
                    unset($timeArr[$k]);
                }
            }
            //夜间
            if($time>=1800){
                $v['yw']=1;
            }
        }
        $timeArr=array_values($timeArr);
        return $timeArr;
    }
}
