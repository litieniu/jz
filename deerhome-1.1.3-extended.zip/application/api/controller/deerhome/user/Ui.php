<?php
namespace app\api\controller\deerhome\user;

use app\api\controller\deerhome\user\Base;
use think\Db;
use think\Validate;

/**
 * 界面渲染
 */
class Ui extends Base
{
    
    public function user()
    {
        $data=[];
        $data['show_wallet']=1;
        $data['order']=[];
        array_push($data['order'],[
            "name"=>"待付款",
            "key"=>"order_dfk",
            "icon"=>$this->fixImg("/assets/addons/deerhome/img/my/wallet.png")
        ]);
        array_push($data['order'],[
            "name"=>"待服务",
            "key"=>"order_dfw",
            "icon"=>$this->fixImg("/assets/addons/deerhome/img/my/dfw.png")
        ]);
        array_push($data['order'],[
            "name"=>"待验收",
            "key"=>"order_dys",
            "icon"=>$this->fixImg("/assets/addons/deerhome/img/my/dys.png")
        ]);
        array_push($data['order'],[
            "name"=>"待评价",
            "key"=>"order_pj",
            "icon"=>$this->fixImg("/assets/addons/deerhome/img/my/dpj.png")
        ]);
        array_push($data['order'],[
            "name"=>"退款/售后",
            "key"=>"order_refund",
            "icon"=>$this->fixImg("/assets/addons/deerhome/img/my/tk.png")
        ]);
        $data['func']=[];
        array_push($data['func'],[
            "name"=>"免费领券",
            "icon"=>$this->fixImg("/assets/addons/deerhome/img/my/icon_get_q.png"),
            "url"=>"/pages/coupon/coupon",
            "type"=>"link",
            "color"=>"#e41f19"
        ]);
        array_push($data['func'],[
            "name"=>"客服服务",
            "icon"=>$this->fixImg("/assets/addons/deerhome/img/my/icon_kefu.png"),
            "url"=>"",
            "type"=>"kefu"
        ]);
        array_push($data['func'],[
            "name"=>"人员入驻",
            "icon"=>$this->fixImg("/assets/addons/deerhome/img/my/icon_zm.png"),
            "url"=>"/pages/apply",
            "type"=>"link"
        ]);
        array_push($data['func'],[
            "name"=>"身份切换",
            "icon"=>$this->fixImg("/assets/addons/deerhome/img/my/icon_sfqh.png"),
            "url"=>"",
            "type"=>"switchToWorder"
        ]);

        //是否开启分销
        if(\Tools\Config::isAgentOn()){
            array_push($data['func'],[
                "name"=>"分销中心",
                "icon"=>$this->fixImg("/assets/addons/deerhome/img/my/icon_fx.png"),
                "url"=>"/pages/agent/index",
                "type"=>"switchToAgent"
            ]);
            array_push($data['func'],[
                "name"=>"推广海报",
                "icon"=>$this->fixImg("/assets/addons/deerhome/img/my/icon_hb.png"),
                "url"=>"/pages/agent/code",
                "type"=>"switchToAgent"
            ]);
        }
        
        array_push($data['func'],[
            "name"=>"常见问题",
            "icon"=>$this->fixImg("/assets/addons/deerhome/img/my/icon_wenti.png"),
            "url"=>"/pages/kefu",
            "type"=>"link"
        ]);
        array_push($data['func'],[
            "name"=>"开具发票",
            "icon"=>$this->fixImg("/assets/addons/deerhome/img/my/icon_fp.png"),
            "url"=>"/pages/my/invoice/invoice",
            "type"=>"link"
        ]);
        $this->ok($data);
    }
   
}
