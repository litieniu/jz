<?php
namespace app\api\controller\deerhome\user;

use app\api\controller\deerhome\user\BaseAuth;
use think\Db;
use think\Validate;
use think\Log;
/**
 * 积分
 */
class Jf extends BaseAuth
{
    public function log()
    {
        $this->xcxLog("积分明细");
        $month=$this->request->param("month","",'trim');
        $where=[];
        $where['deerhome_user_id']=$this->_user['id'];
       
        if(preg_match("/^\d{4}-\d{2}$/",$month)){
            $where['addtime']=['like',$month.'%'];
        }
        $data=Db::name("deerhome_user_jf_log")->where($where)->order("id desc")->paginate(10)->each(function($item, $key){
            $item['addtime']=date("m-d H:i",strtotime($item['addtime']));
            return $item;
        });
        $this->ok($data);
    }
}
