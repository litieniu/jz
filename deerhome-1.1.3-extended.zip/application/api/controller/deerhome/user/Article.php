<?php
namespace app\api\controller\deerhome\user;

use app\api\controller\deerhome\user\Base;
use think\Db;
use think\Validate;

/**
 * 文章
 */
class Article extends Base
{
    
    public function wenti()
    {
        $this->xcxLog("常见问题");
        $banner=Db::name("deerhome_design")->where("page","wenti")->find();
        $banner=json_decode($banner['con'],true);
        $banner=$banner['banner'];
        if(isset($banner['img'])){
            $banner=$this->fixImg($banner['img']);
        }
        $data=Db::name("deerhome_article")->field("id,name")->where("cate",2)->order("id desc")->limit(50)->select();
        $out=[];
        $out['banner']=$banner;
        $out['list']=$data;
        $this->ok($out);
    }
    public function detail()
    {
        $id=$this->request->param("id",0,'intval');
        $data=Db::name("deerhome_article")->where("id",$id)->find();
        if(!$data){
            $this->err("文章不存在");
        }
        $data['con']=htmlspecialchars_decode($data['con']);
        Db::name("deerhome_article")->where("id",$id)->setInc("see",1);
        $this->ok($data);
    }
}
