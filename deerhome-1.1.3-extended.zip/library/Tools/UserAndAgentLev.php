<?php
namespace Tools;
use think\Db;
/**
 * 会员和推广人升级类
*/
class UserAndAgentLev
{
    public static function action($user){
       self::actionUser($user);
       self::actionAgent($user);
    }
    /**
     * 会员升级，根据id
    */
    public static function actionUserById($userId){
         $user=Db::name('deerhome_user')->where("id",$userId)->find();
         if(!$user){
              return;
         }
         self::actionUser($user);
    }
    /**
     * 会员升级
    */
    public static function actionUser($user){
       $userLevConfig=self::userLevConfig($user);
       if(!$userLevConfig){
           return;
       }
       $task=json_decode($userLevConfig['task'],true);
       $doneTaskNum=0;
       foreach($task as $v){
            if($v['name']=='消费金额'){
                $sumPrice=self::sumUserOrderPrice($user['id']);
                if(bccomp($sumPrice,$v['num'],2)>0){
                    $doneTaskNum++;
                }
            }
            if($v['name']=='实际充值金额'){
                $sumPrice=self::sumUserRechargePrice($user['id']);
                if(bccomp($sumPrice,$v['num'],2)>0){
                    $doneTaskNum++;
                }
            }
       }
       if(!self::hasDoneTask($userLevConfig['task_type'],$doneTaskNum,count($task))){
           return;
       }
       Db::name('deerhome_user')->where("id",$user['id'])->update(['user_lev_id'=>$userLevConfig['id']]);
    }
    /**
     * 推广人升级，根据id
    */
    public static function actionAgentById($userId){
        $user=Db::name('deerhome_user')->where("id",$userId)->find();
        if(!$user){
             return;
        }
        self::actionUser($user);
   }
    /**
     * 推广人升级
    */
    public static function actionAgent($user){
        //是否开启分销
        if(!Config::isAgentOn()){
            return;
        }
        //如果不是人人分销模式
        if(Config::getAgentFmxs()!=1){
            //不是推广人
            if($user['agent']!=1){
                return;
            }
        }
        
        $agentLevConfig=self::agentLevConfig($user);
        if(!$agentLevConfig){
            return;
        }
        $task=json_decode($agentLevConfig['task'],true);
        $doneTaskNum=0;
        foreach($task as $v){
             if($v['name']=='自身消费金额'){
                 $sumNum=self::sumUserOrderPrice($user['id']);
                 if(bccomp($sumNum,$v['num'],2)>0){
                     $doneTaskNum++;
                 }
             }
             if($v['name']=='推广人数'){
                 $sumNum=self::sumAgentSons($user['id']);
                 if(bccomp($sumNum,$v['num'],2)>0){
                     $doneTaskNum++;
                 }
             }
             if($v['name']=='下级消费金额'){
                 $sumNum=self::sumAgentSonsPrice($user['id']);
                 if(bccomp($sumNum,$v['num'],2)>0){
                     $doneTaskNum++;
                 }
             }
        }
        if(!self::hasDoneTask($agentLevConfig['task_type'],$doneTaskNum,count($task))){
            return;
        }
        Db::name('deerhome_user')->where("id",$user['id'])->update(['agent_lev_id'=>$agentLevConfig['id']]);
    }
    /**
     * 是否满足条件
    */
    private static function hasDoneTask($task_type,$doneTaskNum,$totalTaskNum){
        //全部满足
       if($task_type==1 && $doneTaskNum==$totalTaskNum){
           return true;
       }
       //满足其中一个
       if($task_type==2 && $doneTaskNum>0){
           return true;
       }
       return false;
    }
    /**
     * 获取某个用户的消费金额
    */
    public static function sumUserOrderPrice($userId){
       return Db::name('deerhome_order')->where('jz_user_id',$userId)->where('status',5)->sum('price_payed');
    }
    /**
     * 获取某个用户的充值金额
    */
    public static function sumUserRechargePrice($userId){
       return Db::name('deerhome_order_pay_log')->where('deerhome_user_id',$userId)->where('type',2)->sum('price');
    }
    /**
     * 获取某个推广人的下级推广人数
    */
    public static function sumAgentSons($userId){
       return Db::name('deerhome_user')->where('agent_lev1_uid',$userId)->count();
    }
    /**
     * 获取某个推广人的下级消费金额
    */
    public static function sumAgentSonsPrice($userId){
       return Db::name('deerhome_order')->where('agent_lev1_uid',$userId)->where('status',5)->sum('price_payed');
    }
    /**
     * 获取会员下一级的配置
    */
    public static function userLevConfig($user){
        if($user['user_lev_id']==0){
            return Db::name('deerhome_user_lev')->order("lev asc")->find();
        }
        $nowLev=Db::name('deerhome_user_lev')->where('id',$user['user_lev_id'])->find();
        if(!$nowLev){
            throw new \Exception("当前会员等级已被删除");
        }
        return Db::name('deerhome_user_lev')->where('lev','>',$nowLev['lev'])->order("lev asc")->find();
    }
    /**
     * 获取推广人下一级的配置
    */
    public static function agentLevConfig($user){
        if($user['agent_lev_id']==0){
            return Db::name('deerhome_agent_lev')->order("lev asc")->find();
        }
        $nowLev=Db::name('deerhome_agent_lev')->where('id',$user['agent_lev_id'])->find();
        if(!$nowLev){
            throw new \Exception("当前推广人等级已被删除");
        }
        return Db::name('deerhome_agent_lev')->where('lev','>',$nowLev['lev'])->order("lev asc")->find();
    }
}