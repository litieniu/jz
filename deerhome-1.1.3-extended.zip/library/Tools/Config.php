<?php
namespace Tools;
use think\Db;
/**
 * 系统配置类
*/
class Config
{
    public static function tel($tel){
        if(!$tel){
            return "";
        }
        $admin=\think\Session::get('admin.username');
        if($admin=='demo'){
            return substr_replace($tel,'****',3,4);
        }
        return $tel;
    }
    //获取系统配置,$arr传入array时则不查询数据库，从array查找，避免多次查询数据库
    public static function getConfig($arr=null,$platform="xcx_config",$key=""){
        if(is_array($arr)){
            $res=$arr;
        }else{
            $data=Db::name("deerhome_xcxpz")->where("platform",$platform)->find();
            if(!$data){
                throw new \Exception("没有{$platform}配置信息");
            }
            $res=\json_decode($data['con'],true);
        }
        if($key){
            if(!isset($res[$key])){
                throw new \Exception("没有{$platform}配置信息的{$key}字段");
            }
            return $res[$key];
        }
        return $res;
    }
    //是否开启分销
    public static function isAgentOn($arr=null){
        $res="";
        try{
            $res=self::getConfig($arr,"agent","on");
        }catch(\Exception $e){
            $res="off";
        }
        return $res=="on";
    }
    //分销层级
    public static function getAgentLev($arr=null){
        $res="";
        try{
            $res=self::getConfig($arr,"agent","lev");
        }catch(\Exception $e){
            $res="1";
        }
        return $res;
    }
    //自购返佣
    public static function getAgentZgfy($arr=null){
        $res="";
        try{
            $res=self::getConfig($arr,"agent","zgfy");
        }catch(\Exception $e){
            $res="off";
        }
        return $res=="on";
    }
    //分销模式
    public static function getAgentFmxs($arr=null){
        $res="";
        try{
            $res=self::getConfig($arr,"agent","fxms");
        }catch(\Exception $e){
            $res="1";
        }
        return $res;
    }
    //分销最低提现金额
    public static function getAgentTxMinMoney($arr=null){
        $res="";
        try{
            $res=self::getConfig($arr,"agent","tx");
        }catch(\Exception $e){
            $res="0";
        }
        return $res;
    }
    //获取分销海报背景
    public static function getAgentPostBgImg($arr=null){
        $res="";
        try{
            $res=self::getConfig($arr,"agent","hb");
        }catch(\Exception $e){
            $res="";
        }
        $res=explode(",",$res);
        $res=array_filter($res);
        return $res;
    }
}