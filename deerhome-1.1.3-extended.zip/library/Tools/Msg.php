<?php
namespace Tools;
use think\Db;
/**
 * 消息类
*/
class Msg
{
    //获取系统配置
    public static function getConfig($platform="xcx_config"){
        $data=Db::name("deerhome_xcxpz")->where("platform",$platform)->find();
        if(!$data){
            throw new \Exception("没有配置信息");
        }
        return \json_decode($data['con'],true);
    }
    //提醒用户已派单
    public static function toUserPaidan($uid,$orderSn){
        $order=Db::name("deerhome_order")->alias('o')
        ->join("deerhome_user u","u.id=o.jz_user_id","left")
        ->field("o.item_name,o.item_gg_name,o.num,o.date_day,o.date_time,o.worker_name,u.wxid")
        ->where("o.sn",$orderSn)
        ->find();

        self::toUser($uid,"您的订单[{$orderSn}]已安排{$order['worker_name']}上门服务");

        if(!$order['wxid']){
            return ;
        }
        //获取微信订阅消息id
        $msgId=Db::name("deerhome_xcxmsg")->where("title","服务派单通知")->value("tplid");
        if(!$msgId){
            return ;
        }
        $data=[];
        $data['thing2']['value']=$order['item_name'];
        $data['thing3']['value']=$order['item_gg_name']."*".$order['num'];
        $data['date4']['value']=$order['date_day']." ".$order['date_time'];
        $data['name8']['value']=$order['worker_name'];
        $data['thing12']['value']="请您保持手机畅通";
        self::sendToWx($msgId,$order['wxid'],$data,"[toUserPaidan]订单号".$orderSn,"pages/myOrder/myOrder");
        return ;
    }
    //提醒用户变更时间
    public static function toUserEditTime($uid,$orderSn,$newTime){
        $order=Db::name("deerhome_order")->alias('o')
        ->join("deerhome_user u","u.id=o.jz_user_id","left")
        ->field("o.item_name,o.item_gg_name,o.num,o.date_day,o.date_time,o.worker_name,u.wxid")
        ->where("o.sn",$orderSn)
        ->find();

        self::toUser($uid,"您的订单[{$orderSn}]已变更上门时间为{$newTime}。");

        if(!$order['wxid']){
            return ;
        }
        //获取微信订阅消息id
        $msgId=Db::name("deerhome_xcxmsg")->where("title","上门时间变更通知")->value("tplid");
        if(!$msgId){
            return ;
        }
        $data=[];
        $data['thing7']['value']=$order['item_name'];
        $data['thing8']['value']=$order['item_gg_name']."*".$order['num'];
        $data['date3']['value']=$order['date_day']." ".$order['date_time'];
        $data['date4']['value']=$newTime;
        self::sendToWx($msgId,$order['wxid'],$data,"[toUserEditTime]订单号".$orderSn,"pages/myOrder/myOrder");
        return ;
    }
    //分销人员提现审核结果
    public static function toAgentMoneyGet($uid,$status,$price,$note){
        $note=$note?$note:"无";
        $price=$price<0?$price*-1:$price;
        $price.="元";
        
        self::toUser($uid,"您的提现申请{$status}，金额{$price}，说明{$note}");

        $user=Db::name("deerhome_user")->field('wxid')->where("id",$uid)->find();
        if(!$user['wxid']){
            return ;
        }
        //获取微信订阅消息id
        $msgId=Db::name("deerhome_xcxmsg")->where("title","提现审核通知")->value("tplid");
        if(!$msgId){
            return ;
        }
        $data=[];
        $data['phrase2']['value']=$status;
        $data['amount1']['value']=$price;
        $data['thing3']['value']=$note;
        self::sendToWx($msgId,$user['wxid'],$data,"[toWorkerMoneyGet]uid={$uid},￥".$price,"pages/agent/index");
        return ;
    }
    //提醒服务人员新的订单
    public static function toWorkerNewOrder($uid,$orderSn){
        self::toWorker($uid,"您有一个新的派单待处理，订单号{$orderSn}");
        $order=Db::name("deerhome_order")->alias('o')
        ->join("deerhome_worker u","u.id=o.worker_id","left")
        ->field("o.sn,o.item_name,o.item_gg_name,o.num,o.date_day,o.date_time,o.price_payed,u.wxid")
        ->where("o.sn",$orderSn)
        ->find();
        if(!$order['wxid']){
            return ;
        }
        //获取微信订阅消息id
        $msgId=Db::name("deerhome_xcxmsg")->where("title","新订单通知")->value("tplid");
        if(!$msgId){
            return ;
        }
        $data=[];
        $data['character_string3']['value']=$order['sn'];
        $data['thing4']['value']=$order['item_name']."-".$order['item_gg_name']."*".$order['num'];
        $data['amount10']['value']=$order['price_payed'];
        $data['date5']['value']=$order['date_day']." ".$order['date_time'];
        $data['thing9']['value']="请尽快联系客户确认上门时间";
        self::sendToWx($msgId,$order['wxid'],$data,"[toWorkerNewOrder]订单号".$orderSn,"pages/workerCode/task");
        return ;
    }
    //提醒服务人员订单已取消
    public static function toWorkerCancelOrder($uid,$orderSn){
        self::toWorker($uid,"您的订单已被取消，订单号{$orderSn}");

        $order=Db::name("deerhome_order")->alias('o')
        ->field("o.sn,o.item_name,o.item_gg_name,o.num,o.date_day,o.date_time,o.price_payed")
        ->where("o.sn",$orderSn)
        ->find();
        if(!$order){
            return ;
        }
        $worker=Db::name("deerhome_worker")->field('wxid')->where("id",$uid)->find();
        if(!$worker['wxid']){
            return ;
        }
        //获取微信订阅消息id
        $msgId=Db::name("deerhome_xcxmsg")->where("title","订单取消通知")->value("tplid");
        if(!$msgId){
            return ;
        }
        $data=[];
        $data['character_string3']['value']=$order['sn'];
        $data['phrase4']['value']="已取消";
        $data['thing5']['value']=$order['item_name']."-".$order['item_gg_name']."*".$order['num'];
        $data['thing6']['value']="其他";
        self::sendToWx($msgId,$worker['wxid'],$data,"[toWorkerCancelOrder]订单号".$orderSn,"pages/workerCode/task");
        return ;
    }
    //服务人员提现审核结果
    public static function toWorkerMoneyGet($uid,$status,$price,$note){
        $note=$note?$note:"无";
        $price=$price<0?$price*-1:$price;
        $price.="元";
        
        self::toWorker($uid,"您的提现申请{$status}，金额{$price}，说明{$note}",1);

        $worker=Db::name("deerhome_worker")->field('wxid')->where("id",$uid)->find();
        if(!$worker['wxid']){
            return ;
        }
        //获取微信订阅消息id
        $msgId=Db::name("deerhome_xcxmsg")->where("title","提现审核通知")->value("tplid");
        if(!$msgId){
            return ;
        }
        $data=[];
        $data['phrase2']['value']=$status;
        $data['amount1']['value']=$price;
        $data['thing3']['value']=$note;
        self::sendToWx($msgId,$worker['wxid'],$data,"[toWorkerMoneyGet]uid={$uid},￥".$price,"pages/workerCode/wallet");
        return ;
    }
    //服务人员入驻审核结果
    public static function toUserApply($uid,$status,$note){
        $note=$note?$note:"无";
        self::toUser($uid,"您的入驻申请，审核{$status}，说明{$note}",1);

        $user=Db::name("deerhome_user")->field('wxid')->where("id",$uid)->find();
        if(!$user['wxid']){
            return ;
        }
        $title="审核通过提醒";
        if($status=="未通过"){
            $title="审核未通过提醒";
        }
        //获取微信订阅消息id
        $msgId=Db::name("deerhome_xcxmsg")->where("title",$title)->value("tplid");
        if(!$msgId){
            return ;
        }
        $data=[];
        $data['phrase6']['value']=$status;
        $data['thing5']['value']="入驻申请";
        if($status=="未通过"){
            $data=[];
            $data['phrase7']['value']=$status;
            $data['thing6']['value']="入驻申请";
            $data['thing8']['value']=$note;
        }
        self::sendToWx($msgId,$user['wxid'],$data,"[toUserApply]uid={$uid}");
        return ;
    }
    private static function sendToWx($template_id,$touser,$data,$logTip="",$page="pages/index/index"){
        $arr=[];
        $arr['template_id']=$template_id;
        $arr['touser']=$touser;
        $arr['data']=$data;
        $arr['page']=$page;
        //developer为开发版；trial为体验版；formal为正式版；默认为正式版
        $arr['miniprogram_state']="formal";
        $arr['lang']="zh_CN";
        try{
            $config=self::getConfig();
            $WeMini = \WeMini\Newtmpl::instance($config);
            $WeMini->send($arr);
        }catch(\Exception $e){
            \think\Log::error($logTip.":发送微信订阅消息失败：".$e->getMessage()."\n".json_encode($arr,JSON_UNESCAPED_UNICODE));
        }
    }
    public static function toUser($uid,$msg,$msg_type="2"){
        return self::send("1",$uid,$msg,$msg_type);
    }
    public static function toWorker($uid,$msg,$msg_type="2"){
        return self::send("2",$uid,$msg,$msg_type);
    }
    
    public static function send($utype,$uid,$msg,$msg_type="2"){
        $msgArr=[];
        $msgArr['utype']=$utype;
        $msgArr['uid']=$uid;
        $msgArr['msg']=$msg;
        $msgArr['msg_type']=$msg_type;
        $msgArr['send_time']=date("Y-m-d H:i:s");
        Db::name("deerhome_msg")->insert($msgArr);
    }
    
    public static function read($id){
        Db::name("deerhome_msg")->where("id",$id)->update(['is_read'=>1,"read_time"=>date("Y-m-d H:i:s")]);
    }
    public static function readAll($uid){
        Db::name("deerhome_msg")->where("uid",$uid)->update(['is_read'=>1,"read_time"=>date("Y-m-d H:i:s")]);
    }
}