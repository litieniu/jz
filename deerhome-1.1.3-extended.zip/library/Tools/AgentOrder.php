<?php
namespace Tools;
use think\Db;
/**
 * 订单分销计算
*/
class AgentOrder
{
    public static function res($item,$user=[]){
        $data=[];
        $agent=[];
        try{
            $agent=\Tools\Config::getConfig(null,"agent");
        }catch(\Exception $e){
            $agent=[];
        }
        if(count($agent)==0){
            return $data;
        }

        //分销模式
        $agent_fmxs=\Tools\Config::getAgentFmxs($agent);
        //分销层级
        $agent_lev=\Tools\Config::getAgentLev($agent);

        //是否开启分销
        if(!\Tools\Config::isAgentOn($agent)){
            return $data;
        }
        //产品是否参与分销
        if($item['anget']!=1){
            return $data;
        }
        //没有上级也没有上上级
        if($user['agent_lev1_uid']==0 && $user['agent_lev2_uid']==0){
            return $data;
        }
        
        $data['agent_lev1_uid']=$user['agent_lev1_uid'];
        $data['agent_lev1_percent']=$item['anget_lev1'];
        $data['agent_lev2_uid']=$user['agent_lev2_uid'];
        $data['agent_lev2_percent']=$item['anget_lev2'];

        
        //自购返佣::分销员自己购买商品，享受一级返佣，上级享受二级返佣；
        if(
            \Tools\Config::getAgentZgfy($agent)
            && ($user['agent']==1 || $agent_fmxs==1)
        ){
            $data['agent_lev1_uid']=$user['id'];
            $data['agent_lev2_uid']=$user['agent_lev1_uid'];
        }
        
        $agent_lev1_user=Db::name("deerhome_user")->alias('u')->join("deerhome_agent_lev a","a.id=u.agent_lev_id","left")->field("u.id,u.agent,u.agent_lev_id,a.name,a.lev1,a.lev2")->where("u.id",$data['agent_lev1_uid'])->find();
        if($agent_lev1_user){
            $data['agent_lev1_price_note']="默认分佣{$data['agent_lev1_percent']}%";
            //按等级增加分佣
            if($agent_lev1_user['lev1']>0){
                $data['agent_lev1_percent']=bcadd($data['agent_lev1_percent'],$agent_lev1_user['lev1'],2);
                $data['agent_lev1_price_note'].="，等级【{$agent_lev1_user['name']}】额外分佣奖励{$agent_lev1_user['lev1']}%";
            }
            //如果指定分销，判断上级是不是分销人员
            if($agent_fmxs==2 && $agent_lev1_user['agent']!=1){
                $data['agent_lev1_price_note']="上级用户[ID{$data['agent_lev1_uid']}]当前不是分销人员，不享受分销佣金";
                $data['agent_lev1_uid']=0;
                $data['agent_lev1_percent']=0;
            }
        }else{
            $data['agent_lev1_price_note']="上级用户[ID{$data['agent_lev1_uid']}]已不存在";
            $data['agent_lev1_uid']=0;
            $data['agent_lev1_percent']=0;
        }

        //一级分销模式
        if($agent_lev==1){
            $data['agent_lev2_uid']=0;
            $data['agent_lev2_percent']=0;
            return $data;
        }

        if($data['agent_lev2_uid']==0 || $data['agent_lev2_percent']==0){
            $data['agent_lev2_uid']=0;
            $data['agent_lev2_percent']=0;
            return $data;
        }

        $agent_lev2_user=Db::name("deerhome_user")->alias('u')->join("deerhome_agent_lev a","a.id=u.agent_lev_id","left")->field("u.id,u.agent,u.agent_lev_id,a.name,a.lev1,a.lev2")->where("u.id",$data['agent_lev2_uid'])->find();

        if(!$agent_lev2_user){
            $data['agent_lev2_price_note']="上上级用户[ID{$data['agent_lev2_uid']}]已不存在";
            $data['agent_lev2_uid']=0;
            $data['agent_lev2_percent']=0;
            return $data;
        }

        $data['agent_lev2_price_note']="默认分佣{$data['agent_lev2_percent']}%";
        //按等级增加分佣
        if($agent_lev2_user['lev2']>0){
            $data['agent_lev2_percent']=bcadd($data['agent_lev2_percent'],$agent_lev2_user['lev2'],2);
            $data['agent_lev2_price_note'].="，等级【{$agent_lev2_user['name']}】额外分佣奖励{$agent_lev2_user['lev2']}%";
        }
        //如果指定分销，判断上上级是不是分销人员
        if($agent_fmxs==2 && $agent_lev2_user['agent']!=1){
            $data['agent_lev2_price_note']="上上级用户[ID{$data['agent_lev2_uid']}]当前不是分销人员，不享受分销佣金";
            $data['agent_lev2_uid']=0;
            $data['agent_lev2_percent']=0;
        }

        return $data;
    }
    
}