define(['jquery', 'bootstrap', 'backend', 'table', 'form'], function ($, undefined, Backend, Table, Form) {

    var Controller = {
        loadTopInfo:function(){
            Fast.api.ajax({
                url: "deerhome/agent_user/index?cate=info",
                loading: true
            },
            function (data,ret) {
                    let html=Template('info_tpl', {data:data});
                    $("#fx_info").html(html);
                    return false;
                }
            );
        },
        index: function () {
            
            // console.log(location)
            let infoList=[
                {icon:'icon-zhanghao',name:'分销员人数',num:'-'},
                {icon:'icon-fuwurenyuanguanli',name:'推广用户数',num:'-'},
                {icon:'icon-xiangmugaikuang_0',name:'分销订单',num:'-'},
                {icon:'icon-a-yingxiaobaoxiao2',name:'订单金额',num:'-'},
                {icon:'icon-xindaieduye-xindaiedugaikuang',name:'佣金余额',num:'-'}
            ];
            let html=Template('info_tpl', {data:infoList});
            $("#fx_info").html(html);
            // 初始化表格参数配置
            Table.api.init({
                extend: {
                    index_url: 'deerhome/agent_user/index' + location.search,
                    add_url: 'deerhome/agent_user/add' + location.search,
                    edit_url: 'deerhome/agent_user/edit',
                    del_url: 'deerhome/agent_user/del',
                    multi_url: 'deerhome/agent_user/multi',
                    import_url: 'deerhome/agent_user/import',
                    table: 'deerhome_agent_user',
                }
            });

            var table = $("#table");
            $(document).on("click",".btn-refresh",function (s) {
                table.bootstrapTable('refresh');
           })
            table.on('post-common-search.bs.table', function (event, table) {
                $(".columns-right").hide();
            });
            table.on('load-success.bs.table', function (e, data) {
                Controller.loadTopInfo();
                if(Config.fxms==2){
                    $("#add_can").removeClass('hide');
                }
            });
            console.log(Config.fxms)
            // 初始化表格
            table.bootstrapTable({
                url: $.fn.bootstrapTable.defaults.extend.index_url,
                pk: 'id',
                sortName: 'id',
                searchFormTemplate: 'customformtpl',
                search: false,
                searchFormVisible: true,
                fixedColumns: true,
                fixedNumber: 1,
                fixedRightNumber: 1,
                columns: [
                    [
                        {field: 'id', title: "UID"},
                        {field: 'face_image', title: "头像", operate: false, events: Table.api.events.image, formatter: Table.api.formatter.image},
                        {field: 'uname', title: '昵称'},
                        {field: 'utel', title: '手机', operate: '='},
                        {field: 'my_users', title: "推广用户数", operate: false},
                        {field: 'name', title: "分销等级", operate: false},
                        {field: 'order_price', title: "消费金额", operate: false},
                        {field: 'wallet_left', title: "佣金余额", operate: false},
                        {field: 'wallet_tx', title: "已提现金额", operate: false},
                        {field: 'wallet_dj', title: "冻结金额", operate: false},
                        {field: 'agent_lev1_uid', title: "上级推广人", operate: false,formatter:function(value,row,index){
                            if(value==0){
                                return `<span class="label label-primary">平台直推</span>`;
                            }
                            return `<span class="label label-success">${row.lev1_uname}(UID${value})</span>`;
                        }},
                        {field: 'regtime', title: "注册时间", operate:'RANGE', addclass:'datetimerange', autocomplete:false},
                        {field: 'operate', title: __('Operate'),
                            table: table,
                            events: Table.api.events.operate,
                            buttons:[
                                {
                                    name: 'detail',
                                    text: `详情`,
                                    title: function(row){ return `【ID${row.id}】详情`},
                                    classname: 'btn btn-xs btn-primary btn-dialog',
                                    icon: 'fa fa-ellipsis-h',
                                    url: `deerhome/agent_user/detail`,
                                    visible: function (row) {
                                        return true;
                                    }
                                },
                                {
                                    name: 'del',
                                    text: ``,
                                    classname: 'btn btn-xs btn-danger btn-delone',
                                    icon: 'fa fa-trash',
                                    url: `deerhome/agent_user/del`,
                                    visible: function (row) {
                                        return Config.fxms==2;
                                    }
                                }
                            ],
                            formatter:Table.api.formatter.buttons
                        }
                    ]
                ]
            });

            // 为表格绑定事件
            Table.api.bindevent(table);
        },
        table: {
            table_user: function () {
                var table_son = $("#table_user");
                table_son.on('post-common-search.bs.table', function (event, table) {
                    $(".columns-right").hide();
                });
                table_son.bootstrapTable({
                    url: 'deerhome/agent_user/detail?table=user&ids='+$("#row_id").val(),
                    sortName: 'id',
                    search: false,
                    searchFormVisible: false,
                    columns: [
                        [
                            {field: 'id', title: 'UID'},
                            {field: 'face_image', title: "头像", operate: false, events: Table.api.events.image, formatter: Table.api.formatter.image},
                            {field: 'uname', title: "昵称", operate: 'LIKE'},
                            {field: 'order_num', title: "订单数", operate: false},
                            {field: 'order_price', title: "订单金额", operate: false},
                            {field: 'regtime', title: '注册时间', operate:'RANGE', addclass:'datetimerange', autocomplete:false},
                        ]
                    ]
                });
                Table.api.bindevent(table_son);
            },
            table_order: function () {
                var table_son = $("#table_order");
                table_son.on('post-common-search.bs.table', function (event, table) {
                    $(".columns-right").hide();
                });
                table_son.bootstrapTable({
                    url: 'deerhome/agent_user/detail?table=order&ids='+$("#row_id").val(),
                    sortName: 'id',
                    search: false,
                    searchFormVisible: false,
                    columns: [
                        [
                            {field: 'status', title: __('Status')
                                , searchList: {"1":__('Status 1'),"2":__('Status 2'),"3":__('Status 3'),"4":__('Status 4'),"5":__('Status 5'),"6":__('Status 6'),"7":__('Status 7'),"8":__('Status 8')}
                                , formatter: function (value, row, index) {
                                    var color = "info";
                                    switch (value) {
                                        case 1:
                                            color = "warning";
                                            break;
                                        case 2:
                                            color = "primary";
                                            break;
                                        case 3:
                                            color = "info";
                                            break;
                                        case 4:
                                            color = "deer";
                                            break;
                                        case 5:
                                            color = "success";
                                            break;
                                        case 6:
                                            color = "danger";
                                            break;
                                        case 7:
                                            color = "danger";
                                            break;
                                        case 8:
                                            color = "default";
                                            break;
                                        default:
                                            break;
                                    }
                                    return '<span class="label label-' + color + '">' + __('Status '+row.status) + '</span>';
                                }
                            },
                            {field: 'sn', title: __('Sn'), operate: '='},
                            {field: 'uname', title: "下单人", formatter:function(value,row,index){
                                return `${row.uname}(UID${row.jz_user_id})`;
                            }},
                            {field: 'item_name', title: __('Item_name'), formatter:function(value,row,index){
                                return `${value} ${row.item_gg_name} * ${row.num}`;
                            }},
                            {field: 'price_payed', title: __('Price_payed'), operate:false},
                            {field: 'id', title: '分佣金额', operate:false, formatter:function(value,row,index){
                                let uid=$("#row_id").val();
                                if(row.agent_lev1_uid==uid){
                                    return `<span class="label label-primary">一级</span> ￥${row.agent_lev1_price}`;
                                }
                                if(row.agent_lev2_uid==uid){
                                    return `<span class="label label-primary">二级</span> ￥${row.agent_lev2_price}`;
                                }
                                return '未知';
                            }},
                        ]
                    ]
                });
                Table.api.bindevent(table_son);
            },
            table_money: function () {
                var table_son = $("#table_money");
                table_son.on('post-common-search.bs.table', function (event, table) {
                    $(".columns-right").hide();
                });
                table_son.bootstrapTable({
                    url: 'deerhome/agent_user/detail?table=money&ids='+$("#row_id").val(),
                    sortName: 'id',
                    search: false,
                    searchFormVisible: false,
                    columns: [
                        [
                            {field: 'addtime', title: __('Addtime')},
                            {field: 'type', title: __('Type'), operate: '='},
                            {field: 'jz_order_sn', title: __('Jz_order_sn'), operate: '='},
                            {field: 'price', title: __('Price'), operate:'BETWEEN'},
                            {field: 'note', title: __('Note'), operate: 'LIKE'},
                        ]
                    ]
                });
                Table.api.bindevent(table_son);
            }
        },
        add: function () {
            Controller.api.bindevent();
        },
        detail: function () {
            console.log(Config.levList)
            $("a.btn-edit-lev").on("click",function(){
                let old_lev_id=$(this).data("lev-id");
                let str='<select class="form-control" id="set-lev-select">';
                str+='<option value="0">--无等级--</option>';
                for(var i=0;i<Config.levList.length;i++){
                    str+='<option value="'+Config.levList[i].id+'" '+(old_lev_id==Config.levList[i].id?'selected':'')+'>'+Config.levList[i].name+'</option>';
                }
                str+='</select>';
                Layer.open({title:'设置分销等级',content:str,btn:['确定'],yes:function(index,layero){
                    let lev=$("#set-lev-select").val();
                    Fast.api.ajax({
                        url: "deerhome/agent_user/set_lev?lev="+lev+"&ids="+$("#row_id").val(),
                        loading: true
                    },
                    function (data,ret) {
                        parent && parent.$("a.btn-refresh").trigger("click");
                        Layer.close(index);
                        location.href=location.href;
                        return false;
                    });
                }});
            });
            // 初始化表格参数配置
            Table.api.init();
            //绑定事件
            $('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
                var panel = $($(this).attr("href"));
                if (panel.length > 0) {
                    Controller.table[panel.data("table")].call(this);
                    // $(this).on('click', function (e) {
                    //     $($(this).attr("href")).find(".btn-refresh").trigger("click");
                    // });
                }
                //移除绑定的事件
                $(this).unbind('shown.bs.tab');
            });
            
            //必须默认触发shown.bs.tab事件
            $('ul.nav-tabs li.active a[data-toggle="tab"]').trigger("shown.bs.tab");
        },
        api: {
            bindevent: function () {
                Form.api.bindevent($("form[role=form]"));
            }
        }
    };
    return Controller;
});
