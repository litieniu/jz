define(['jquery', 'bootstrap', 'backend', 'table', 'form'], function ($, undefined, Backend, Table, Form) {

    var Controller = {
        index: function () {
            // 初始化表格参数配置
            Table.api.init({
                extend: {
                    index_url: 'deerhome/user/index' + location.search,
                    add_url: 'deerhome/user/add',
                    edit_url: 'deerhome/user/edit',
                    del_url: 'deerhome/user/del',
                    multi_url: 'deerhome/user/multi',
                    import_url: 'deerhome/user/import',
                    table: 'deerhome_user',
                }
            });

            var table = $("#table");
            //在普通搜索渲染后
            table.on('post-common-search.bs.table', function (event, table) {
                var form = $("form", table.$commonsearch);
                $("input[name='cate.name']", form).addClass("selectpage").data("source", "deerhome/qd/index").data("primaryKey", "name").data("field", "name").data("orderBy", "id desc");
                Form.events.selectpage(form);
            });
            // 初始化表格
            table.bootstrapTable({
                url: $.fn.bootstrapTable.defaults.extend.index_url,
                pk: 'id',
                sortName: 'id',
                fixedColumns: true,
                fixedNumber: 1,
                fixedRightNumber: 1,
                search: false,
                searchFormVisible: true,
                dblClickToEdit:false,
                columns: [
                    [
                        {field: 'id', title: __('Id'),operate: false},
                        {field: 'face_image', title: "头像", operate: false, events: Table.api.events.image, formatter: Table.api.formatter.image},
                        {field: 'uname', title: __('Uname'), operate: 'LIKE'},
                        {field: 'utel', title: __('Utel'), operate: 'LIKE'},
                        {field: 'wallet_charge', title: "储值卡", operate: false,sortable:true,formatter:function(value,row,index){
                            let a=`￥${value} `;
                            a+= `<a class="btn-dialog" style="font-size:12px;margin-left:5px;margin-right:5px;" data-toggle="tooltip" data-original-title="【UID${row.id}】钱包流水" data-shade='0.3'  title="点击查看" href="`+Fast.api.fixurl('deerhome/order_pay_log/index') +`?is_wallet=1&deerhome_user_id=${row.id}">流水</a>`;

                            a+=`<a class="btn-dialog" data-shade-close="false"  data-shade='0.3' data-area='["400px","500px"]' style="font-size:12px;" data-toggle="tooltip" data-original-title="【UID${row.id}】钱包充值" title="点击充值" href="`+Fast.api.fixurl('deerhome/user/wallet_charge') +`?deerhome_user_id=${row.id}">充值</a>`;
                            return a;
                        }},
                        {field: 'user_lev_id', title: "会员等级", operate: false,sortable:true,formatter:function(value,row,index){
                            let a=`-`;
                            if(value>0 && row.lev.name){
                                a= `${row.lev.name}`;
                            }
                            a+=`<a class="btn-set-lev" data-id="${row.id}" data-lev-id="${value}" data-shade-close="false"  data-shade='0.3' data-area='["400px","500px"]' style="font-size:12px;margin-left:5px;" data-toggle="tooltip"  title="设置" href="javascript:;"><i class="fa fa-pencil"></i></a>`;
                            return a;
                        }},
                        {field: 'jf', title: "积分", operate: false,sortable:true},
                        {field: 'order_num', title: "订单数", operate: false},
                        {field: 'order_price', title: "订单金额", operate: false},
                        {field: 'user_sc', title: "收藏", operate: false,formatter:function(value,row,index){
                            return `<a class="btn-dialog" data-toggle="tooltip" data-original-title="【UID${row.id}】收藏" title="点击查看" href="`+Fast.api.fixurl('deerhome/user_collected/index') +`?type=1&jz_user_id=${row.id}">${value}</a>`;
                        }},
                        {field: 'user_zj', title: "产品足迹", operate: false,formatter:function(value,row,index){
                            return `<a class="btn-dialog" data-toggle="tooltip" data-original-title="【UID${row.id}】产品足迹" title="点击查看" href="`+Fast.api.fixurl('deerhome/user_collected/index') +`?type=2&jz_user_id=${row.id}">${value}</a>`;
                        }},
                        {field: 'user_pages', title: "页面记录", operate: false,formatter:function(value,row,index){
                            return `<a class="btn-dialog" data-toggle="tooltip" data-original-title="【UID${row.id}】页面访问记录" title="点击查看" href="`+Fast.api.fixurl('deerhome/user_collected/index') +`?type=3&jz_user_id=${row.id}">${value}</a>`;
                        }},
                        {field: 'note', title: __('Note'), operate: 'LIKE'},
                        {field: 'last_time', title: "最近打开", operate:'RANGE', addclass:'datetimerange', autocomplete:false,sortable:true},
                        {field: 'regtime', title: __('Regtime'), operate:'RANGE', addclass:'datetimerange', autocomplete:false,sortable:true},
                        {field: 'wxid', title: __('Wxid'), operate: 'LIKE'},
                        {field: 'operate', title: __('Operate'), table: table, events: Table.api.events.operate, formatter: Table.api.formatter.operate}
                    ]
                ]
            });

            // 为表格绑定事件
            Table.api.bindevent(table);
            $(document).on("click","a.btn-set-lev",function (s) {
                let row_id=$(this).data("id");
                let old_lev_id=$(this).data("lev-id");
                let str='<select class="form-control" id="set-lev-select">';
                str+='<option value="0">--无等级--</option>';
                for(var i=0;i<Config.levList.length;i++){
                    str+='<option value="'+Config.levList[i].id+'" '+(old_lev_id==Config.levList[i].id?'selected':'')+'>'+Config.levList[i].name+'</option>';
                }
                str+='</select>';
                Layer.open({title:`【UID${row_id}】设置会员等级`,content:str,btn:['确定'],yes:function(index,layero){
                    let lev=$("#set-lev-select").val();
                    Fast.api.ajax({
                        url: "deerhome/user_lev/set_lev?lev="+lev+"&id="+row_id,
                        loading: true
                    },
                    function (data,ret) {
                        $("a.btn-refresh").trigger("click");
                        Layer.close(index);
                        return false;
                    });
                }});
            });
        },
        add: function () {
            Controller.api.bindevent();
        },
        edit: function () {
            Controller.api.bindevent();
        },
        wallet_charge: function () {
            Controller.api.bindevent();
        },
        api: {
            bindevent: function () {
                Form.api.bindevent($("form[role=form]"));
            }
        }
    };
    return Controller;
});
