define(['jquery', 'bootstrap', 'backend', 'table', 'form'], function ($, undefined, Backend, Table, Form) {

    var Controller = {
        index: function () {
            // 初始化表格参数配置
            Table.api.init({
                extend: {
                    index_url: 'deerhome/worker_day/index' + location.search,
                    add_url: 'deerhome/worker_day/add'+ location.search,
                    edit_url: 'deerhome/worker_day/edit',
                    del_url: 'deerhome/worker_day/del',
                    multi_url: 'deerhome/worker_day/multi',
                    import_url: 'deerhome/worker_day/import',
                    table: 'deerhome_worker_day',
                }
            });

            var table = $("#table");
            //在普通搜索渲染后
            table.on('post-common-search.bs.table', function (event, table) {
                $(".columns-right").hide();
            });
            // 初始化表格
            table.bootstrapTable({
                url: $.fn.bootstrapTable.defaults.extend.index_url,
                pk: 'id',
                sortName: 'day',
                search: false,
                columns: [
                    [
                        {checkbox: true},
                        {field: 'day', title: __('Day')},
                        {field: 'jz_worker_id', title: 'jz_worker_id',operate: '=',visible:false},
                        {field: 'pb_rq', title:"休息"+ __('Day_time')}
                    ]
                ]
            });

            // 为表格绑定事件
            Table.api.bindevent(table);
        },
        add: function () {
            var setDayTime = function(){
                var arr=[];
                $(".rowbox").each(function(){
                    var _this = $(this);
                    if(_this.hasClass("active")){
                        arr.push(_this.text());
                    }  
                });
                $("#c-pb_rq").val(arr.join(","));
            }
            $(".rowbox").on("click",function(){
                var _this = $(this);
                if(_this.hasClass("active")){
                    _this.removeClass("active");
                }else{
                    _this.addClass("active");
                }
                setDayTime();
            });
            $("#btn-pb-qx").on("click",function(){
                $(".rowbox").addClass("active");
                setDayTime();
            });

            Controller.api.bindevent();
        },
        edit: function () {
            Controller.api.bindevent();
        },
        api: {
            bindevent: function () {
                Form.api.bindevent($("form[role=form]"));
            }
        }
    };
    return Controller;
});
