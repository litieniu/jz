define(['jquery', 'bootstrap', 'backend', 'addtabs', 'table', 'form', 'echarts', 'echarts-theme', 'template'], function ($, undefined, Backend, Datatable, Table, Form, Echarts, undefined, Template,JNice,PerfectScrollbar) {
    var _post=function (url, par, okCallback, errCallback) {
        $.post(url, par, function (r) {
                if (r.code != 1) {
                    if (typeof errCallback == "function") {
                        errCallback(r);
                        return;
                    }
                    alert(r.msg);
                    return;
                }
                if (typeof okCallback == "function") {
                    okCallback(r.data, r);
                    return;
                }

            }, "json")
            .fail(function () {
                Layer.open({title:false,content:'网络繁忙，请稍后重试刷新页面！',btn:false});
                if (typeof errCallback == "function") {
                    errCallback({
                        msg: "网络繁忙，请稍后重试！"
                    });
                    return;
                }
            });
    }
    //交易走势
    var _trade_chart;
    //用户走势
    var _chart_user;
    var loadingData=function(){
        _trade_chart.showLoading();
        _chart_user.showLoading();
        _post("deerhome/info",{},function(data){
            for(var k in data.tpl_ids){
                $("#"+k).html(data.tpl_ids[k]);
            }
            _tradePar(data.trade_chart);
            _chart_user_par(data.use_chart);
            $("#hot_sale_list").html(Template("tpl_hot_sale_list", {list:data.hot_sale}));
            $("#xs_list").html(Template("tpl_xs_list", {list:data.xs_list}));
            $("#worker_rank").html(Template("tpl_worker_rank", {list:data.worker_rank}));
            $("#fw_log").html(Template("tpl_fw_log", {list:data.fw_log}));
        })
    }
    var _chart_user_par=function(_data){
        var option = {
            title: {
                text: '',
                subtext: ''
            },
            color: [
                "#c388f6",
            ],
            tooltip: {
                trigger: 'axis'
            },
            legend: {
                data: ['新增客户数'],
                show:false,
                bottom: 0,
            },
            toolbox: {
                show: false,
                feature: {
                    magicType: {show: true, type: ['stack', 'tiled']},
                    saveAsImage: {show: true}
                }
            },
            xAxis: [{
                type: 'category',
                data: _data.x,
                axisPointer: {
                    type: 'shadow'
                },
                axisLine:{
                    show:false
                }
            }],
            yAxis: [
                {
                    type: 'value',
                    name: '新增客户数',
                    axisLine:{
                        show:false
                    },
                    axisLabel:{
                        show:false
                    }
                }
            ],
            grid: {
                left: 15,
                top: 'top',
                right: 15,
                bottom: 55
            },
            series: [{
                name: '新增客户数',
                type: 'bar',
                smooth: true,
                areaStyle: {
                    normal: {}
                },
                data: _data.num
            }]
        };
        _chart_user.setOption(option);
        _chart_user.hideLoading();
        _chart_user.resize();
    }
    var _tradePar=function(_data){
        var option = {
            title: {
                text: '',
                subtext: ''
            },
            color: [
                "#c388f6",
                "#dfe2e6",
            ],
            tooltip: {
                trigger: 'axis'
            },
            legend: {
                data: ['订单数','交易额'],
                bottom: 0,
            },
            toolbox: {
                show: false,
                feature: {
                    magicType: {show: true, type: ['stack', 'tiled']},
                    saveAsImage: {show: true}
                }
            },
            xAxis: [{
                type: 'category',
                data: _data.x,
                axisPointer: {
                    type: 'shadow'
                }
            }],
            yAxis: [
                {
                    type: 'value',
                    name: '订单数',
                    min: 0,
                    max: 100,
                    // interval: 2,
                    axisLabel: {
                        formatter: '{value} 单'
                    },
                    axisLine:{
                        show:false
                    },
                    axisLabel:{
                        show:false
                    }
                },
                {
                    type: 'value',
                    name: '交易额',
                    show:false,
                    // min: 0,
                    // max: 5000,
                    // interval: 1000,
                    axisLabel: {
                        formatter: '{value} 元'
                    },
                    axisLabel:{
                        show:false
                    }
                }
            ],
            grid: {
                left: 'left',
                top: 'top',
                right: 5,
                bottom: 55
            },
            series: [{
                name: '订单数',
                type: 'bar',
                smooth: true,
                areaStyle: {
                    normal: {}
                },
                data: _data.num
            },{
                name: '交易额',
                type: 'line',
                smooth: true,
                yAxisIndex: 1,
                areaStyle: {
                    normal: {}
                },
                lineStyle: {
                    normal: {
                        width: 2
                    }
                },
                data: _data.price
            }]
        };
        _trade_chart.setOption(option);
        _trade_chart.hideLoading();
        _trade_chart.resize();
    }
 
    var Controller = {
        index: function () {

            // 基于准备好的dom，初始化echarts实例
            _trade_chart = Echarts.init(document.getElementById('trade_chart'), 'walden');
            _chart_user = Echarts.init(document.getElementById('chart_user'), 'walden');
            
            loadingData();

            $(window).resize(function () {
                _trade_chart.resize();
                _chart_user.resize();
            });

            $(window).on('scroll', function () {
                var scroll = $(window).scrollTop();
                if (scroll < 400) {
                    $('#back-top').fadeOut(500);
                } else {
                    $('#back-top').fadeIn(500);
                }
            });
            $('#back-top a').on("click", function () {
                $('body,html').animate({
                    scrollTop: 0
                }, 100);
                return false;
            });

            $(document).on("click", ".btn-deer-add-tab", function () {
                let url=$(this).data("url");
                top.window.setNav(url);
                return;
                let title=$(this).data("title");
                let id=$(this).data("nodeid");
                top.window.$("<a />").append('<span>' + title + '</span>').prop("href", "javascript:;").attr({
                    url: url,
                    addtabs: id
                }).addClass("hide").appendTo(top.window.document.body).trigger("click");
                setTimeout(function () {
                    top.window.$("#tab_"+id).find('a').trigger("click");
                },100)
                // Backend.api.addtabs(url, title);
            });
            $(document).on("click", ".btn-refresh", function () {
                window.location.reload();
            });
            $(document).on("change", "#trade_select", function () {
                var _val = $(this).val();
                _trade_chart.showLoading();
                _post("deerhome/info",{trade:_val},function(data){
                    _tradePar(data.trade_chart);
                })
            });
            Controller.api.bindevent();
        },
        api: {
            bindevent: function () {
                Form.api.bindevent($("form[role=form]"),function(r,data){
                    $("#feedback-con").val("");
                    Layer.open({title:"反馈成功",content:data.msg,btn:false});
                    return false;
                });
            }
        }
    };

    return Controller;
});
