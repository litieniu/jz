define(['jquery', 'bootstrap', 'backend', 'table', 'form'], function ($, undefined, Backend, Table, Form) {

    var Controller = {
        index: function () {
            // 初始化表格参数配置
            Table.api.init({
                extend: {
                    index_url: 'deerhome/items/index' + location.search,
                    add_url: 'deerhome/items/add',
                    edit_url: 'deerhome/items/edit',
                    del_url: 'deerhome/items/del',
                    multi_url: 'deerhome/items/multi',
                    import_url: 'deerhome/items/import',
                    dragsort_url: '',
                    table: 'deerhome_items',
                }
            });

            var table = $("#table");
            table.on('post-common-search.bs.table', function (event, table) {
                $(".columns-right").hide();
            });
           
            // 初始化表格
            table.bootstrapTable({
                url: $.fn.bootstrapTable.defaults.extend.index_url,
                pk: 'id',
                sortName: 'id',
                search: false,
                // commonSearch: false,
                searchFormVisible: true,
                showToggle: false,
                showColumns: false,
                showExport: false,
                fixedColumns: true,
                fixedNumber: 2,
                fixedRightNumber: 1,
                columns: [
                    [
                        {checkbox: true},
                        {field: 'id', title: __('Id'),fixed:true, operate: false},
                        {
                            field: 'cate_id', title: '服务类目', searchList: function (column) {
                                return Template('categorytpl', {});
                            }, formatter: function (value, row, index) {
                                return '无';
                            }, visible: false
                        },
                        {field: 'cate.name', operate: false, title: __('Cate_id'),formatter:function(value,row,index){
                            return `<span class="label label-primary">${value}</span>`;
                        }},
                        {field: 'name', title: __('Name'), operate: 'LIKE'},
                        {field: 'status', title: __('Status'),searchList:{'1':'正常','2':'下架'}, yes:'1',no:'2', formatter: Table.api.formatter.toggle},
                        {field: 'home', title: __('Home'),searchList:{'1':'是','2':'否'}, yes:'1',no:'2', formatter: Table.api.formatter.toggle},
                        {field: 'recommend', title: __('Recommend'),searchList:{'1':'是','2':'否'}, yes:'1',no:'2', formatter: Table.api.formatter.toggle},
                        {field: 'gg', title: "服务规格", operate: false,formatter: function (value, row, index) {
                            let a='';
                            value.forEach(function(v,i){
                                a+=`<span style='color:#884ffb'>${v.name}</span> ￥${v.price} / ${v.dw}<br/>`
                            });
                            return a;
                        }},
                        {field: 'worker_fc_bl', title: __('Worker_fc_bl'), operate: false,formatter: function (value, row, index) {
                            return value+"%";
                        }},
                        {
                            field: 'anget', title: '参与分销',searchList:{'1':'是','2':'否'}, formatter:function(v,r,index){
                                if(v==2){
                                    return `<span class="label label-primary">否</span>`;
                                }
                                return `<span style='color:#884ffb'>上级分佣</span> ${r.anget_lev1}%<br/><span style='color:#884ffb'>上上级分佣</span> ${r.anget_lev2}%`;
                            }
                        },
                        {field: 'sale_times', title: '真实'+__('Sale_times'), operate: false},
                        {field: 'view_times', title: __('View_times'), operate: false},
                        {field: 'face_image', title: __('Face_image'), operate: false, events: Table.api.events.image, formatter: Table.api.formatter.image},
                        // {field: 'video_file', title: __('Video_file'), operate: false, formatter: Table.api.formatter.file},
                        {field: 'createtime', title: __('Createtime'), operate:false, addclass:'datetimerange', autocomplete:false, formatter: Table.api.formatter.datetime},
                        {field: 'updatetime',  title: __('Updatetime'), operate:false, addclass:'datetimerange', autocomplete:false, formatter: Table.api.formatter.datetime},
                        {field: 'weigh', title: __('Weigh'), operate: false},
                        {field: 'operate', title: __('Operate'), table: table, events: Table.api.events.operate, formatter: Table.api.formatter.operate}
                        

                    ]
                ]
            });

            // 为表格绑定事件
            Table.api.bindevent(table);
        },
        setEditor:function(){
            var setHeight=function(){
                if($(".tox-tinymce").length==0){
                    setTimeout(function(){
                        setHeight();
                    },300);
                    return;
                }
                tinymce.activeEditor.dom.setStyle($(".tox-tinymce"), 'height', '600px');
            }
            setHeight();
        },
        add: function () {
            this.setEditor();
            Controller.api.bindevent();
        },
        edit: function () {
            this.setEditor();
            Controller.api.bindevent();
        },
        api: {
            bindevent: function () {
                Form.api.bindevent($("form[role=form]"));
            }
        }
    };
    return Controller;
});
