define(['jquery', 'bootstrap', 'backend', 'table', 'form','dragsort'], function ($, undefined, Backend, Table, Form) {
    var Controller = {
        index: function () {
            var page_id=$(".deer_page_id").attr("data-deer-id");
            $(".deer_can_edit").on("click", function () {
                $(".deer_can_edit").removeClass("deer_boder");
                $(this).addClass("deer_boder");
                $(".page_deer_tip_area").hide();
                $(".deer_design").hide();
                var page_id = $(".deer_page_id").attr("data-deer-id");
                var block = $(this).attr("data-deer-block");
                $(".deer_design_"+block).show();
                $("#page-id").val(page_id);
                $("#page-block").val(block);
                if(block=="cate"){
                    return;
                }
                $("#deer_sub_box").show();
            });
            $(".deer-select-slide-box").delegate(".deer-select-slide-change","change",function () {
                var type=$(this).val();
                if(type=="item"){
                    $(this).parent().parent().find(".deer-select-slide-change-items").css("display","table");
                }else{
                    $(this).parent().parent().find(".deer-select-slide-change-items").hide();
                    $(this).parent().parent().find(".deer-select-slide-change-items").find(".form-control").val("");
                }
            });
            $(".deer-select-slide-box").delegate(".btn-deer-dialog","click",function () {
                var url=$(this).attr("data-urlpop");
                var title=$(this).attr("title");
                var id=$(this).parent().find(".form-control-id");
                var desc=$(this).parent().find(".form-control-desc");
                Fast.api.open(url,title,{
                    callback:function(value){
                      console.log(value);
                      id.val(value.id).trigger("change");
                      desc.val(value.name).trigger("change");
                    }
                });
            });
            Controller.api.bindevent();
        },
        home: function () {
            Controller.api.bindevent();
        },
        cates: function () {
            Table.api.init({
                extend: {
                    index_url: 'deerhome/cate' + location.search,
                    table: 'deerhome_cate',
                }
            });
            var table = $("#table");
            table.on('post-common-search.bs.table', function (event, table) {
                $(".columns-right").hide();
            });
            table.bootstrapTable({
                url: $.fn.bootstrapTable.defaults.extend.index_url,
                pk: 'id',
                sortName: 'id',
                uniqueId:'id',
                search: false,
                commonSearch: false,
                searchFormVisible: false,
                showToggle: false,
                showColumns: false,
                showExport: false,
                fixedColumns: true,
                fixedNumber: 1,
                fixedRightNumber: 1,
                pagination:false,
                columns: [
                    [
                        {checkbox: true},
                        {field: 'id', title: __('Id'),fixed:true, operate: false},
                        {field: 'name', title: __('Name'),align:"left", operate: false, formatter:function(value,row,index){
                            if(row.cate_id==0){
                                return `<b >${value}</b>`;
                            }
                            return `<span >${value}</span>`;
                        }},
                        {field: 'face_image', title: "图标", operate: false, events: Table.api.events.image, formatter: Table.api.formatter.image},
                        {
                            field: 'operate', title: __('Operate'), width: 85, events: {
                                'click .btn-chooseone': function (e, value, row, index) {
                                    let action=`/pages/classify/cate?id=${row.id}&fid=${row.cate_id}&n=${row.name}`;
                                    if(row.cate_id==0){
                                        action=`/pages/classify/cate?fid=${row.id}&n=${row.name}`;
                                    }
                                    Fast.api.close([{
                                        id: row.id
                                        ,name:row.name
                                        ,img:row.face_image
                                        ,action:action
                                    }]);
                                },
                            }, formatter: function () {
                                return '<a href="javascript:;" class="btn btn-danger btn-chooseone btn-xs"><i class="fa fa-check"></i> ' + __('Choose') + '</a>';
                            }
                        }

                    ]
                ]
            });

            // 为表格绑定事件
            Table.api.bindevent(table);

            $(".btn-select").on("click",function () {
                var ids=Table.api.selectedids(table);
                if(ids.length==0){
                    Toastr.error("请选择");
                    return;
                }
                let arr=[];
                ids.forEach(function (v,i) {
                    let row=table.bootstrapTable('getRowByUniqueId', v);
                    let action=`/pages/classify/cate?id=${row.id}&fid=${row.cate_id}&n=${row.name}`;
                    if(row.cate_id==0){
                        action=`/pages/classify/cate?fid=${row.id}&n=${row.name}`;
                    }
                    arr.push({
                        id:row.id
                        ,name:row.name
                        ,img:row.face_image
                        ,action:action
                    });
                });
                Fast.api.close(arr);
            })
        },
        items: function () {
            Table.api.init({
                extend: {
                    index_url: 'deerhome/items/index' + location.search,
                    table: 'deerhome_items',
                }
            });
            let _multiple=Config.multiple=='true';
            console.log(_multiple);
            var table = $("#table");
            table.on('post-common-search.bs.table', function (event, table) {
                $(".columns-right").hide();
            });
            table.bootstrapTable({
                url: $.fn.bootstrapTable.defaults.extend.index_url,
                pk: 'id',
                sortName: 'id',
                uniqueId:'id',
                search: false,
                commonSearch: true,
                searchFormVisible: true,
                showToggle: false,
                showColumns: false,
                showExport: false,
                fixedColumns: true,
                fixedNumber: 1,
                fixedRightNumber: 1,
                columns: [
                    [
                        {checkbox: true,visible:_multiple},
                        {field: 'id', title: __('Id'),fixed:true, operate: false},
                        {
                            field: 'cate_id', title: '服务类目', searchList: function (column) {
                                return Template('categorytpl', {});
                            }, formatter: function (value, row, index) {
                                return '无';
                            }, visible: false
                        },
                        {field: 'cate.name', operate: false, title: "服务类目",formatter:function(value,row,index){
                            return `<span class="label label-primary">${value}</span>`;
                        }},
                        {field: 'face_image', title: "封面图", operate: false, events: Table.api.events.image, formatter: Table.api.formatter.image},
                        {field: 'name',align:'left', title: __('Name'), operate: 'LIKE'},
                        {field: 'price', title: "价格", operate: false,formatter:function(value,row,index){
                            return `￥${row.price}/${row.dw}`;
                        }},
                        {field: 'sale_times', title: "销量", operate: false},
                        {field: 'view_times', title: "浏览量", operate: false},
                        {
                            field: 'operate', title: __('Operate'), width: 85, events: {
                                'click .btn-chooseone': function (e, value, row, index) {
                                    let obj={id: row.id,name:row.name,img:row.face_image,price:row.price,dw:row.dw};
                                    obj.action=`/pages/productDetail/productDetail?id=${row.id}`;
                                    if(_multiple){
                                        Fast.api.close([obj]);
                                        return;
                                    }
                                    Fast.api.close(obj);
                                },
                            }, formatter: function () {
                                return '<a href="javascript:;" class="btn btn-danger btn-chooseone btn-xs"><i class="fa fa-check"></i> ' + __('Choose') + '</a>';
                            }
                        }

                    ]
                ]
            });

            // 为表格绑定事件
            Table.api.bindevent(table);

            $(".btn-select").on("click",function () {
                var ids=Table.api.selectedids(table);
                if(ids.length==0){
                    Toastr.error("请选择");
                    return;
                }
                let arr=[];
                ids.forEach(function (v,i) {
                    let row=table.bootstrapTable('getRowByUniqueId', v);
                    arr.push({
                        id: row.id
                        ,name:row.name
                        ,img:row.face_image
                        ,price:row.price
                        ,dw:row.dw
                        ,action:`/pages/productDetail/productDetail?id=${row.id}`
                    });
                });
                Fast.api.close(arr);
            })
        },
        api: {
            bindevent: function () {
                Form.api.bindevent($("form[role=form]"),function(data, ret){
                    setTimeout(function(){
                        window.location.reload();
                    },1000)
                });
            }
        }
    };
    return Controller;
});
