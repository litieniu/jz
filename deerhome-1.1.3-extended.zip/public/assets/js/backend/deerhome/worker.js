define(['jquery', 'bootstrap', 'backend', 'table', 'form'], function ($, undefined, Backend, Table, Form) {

    var Controller = {
        index: function () {
            // 初始化表格参数配置
            Table.api.init({
                extend: {
                    index_url: 'deerhome/worker/index' + location.search,
                    add_url: 'deerhome/worker/add',
                    edit_url: 'deerhome/worker/edit',
                    del_url: 'deerhome/worker/del',
                    multi_url: 'deerhome/worker/multi',
                    import_url: 'deerhome/worker/import',
                    table: 'deerhome_worker',
                }
            });

            var table = $("#table");
            //在普通搜索渲染后
            table.on('post-common-search.bs.table', function (event, table) {
                var form = $("form", table.$commonsearch);
                $("input[name='jz_shop_id']", form).addClass("selectpage").data("source", "deerhome/shop/index").data("primaryKey", "id").data("field", "mdname").data("orderBy", "id desc");
                $("input[name='jz_worker_lev_id']", form).addClass("selectpage").data("source", "deerhome/worker_lev/index").data("primaryKey", "id").data("field", "name").data("orderBy", "id desc");
                Form.events.selectpage(form);
            });
            // 初始化表格
            table.bootstrapTable({
                url: $.fn.bootstrapTable.defaults.extend.index_url,
                pk: 'id',
                sortName: 'id',
                search: false,
                showToggle: false,
                showColumns: false,
                searchFormVisible: true,
                fixedColumns: true,
                fixedRightNumber: 1,
                fixedNumber: 1,
                columns: [
                    [
                        {field: 'id', title: __('Id'), operate: false},
                        {field: 'status',addclass:'niceSelect', title: __('Status'), searchList: {"1":__('Status 1'),"2":__('Status 2')},yes:'1',no:'2', formatter: Table.api.formatter.toggle},
                        {field: 'type',addclass:'niceSelect', title: __('Type'), searchList: {"1":__('Type 1'),"2":__('Type 2')}, formatter:function(value,row,index){
                            if(value==1){
                                return `<span class="label label-success">内部</span>`;
                            }
                            return `<span class="label label-warning">入驻</span>`;
                        }},
                        {field: 'jz_shop_id', title: __('Jz_shop_id'), formatter:function(value,row,index){
                            if(value==0){
                                return '-';
                            }
                            return `<span class="label label-primary">${row.shop.mdname}</span>`;
                        }},
                        {field: 'jz_worker_lev_id', title: __('Jz_worker_lev_id'), formatter:function(value,row,index){
                            var html = `<span class="label label-primary">${row.lev.name}</span>`;
                            if(row.lev.fybl>0){
                                html += ` <span class="label label-primary" data-toggle="tooltip" title="额外返佣">+${row.lev.fybl}%</span>`;
                            }
                            return html;
                        }},
                        {field: 'face_image', title: "头像", operate: false, events: Table.api.events.image, formatter: Table.api.formatter.image},
                        {field: 'uname', title: __('Uname'), operate: 'LIKE'},
                        {field: 'utel', title: __('Utel'), operate: 'LIKE'},
                        {field: 'is_working',addclass:'niceSelect', title: "接单中", searchList: {"1":"是","2":"否"}, formatter:function(value,row,index){
                            if(value==1){
                                return `<span class="label label-success"><i class="fa fa-check"></i></span>`;
                            }
                            return `<span class="label label-warning" style="background:#ccc;"><i class="fa fa-close"></i></span>`;
                        }},
                        {field: 'times', title: __('Times'), operate: false},
                        {field: 'money_left', title: __('Money_left'), operate:'BETWEEN'},
                        {field: 'money_dj', title: __('Money_dj'), operate:'BETWEEN'},
                        {field: 'money_tx', title: __('Money_tx'), operate:'BETWEEN'},
                       
                        {field: 'id', title: "排班", operate:false, formatter:function(value,row,index){
                            return ` <a href="deerhome/worker_day/index?jz_worker_id=${value}" class="btn btn-xs btn-success-2 btn-dialog" data-area='["100%","100%"]' title="【${row.uname}】排班管理" data-field-index="10" data-table-id="table" data-row-index="${index}"><i class="fa fa-calendar"></i> 排班管理</a>`;
                        }},
                        {field: 'id', title: "资金明细", operate:false, formatter:function(value,row,index){
                            return ` <a href="deerhome/money_log/index?jz_worker_id=${value}" class="btn btn-xs btn-success-2 btn-dialog" title="【${row.uname}】资金明细" ><i class="fa fa-jpy"></i> 查看</a>`;
                        }},
                        {field: 'id', title: "银行卡", operate:false, formatter:function(value,row,index){
                            if(!row.card.id){
                                return '<span style="color:#7d7979;">未填写</span>';
                            }
                            return ` <a href="deerhome/worker_card/edit?ids=${row.card.id}" class="btn btn-xs btn-success-2 btn-dialog" title="【${row.uname}】银行卡" ><i class="fa fa-credit-card"></i> 查看</a>`;
                        }},
                        {field: 'sfz_a_image', title: "身份证正面", operate: false, events: Table.api.events.image, formatter: Table.api.formatter.image},
                        {field: 'sfz_b_image', title: "身份证反面", operate: false, events: Table.api.events.image, formatter: Table.api.formatter.image},
                        {field: 'zs_image', title: "技能证书", operate: false, events: Table.api.events.image, formatter: Table.api.formatter.image},
                        {field: 'wxid', title: "微信id", operate: 'LIKE'},
                        {field: 'addtime', title: __('Addtime'), operate:'RANGE', addclass:'datetimerange', autocomplete:false},
                        {field: 'operate', title: __('Operate'), table: table, events: Table.api.events.operate, formatter: Table.api.formatter.operate}
                    ]
                ]
            });

            // 为表格绑定事件
            Table.api.bindevent(table);
        },
        add: function () {
            Controller.api.bindevent();
        },
        edit: function () {
            Controller.api.bindevent();
        },
        api: {
            bindevent: function () {
                Form.api.bindevent($("form[role=form]"));
            }
        }
    };
    return Controller;
});
