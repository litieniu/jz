define(['jquery', 'bootstrap', 'backend', 'table', 'form'], function ($, undefined, Backend, Table, Form,JNice) {

    var Controller = {
        index: function () {
            // 初始化表格参数配置
            Table.api.init({
                extend: {
                    index_url: 'deerhome/order/index' + location.search,
                    add_url: 'deerhome/order/add',
                    edit_url: 'deerhome/order/edit',
                    del_url: 'deerhome/order/del',
                    multi_url: 'deerhome/order/multi',
                    import_url: 'deerhome/order/import',
                    table: 'deerhome_order',
                }
            });

            var table = $("#table");
            $.fn.bootstrapTable.locales[Table.defaults.locale]['formatSearch'] = function(){return "订单号、手机号";};
            //在普通搜索渲染后
           
            // 初始化表格
            table.bootstrapTable({
                url: $.fn.bootstrapTable.defaults.extend.index_url,
                pk: 'id',
                sortName: 'id',
                fixedColumns: true,
                fixedNumber: 2,
                fixedRightNumber: 1,
                columns: [
                    [
                        {checkbox: true,formatter:function (value,row,index) {
                            if(row.status!=8){
                                return {
                                    disabled:true
                                };
                            }
                        }},
                        {field: 'jz_user_id', title: __('Jz_user_id'),visible:false,operate:false},
                        {field: 'status', title: __('Status')
                        , searchList: {"1":__('Status 1'),"2":__('Status 2'),"3":__('Status 3'),"4":__('Status 4'),"5":__('Status 5'),"6":__('Status 6'),"7":__('Status 7'),"8":__('Status 8')}
                        , formatter: function (value, row, index) {
                            var color = "info";
                            switch (value) {
                                case 1:
                                    color = "primary";
                                    break;
                                case 2:
                                    color = "warning";
                                    break;
                                case 3:
                                    color = "info";
                                    break;
                                case 4:
                                    color = "info";
                                    break;
                                case 5:
                                    color = "success";
                                    break;
                                case 6:
                                    color = "danger";
                                    break;
                                case 7:
                                    color = "danger";
                                    break;
                                case 8:
                                    color = "default";
                                    break;
                                default:
                                    break;
                            }
                            return '<span class="label label-' + color + '">' + __('Status '+row.status) + '</span>';
                        }
                    },
                        {field: 'sn', title: __('Sn'), operate: '='},
                        {field: 'is_card', title: __('次卡订单'),custom:{"1":"success","2":"primary"}, addClass:"selectpicker",  searchList: {'1':'是','2':'否'}, operate: '=',sortable:true, formatter: Table.api.formatter.label},
                        {field: 'item_name', title: __('Item_name'), operate: 'LIKE'},
                        {field: 'item_gg_name', title: __('Item_gg_name'), operate: 'LIKE'},
                        {field: 'num', title: __('Num'),operate:false,sortable:true},
                        {field: 'price_item_total', title: "服务金额", operate:false,sortable:true},
                        {field: 'price_bcj', title: "补差价",operate:false,sortable:true},
                        {field: 'price_light', title: __('Price_light'), operate:false,sortable:true},
                        {field: 'price_total', title: __('Price_total'), operate:false,sortable:true},
                        {field: 'price_discount', title: "会员折后总价", operate:false,sortable:true},
                        {field: 'price_yh', title: __('Price_yh'),sortable:true, operate:false,formatter:function (value,row,index) {
                            if(value==0){
                                return '0';
                            }
                            return '-'+value;
                        }},
                        {field: 'price_need_pay', title: __('Price_need_pay'),operate:false,sortable:true},
                        {field: 'price_payed', title: __('Price_payed'), operate:false,sortable:true,formatter:function (value,row,index) {
                            return '<span style="color:#f75444;">￥'+value+'</span>&nbsp;<a href="deerhome/order_pay_log/index/order_sn/'+row.sn+'" class="btn btn-xs btn-primary btn-dialog"  data-shade="0.3" title="【订单'+row.sn+'】支付流水" >流水</a>';
                        }},
                        {field: 'user_name', title: __('User_name'), operate: 'LIKE'},
                        {field: 'user_phone', title: __('User_phone'), operate: 'LIKE'},
                        {field: 'address_title', title: __('Address_title'), operate: 'LIKE'},
                        {field: 'address_detail', title: __('Address_detail'), operate: 'LIKE'},
                        {field: 'address_address', title: __('Address_address'), operate: 'LIKE'},
                        {field: 'date_day', title: __('Date_day'), operate:'RANGE', addclass:'datetimerange', autocomplete:false,sortable:true},
                        {field: 'date_time', title: __('Date_time'), operate:'RANGE', addclass:'', autocomplete:false,operate:false},
                        {field: 'note', title: __('Note'), operate: 'LIKE'},
                        // {field: 'worker_id', title: __('Worker_id')},
                        {field: 'worker_name', title: __('Worker_name'), operate: '='},
                        {field: 'worker_price', title: __('Worker_price'), operate:'BETWEEN',sortable:true},
                        {field: 'worker_price_note', title: __('Worker_price_note'),operate:false},
                        {field: 'worker_price_to_wallet',addClass:"selectpicker",  title: __('Worker_price_to_wallet'),custom:{"0":"primary","1":"success"}, searchList: {"0":"未结算","1":"已结算"}, formatter: Table.api.formatter.label},
                        {field: 'time_add', title: __('Time_add'), operate:'RANGE', addclass:'datetimerange', autocomplete:false,sortable:true},
                        {field: 'time_done', title: __('Time_done'), operate:'RANGE', addclass:'datetimerange', autocomplete:false,sortable:true},
                        {field: 'operate', title: __('Operate'), table: table, events: Table.api.events.operate, formatter:Table.api.formatter.buttons,
                        buttons:[
                            {
                                name: 'detail',
                                text: '详情',
                                title: '订单详情',
                                classname: 'btn btn-xs btn-success btn-dialog',
                                extend:' data-area=\'["800px", "700px"]\' data-shade=\'0.3\'',
                                icon: '',
                                url: 'deerhome/order/detail?sn={sn}',
                                visible: function (row) {
                                    return true;
                                }
                            },
                            {
                                name: 'paidan',
                                text: '派单',
                                title: '派单',
                                classname: 'btn btn-xs btn-success btn-dialog',
                                icon: 'fa fa-paper-plane-o',
                                url: 'deerhome/order/paidan',
                                extend:' data-area=\'["400px", "500px"]\' data-shade=\'0.3\'',
                                visible: function (row) {
                                    if(row.status==2 || row.status==3){
                                        return true;
                                    }
                                    return false;
                                }
                            }
                            ,{
                                name: 'log',
                                text: '日志',
                                title: '订单日志',
                                classname: 'btn btn-xs btn-info btn-dialog',
                                extend:' data-area=\'["400px", "500px"]\' data-shade=\'0.3\'',
                                icon: '',
                                url: 'deerhome/order/log',
                                visible: function (row) {
                                    return true;
                                }
                            }
                        ]}
                    ]
                ]
            });

            // 为表格绑定事件
            Table.api.bindevent(table);
        },
        add: function () {
            Controller.api.bindevent();
        },
        edit: function () {
            Controller.api.bindevent();
        },
        paidan: function () {
            Controller.api.bindevent();
        },
        detail: function () {
            $('body').on('click', '.btn-map-nav', function () {
                let url=$(this).attr('data-url');
                (window.top?window.top:window.self).Layer.open({
                    type: 2,
                    title: '导航',
                    content: url,
                    area: ['100%', '100%'],
                    maxmin: false,
                });
            })
            $('body').on('click', '.data-tips-image', function () {
                var img = new Image();
                var imgWidth = this.getAttribute('data-width') || '480px';
                var body=(window.top?window.top:window.self);
                img.onload = function () {
                    var $content = $(img).appendTo('body').css({background: '#fff', width: imgWidth, height: 'auto'});
                    Layer.open({
                        type: 1, area: imgWidth, title: false, closeBtn: 1,
                        skin: 'layui-layer-nobg', shadeClose: true, content: $content,
                        end: function () {
                            $(img).remove();
                        },
                        success: function () {
        
                        }
                    });
                };
                img.onerror = function (e) {
        
                };
                img.src = this.getAttribute('data-tips-image') || this.src;
            });
        },
        api: {
            bindevent: function () {
                Form.api.bindevent($("form[role=form]"));
            }
        }
    };
    return Controller;
});
