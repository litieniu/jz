define(['jquery', 'bootstrap', 'backend', 'table', 'form'], function ($, undefined, Backend, Table, Form) {
 
    var Controller = {
        index: function () {
            
            // 初始化表格参数配置
            Table.api.init({
                extend: {
                    index_url: 'deerhome/cate/index' + location.search,
                    add_url: 'deerhome/cate/add',
                    edit_url: 'deerhome/cate/edit',
                    del_url: 'deerhome/cate/del',
                    multi_url: 'deerhome/cate/multi',
                    import_url: 'deerhome/cate/import',
                    dragsort_url: '',
                    table: 'cate',
                }
            });

            var table = $("#table");
            //在普通搜索渲染后
            table.on('post-common-search.bs.table', function (event, table) {
                var form = $("form", table.$commonsearch);
                $("input[name='cateparent.name']", form).addClass("selectpage").data("source", "jz/cate/cate1").data("primaryKey", "name").data("field", "name").data("orderBy", "id desc");
                $(".columns-right").hide();
                Form.events.selectpage(form);
            });
            // 初始化表格
            table.bootstrapTable({
                url: $.fn.bootstrapTable.defaults.extend.index_url,
                pk: 'id',
                sortName: 'weigh',
                showToggle: false,
                showColumns: false,
                showExport: false,
                search: false,
                pagination:false,
                searchFormVisible: false,
                columns: [
                    [
                        {checkbox: true},
                        {field: 'id', title: __('Id'), operate: false},
                        
                        {field: 'name', title: __('Name'),align:"left", operate: 'LIKE', formatter:function(value,row,index){
                            if(row.cate_id==0){
                                return `<b >${value}</b>`;
                            }
                            return `<span >${value}</span>`;
                        }},
                        {field: 'face_image', title: __('Face_image'), operate: false, events: Table.api.events.image, formatter: Table.api.formatter.image},
                        {field: 'home', title: __('Home'),searchList:{'1':'展示','2':'不展示'}, yes:'1',no:'2', formatter:function(value,row,index){
                            if(row.cate_id>0){
                                return `-`;
                            }
                            return `<a href="javascript:;" data-toggle="tooltip"  class="btn-change " data-index="${index}" data-id="${row.id}" data-params="home=${value==1?2:1}" data-original-title="点击切换"><i class="fa fa-toggle-on text-success text-success ${value==2?'fa-flip-horizontal text-gray':''} fa-2x"></i></a>`;
                            return Table.api.formatter.toggle(value,row,index);
                        }},
                        {field: 'can_apply', title: '支持入驻',searchList:{'1':'是','2':'否'}, yes:'1',no:'2', formatter:function(value,row,index){
                            if(row.cate_id>0){
                                return `-`;
                            }
                            return `<a href="javascript:;" data-toggle="tooltip"  class="btn-change " data-index="${index}" data-id="${row.id}" data-params="can_apply=${value==1?2:1}" data-original-title="点击切换"><i class="fa fa-toggle-on text-success text-success ${value==2?'fa-flip-horizontal text-gray':''} fa-2x"></i></a>`;
                            return Table.api.formatter.toggle(value,row,index);
                        }},
                        {field: 'status', title: __('Status'),searchList:{'1':'正常','2':'停用'}, yes:'1',no:'2', formatter: Table.api.formatter.toggle},
                        {field: 'ad_image', title: '广告图', operate: false, events: Table.api.events.image, formatter: Table.api.formatter.image},
                        {field: 'fw', title: "服务数量", operate: false},
                        {field: 'weigh', title: __('Weigh'), operate: false},
                        {field: 'createtime', title: __('Createtime'), operate:'RANGE', addclass:'datetimerange', operate: false, autocomplete:false, formatter: Table.api.formatter.datetime},
                        {field: 'operate', title: __('Operate'), table: table, events: Table.api.events.operate, formatter: Table.api.formatter.operate}
                    ]
                ]
            });

            // 为表格绑定事件
            Table.api.bindevent(table);
        },
        add: function () {
            Controller.watch();
            Controller.api.bindevent();
        },
        edit: function () {
            Controller.watch();
            Controller.api.bindevent();
        },
        watch:function(){
            $(".deer-select-slide-box").delegate(".deer-select-slide-change","change",function () {
                var type=$(this).val();
                if(type=="item"){
                    $(this).parent().parent().find(".deer-select-slide-change-items").css("display","table");
                }else{
                    $(this).parent().parent().find(".deer-select-slide-change-items").hide();
                    $(this).parent().parent().find(".deer-select-slide-change-items").find(".form-control").val("");
                }
            });
            $(".deer-select-slide-box").delegate(".btn-deer-dialog","click",function () {
                var url=$(this).attr("data-urlpop");
                var title=$(this).attr("title");
                var id=$(this).parent().find(".form-control-id");
                var desc=$(this).parent().find(".form-control-desc");
                Fast.api.open(url,title,{
                    callback:function(value){
                      console.log(value);
                      id.val(value.id).trigger("change");
                      desc.val(value.name).trigger("change");
                    }
                });
            });
        },
        api: {
            bindevent: function () {
                Form.api.bindevent($("form[role=form]"));
            }
        }
    };
    return Controller;
});
