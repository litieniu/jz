define(['jquery', 'bootstrap', 'backend', 'table', 'form'], function ($, undefined, Backend, Table, Form) {

    var Controller = {
        index: function () {
            // 初始化表格参数配置
            Table.api.init({
                extend: {
                    index_url: 'deerhome/charge_sys/index' + location.search,
                    add_url: 'deerhome/charge_sys/add',
                    edit_url: 'deerhome/charge_sys/edit',
                    del_url: 'deerhome/charge_sys/del',
                    multi_url: 'deerhome/charge_sys/multi',
                    import_url: 'deerhome/charge_sys/import',
                    table: 'deerhome_sys_charge',
                }
            });

            var table = $("#table");
            table.on('post-common-search.bs.table', function (event, table) {
                $(".columns-right").hide();
            });
            // 初始化表格
            table.bootstrapTable({
                url: $.fn.bootstrapTable.defaults.extend.index_url,
                pk: 'id',
                sortName: 'price',
                sortOrder: 'asc',
                search: false,
                searchFormVisible: false,
                columns: [
                    [
                        {checkbox: true},
                        {field: 'price', title: __('Price'), operate:'BETWEEN',sortable:true},
                        {field: 'give', title: __('Give'),sortable:true},
                    ]
                ]
            });

            // 为表格绑定事件
            Table.api.bindevent(table);
        },
        add: function () {
            Controller.api.bindevent();
        },
        edit: function () {
            Controller.api.bindevent();
        },
        api: {
            bindevent: function () {
                Form.api.bindevent($("form[role=form]"));
            }
        }
    };
    return Controller;
});
