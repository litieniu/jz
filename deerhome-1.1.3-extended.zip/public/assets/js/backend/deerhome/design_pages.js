define(['jquery', 'bootstrap', 'backend', 'table', 'form'], function ($, undefined, Backend, Table, Form) {

    var Controller = {
        index: function () {
            // 初始化表格参数配置
            Table.api.init({
                extend: {
                    index_url: 'deerhome/design_pages/index' + location.search,
                    add_url: 'deerhome/design_pages/add',
                    edit_url: 'deerhome/design_pages/edit',
                    del_url: 'deerhome/design_pages/del',
                    multi_url: 'deerhome/design_pages/multi',
                    import_url: 'deerhome/design_pages/import',
                    table: 'deerhome_design_pages',
                }
            });

            var table = $("#table");
            $.fn.bootstrapTable.locales[Table.defaults.locale]['formatSearch'] = function(){return "页面名称";};
            table.on('post-common-search.bs.table', function (event, table) {
                $(".columns-right").hide();
            });
            // 初始化表格
            table.bootstrapTable({
                url: $.fn.bootstrapTable.defaults.extend.index_url,
                pk: 'id',
                sortName: 'id',
                dblClickToEdit: false,
                columns: [
                    [
                        {field: 'id', title: __('Id'), operate: false},
                        {field: 'page_title', title: __('Page_title'), operate: 'LIKE'},
                        {field: 'status', title: __('Status'), searchList: {"1":__('Status 1'),"2":__('Status 2')}, formatter: function (value, row, index) {
                            if(value==1){
                                return '<span class="label label-success"><i class="iconfont icon-shenhe" style="font-size:12px;"></i> 已发布</span>';
                            }else{
                                return '<span class="label label-danger"><i class="iconfont icon-loudou" style="font-size:12px;"></i> 草稿箱</span>';
                            }
                        }},
                        {field: 'cate', title: __('Cate'), searchList: {"1":__('Cate 1'),"2":__('Cate 2')},custom:{"1":"primary","2":"warning"}, formatter: Table.api.formatter.label},
                        {field: 'update_time', title: __('Update_time'), operate: false, addclass:'datetimerange', autocomplete:false},
                        {field: 'id', title:"操作", operate: false, formatter: function (value, row, index) {
                            let url_design = Fast.api.fixurl('deerhome/design/home?id='+value);
                            let url_edit = Fast.api.fixurl('deerhome/design_pages/edit?ids='+value);
                            var actions = [];
                            actions.push('<a class="btn btn-success btn-xs" target="_blank" href="'+url_design+'" data-toggle="tooltip" data-btn="edit" data-title="去装修页面" data-refresh="true" data-table-id="table"><i class="fa fa-code"></i> 去装修</a>');

                            actions.push('<a style="margin-left:6px;" href="'+url_edit+'" class="btn btn-xs btn-info btn-editone btn-dialog" data-toggle="tooltip" data-container="body" title="编辑" data-shade="0.3" data-area=\'["400px","300px"]\' data-table-id="table" ><i class="fa fa-pencil"></i></a>');

                            if(row.can_del==1){
                                actions.push('<a  style="margin-left:6px;" class="btn btn-danger btn-xs btn-del" data-toggle="tooltip" data-btn="del" data-id="'+value+'" data-title="删除" ><i class="fa fa-trash"></i></a>');
                            }
                            return actions.join('');
                        }}
                    ]
                ]
            });

            // 为表格绑定事件
            Table.api.bindevent(table);
        },
        add: function () {
            Controller.api.bindevent();
        },
        edit: function () {
            Controller.api.bindevent();
        },
        api: {
            bindevent: function () {
                Form.api.bindevent($("form[role=form]"));
            }
        }
    };
    return Controller;
});
