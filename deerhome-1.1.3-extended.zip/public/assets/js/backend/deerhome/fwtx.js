define(['jquery', 'bootstrap', 'backend', 'table', 'form'], function ($, undefined, Backend, Table, Form) {

    var Controller = {
        index: function () {
            // 初始化表格参数配置
            Table.api.init({
                extend: {
                    index_url: 'deerhome/fwtx/index' + location.search,
                    add_url: 'deerhome/fwtx/add',
                    edit_url: 'deerhome/fwtx/edit',
                    multi_url: 'deerhome/fwtx/multi',
                    import_url: 'deerhome/fwtx/import',
                    table: 'deerhome_worker_money_log',
                }
            });

            var table = $("#table");
            $.fn.bootstrapTable.locales[Table.defaults.locale]['formatSearch'] = function(){return "服务人员搜索";};
            table.on('post-common-search.bs.table', function (event, table) {
                var form = $("form", table.$commonsearch);
                $("input[name='bank']", form).addClass("selectpage").data("source", "deerhome/worker_card/index").data("primaryKey", "id").data("field", "bank").data("orderBy", "id desc");
            });
            // 初始化表格
            table.bootstrapTable({
                url: $.fn.bootstrapTable.defaults.extend.index_url,
                pk: 'id',
                sortName: 'id',
                fixedColumns: true,
                fixedNumber: 1,
                fixedRightNumber: 1,
                columns: [
                    [
                        {field: 'id', title: __('Id'),operate:false},
                        {field: 'status', title: __('Status'),addclass:'niceSelect', searchList: {"1":__('Status 1'),"2":__('Status 2'),"3":__('Status 3')}, formatter: function(value, row, index){
                            if(value==1){
                                return '<span class="label label-danger">' + __('Status '+row.status) + '</span>';
                            }
                            if(value==2){
                                return '<span class="label label-success">' + __('Status '+row.status) + '</span>';
                            }
                            if(value==3){
                                return '<span class="label label-warning">' + __('Status '+row.status) + '</span>';
                            }
                            return '未知';
                        }},
                        {field: 'type', title: __('Type'),addclass:'niceSelect', searchList: {"分销提现":"分销提现","服务提现":"服务提现"}, formatter: Table.api.formatter.label},
                        {field: 'worker.uname', title: '申请人', operate: '=',formatter: function (value, row, index) {
                            if(row.jz_worker_id>0){
                                return row.worker.uname + ' (ID' + row.worker.id + ')';
                            }
                            return row.user.uname + ' (UID' + row.user.id + ')';
                        }},
                        {field: 'skr', title: "收款人", operate:'='},
                        {field: 'bank', title: "开户行"},
                        {field: 'bankcard', title: "银行卡号", operate:'='},
                        {field: 'price', title: __('Price'), operate:'BETWEEN'},
                        {field: 'note', title: __('Note'), operate: 'LIKE',operate:false},
                        {field: 'addtime', title: __('Addtime'), operate:'RANGE', addclass:'datetimerange', autocomplete:false},
                        {field: 'sh_ren', title: "处理人", operate:'=',operate:false},
                        {field: 'donetime', title: __('Donetime'), operate:'RANGE', addclass:'datetimerange', autocomplete:false},
                        {field: 'operate', title: __('Operate'), table: table, 
                        events: Table.api.events.operate,
                        buttons:[
                            {
                                name: 'btn_sh',
                                text: `审核`,
                                title: function(row){ return `【ID${row.id}】审核`},
                                classname: 'btn btn-xs btn-success btn-dialog',
                                icon: 'fa fa-check',
                                url: `deerhome/fwtx/edit`,
                                visible: function (row) {
                                    if(row.status!=1){
                                        return false;
                                    }
                                    return true;
                                }
                            }
                        ],
                        formatter:Table.api.formatter.buttons
                        }
                    ]
                ]
            });

            // 为表格绑定事件
            Table.api.bindevent(table);
        },
        add: function () {
            Controller.api.bindevent();
        },
        edit: function () {
            Controller.api.bindevent();
        },
        api: {
            bindevent: function () {
                Form.api.bindevent($("form[role=form]"));
            }
        }
    };
    return Controller;
});
