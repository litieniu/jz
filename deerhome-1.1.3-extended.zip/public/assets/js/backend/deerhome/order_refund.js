define(['jquery', 'bootstrap', 'backend', 'table', 'form'], function ($, undefined, Backend, Table, Form) {

    var Controller = {
        index: function () {
            // 初始化表格参数配置
            Table.api.init({
                extend: {
                    index_url: 'deerhome/order_refund/index' + location.search,
                    add_url: 'deerhome/order_refund/add',
                    edit_url: 'deerhome/order_refund/edit',
                    del_url: 'deerhome/order_refund/del',
                    multi_url: 'deerhome/order_refund/multi',
                    import_url: 'deerhome/order_refund/import',
                    table: 'deerhome_order_refund',
                }
            });

            var table = $("#table");
            // 初始化表格
            table.bootstrapTable({
                url: $.fn.bootstrapTable.defaults.extend.index_url,
                pk: 'id',
                sortName: 'id',
                fixedColumns: true,
                fixedRightNumber: 1,
                columns: [
                    [
                        {field: 'id', title: __('Id'), operate: false},
                        {field: 'status', title: __('Status'), searchList: {"1":__('Status 1'),"2":__('Status 2'),"3":__('Status 3')}, formatter: Table.api.formatter.label,custom:{'1': 'warning', '2':'success','3': 'danger'}},
                        {field: 'user.uname', title: "申请人"},
                        {field: 'order_sn', title: __('Order_sn'), operate: 'LIKE'},
                        {field: 'lx', title: __('Lx'), operate: 'LIKE'},
                        {field: 'price', title: __('Price'), operate:'BETWEEN'},
                        {field: 'price_refund', title: __('Price_refund'), operate:'BETWEEN'},
                        {field: 'note', title: __('Note'), operate: 'LIKE'},
                        {field: 'addtime', title: __('Addtime'), operate:'RANGE', addclass:'datetimerange', autocomplete:false},
                        {field: 'ac_admin', title: __('Ac_admin'), operate: 'LIKE'},
                        {field: 'ac_admin_note', title: "处理备注", operate: 'LIKE', operate: false},
                        {field: 'ac_admin_time', title: __('Ac_admin_time'), operate:'RANGE', addclass:'datetimerange', autocomplete:false},
                        {field: 'operate', title: __('Operate'),
                            table: table,
                            events: Table.api.events.operate,
                            buttons:[
                                {
                                    name: 'btn_sh',
                                    text: `审核`,
                                    title: function(row){ return `【${row.user.uname}】审核`},
                                    classname: 'btn btn-xs btn-success btn-dialog',
                                    icon: 'fa fa-check',
                                    url: `deerhome/order_refund/edit`,
                                    visible: function (row) {
                                        if(row.status!=1){
                                            return false;
                                        }
                                        return true;
                                    }
                                }
                            ],
                            formatter:Table.api.formatter.buttons
                        }
                    ]
                ]
            });

            // 为表格绑定事件
            Table.api.bindevent(table);
        },
        add: function () {
            Controller.api.bindevent();
        },
        edit: function () {
            Controller.api.bindevent();
        },
        api: {
            bindevent: function () {
                Form.api.bindevent($("form[role=form]"));
            }
        }
    };
    return Controller;
});
