define(['jquery', 'bootstrap', 'backend', 'table', 'form'], function ($, undefined, Backend, Table, Form) {

    var Controller = {
        index: function () {
            // 初始化表格参数配置
            Table.api.init({
                extend: {
                    index_url: 'deerhome/xcxmsg/index' + location.search,
                    add_url: 'deerhome/xcxmsg/add',
                    edit_url: 'deerhome/xcxmsg/edit',
                    del_url: 'deerhome/xcxmsg/del',
                    multi_url: 'deerhome/xcxmsg/multi',
                    import_url: 'deerhome/xcxmsg/import',
                    table: 'deerhome_xcxmsg',
                }
            });

            var table = $("#table");
            table.on('post-common-search.bs.table', function (event, table) {
                $(".columns-right").hide();
            });
            // 初始化表格
            table.bootstrapTable({
                url: $.fn.bootstrapTable.defaults.extend.index_url,
                pk: 'id',
                sortName: 'id',
                uniqueId: 'id',
                search: false,
                columns: [
                    [
                        {checkbox: true},
                        {field: 'pushed', title: "推送到微信后台",searchList:{"1":"是","2":"否"}, formatter: Table.api.formatter.label},
                        {field: 'title', title: __('Title'), operate: 'LIKE'},
                        {field: 'tplid', title: __('Tplid'), operate: '='},
                        {field: 'keyword', title: __('Keyword'), operate: 'LIKE', class: 'autocontent', formatter: Table.api.formatter.content},
                        {field: 'kidListDesc', title: '关键词', operate: 'LIKE'},
                    ]
                ]
            });

            $(".btn-pushtowx").click(function () {
                let ids = Table.api.selectedids(table);
                if (ids.length == 0) {
                    Layer.msg("请选择要推送的模板")
                    return false;
                }
                let data=[];
                for(let i=0;i<ids.length;i++){
                    let row=table.bootstrapTable('getRowByUniqueId',ids[i]);
                    data[i]={};
                    data[i].id=row.id;
                    data[i].title=row.title;
                    data[i].tid=row.tid;
                    data[i].kidList=row.keyword;
                }
                let index=0;
                let ok=0;
                let err=[];
                let push=function(){
                    if(index>=data.length){
                        table.bootstrapTable('refresh');
                        Layer.open({title:'处理完成',btn:false,content:"<b>合计推送"+data.length+"条，成功"+ok+"条，失败"+err.length+"条</b><br/>"+err.join("<br/>")});
                        return false;
                    }
                    Layer.msg("正在推送第 "+(index+1)+"/"+data.length+" 条数据");
                    Fast.api.ajax({
                            url: "deerhome/xcxmsg/push_to_wx",
                            data:data[index],
                            loading: true
                        },
                        function (res,ret) {
                            index++;
                            ok++;
                            setTimeout(push,500);
                        },
                        function (res,ret) {
                            err.push("【"+data[index].title+"】"+ret.msg);
                            index++;
                            setTimeout(push,500);
                        }
                    );
                }
                push();
            })
            // 为表格绑定事件
            Table.api.bindevent(table);
        },
        add: function () {
            Controller.api.bindevent();
        },
        edit: function () {
            Controller.api.bindevent();
        },
        api: {
            bindevent: function () {
                Form.api.bindevent($("form[role=form]"));
            }
        }
    };
    return Controller;
});
