define(['jquery', 'bootstrap', 'backend', 'table', 'form'], function ($, undefined, Backend, Table, Form) {

    var Controller = {
        index: function () {
            $(".btn-change").each(function () {
                let id=$(this).data("id");
                if($("#"+id).val()=="on"){
                    $(this).find("i.fa-toggle-on").removeClass("fa-flip-horizontal text-gray hide");
                }else{
                    $(this).find("i.fa-toggle-on").addClass("fa-flip-horizontal text-gray").removeClass("hide");
                }
                $(this).find("i.toggle-loading").addClass("hide");
            })
            $(document).on("click", ".btn-change", function () {
                let id=$(this).data("id");
                if($("#"+id).val()=="on"){
                    $("#"+id).val("off");
                    $(this).find("i").addClass("fa-flip-horizontal text-gray");
                }else{
                    $("#"+id).val("on");
                    $(this).find("i").removeClass("fa-flip-horizontal text-gray");
                }
            })
            Controller.api.bindevent();
        },
        api: {
            bindevent: function () {
                Form.api.bindevent($("form[role=form]"));
            }
        }
    };
    return Controller;
});
