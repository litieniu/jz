define(['jquery', 'bootstrap', 'backend', 'table', 'form'], function ($, undefined, Backend, Table, Form) {

    var Controller = {
        index: function () {
            // 初始化表格参数配置
            Table.api.init({
                extend: {
                    index_url: 'deerhome/user_collected/index' + location.search,
                    add_url: 'deerhome/user_collected/add',
                    edit_url: 'deerhome/user_collected/edit',
                    del_url: 'deerhome/user_collected/del',
                    multi_url: 'deerhome/user_collected/multi',
                    import_url: 'deerhome/user_collected/import',
                    table: 'deerhome_user_collected',
                }
            });

            var table = $("#table");
            table.on('post-common-search.bs.table', function (event, table) {
                $(".columns-right").hide();
                $(".fixed-table-toolbar").hide();
            });
            // 初始化表格
            table.bootstrapTable({
                url: $.fn.bootstrapTable.defaults.extend.index_url,
                pk: 'id',
                sortName: 'id',
                fixedColumns: true,
                fixedNumber: 1,
                fixedRightNumber: 1,
                search: false,
                searchFormVisible: false,
                dblClickToEdit:false,
                columns: [
                    [
                        {field: 'cate', title: '名称',formatter:function(value,row,index){
                            if(row.type==3){
                                return `${row.note}`;
                            }
                            return `${row.items.name}`;
                        }},
                        {field: 'add_time', title: "时间", operate:'RANGE', addclass:'datetimerange', autocomplete:false},
                    ]
                ]
            });

            // 为表格绑定事件
            Table.api.bindevent(table);
        },
        add: function () {
            Controller.api.bindevent();
        },
        edit: function () {
            Controller.api.bindevent();
        },
        api: {
            bindevent: function () {
                Form.api.bindevent($("form[role=form]"));
            }
        }
    };
    return Controller;
});
