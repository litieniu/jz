define(['jquery', 'bootstrap', 'backend', 'table', 'form'], function ($, undefined, Backend, Table, Form) {

    var Controller = {
        index: function () {
            // 初始化表格参数配置
            Table.api.init({
                extend: {
                    index_url: 'deerhome/open_city/index' + location.search,
                    add_url: 'deerhome/open_city/add',
                    edit_url: 'deerhome/open_city/edit',
                    del_url: 'deerhome/open_city/del',
                    multi_url: 'deerhome/open_city/multi',
                    import_url: 'deerhome/open_city/import',
                    table: 'deerhome_open_city',
                }
            });

            var table = $("#table");
            table.on('post-common-search.bs.table', function (event, table) {
                $(".columns-right").hide();
            });
            // 初始化表格
            table.bootstrapTable({
                url: $.fn.bootstrapTable.defaults.extend.index_url,
                pk: 'id',
                sortName: 'id',
                search: false,
                searchFormVisible: true,
                columns: [
                    [
                        {checkbox: true},
                        {field: 'id', title: __('Id'), operate: false},
                        {field: 'cityname', title: __('Cityname'), operate: 'LIKE'},
                        {field: 'province', title: __('Province'), operate: 'LIKE'},
                    ]
                ]
            });

            // 为表格绑定事件
            Table.api.bindevent(table);
        },
        add: function () {
            Controller.api.bindevent();
        },
        edit: function () {
            Controller.api.bindevent();
        },
        api: {
            bindevent: function () {
                Form.api.bindevent($("form[role=form]"));
            }
        }
    };
    return Controller;
});
