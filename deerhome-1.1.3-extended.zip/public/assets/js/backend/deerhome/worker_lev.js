define(['jquery', 'bootstrap', 'backend', 'table', 'form'], function ($, undefined, Backend, Table, Form) {

    var Controller = {
        index: function () {
            // 初始化表格参数配置
            Table.api.init({
                extend: {
                    index_url: 'deerhome/worker_lev/index' + location.search,
                    add_url: 'deerhome/worker_lev/add',
                    edit_url: 'deerhome/worker_lev/edit',
                    del_url: 'deerhome/worker_lev/del',
                    multi_url: 'deerhome/worker_lev/multi',
                    import_url: 'deerhome/worker_lev/import',
                    table: 'deerhome_worker_lev',
                }
            });

            var table = $("#table");
            table.on('post-common-search.bs.table', function (event, table) {
                $(".columns-right").hide();
            });
            // 初始化表格
            table.bootstrapTable({
                url: $.fn.bootstrapTable.defaults.extend.index_url,
                pk: 'id',
                sortName: 'id',
                columns: [
                    [
                        {field: 'name', title: __('Name'), operate: 'LIKE'},
                        {field: 'fybl', title: "额外"+ __('Fybl'), operate:'BETWEEN',formatter:function(value,row,index){
                            return `<span class="label label-primary">+${value}%</span>`;
                        }},
                        {field: 'operate', title: __('Operate'), table: table, events: Table.api.events.operate, formatter: Table.api.formatter.operate}
                    ]
                ]
            });

            // 为表格绑定事件
            Table.api.bindevent(table);
        },
        add: function () {
            Controller.api.bindevent();
        },
        edit: function () {
            Controller.api.bindevent();
        },
        api: {
            bindevent: function () {
                Form.api.bindevent($("form[role=form]"));
            }
        }
    };
    return Controller;
});
