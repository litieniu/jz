define(['jquery', 'bootstrap', 'backend', 'table', 'form','bootstrap-select'], function ($, undefined, Backend, Table, Form,undefined) {

    var Controller = {
        index: function () {
            // 初始化表格参数配置
            Table.api.init({
                extend: {
                    index_url: 'deerhome/card_order/index' + location.search,
                    add_url: 'deerhome/card_order/add',
                    edit_url: '',
                    del_url: 'deerhome/card_order/del',
                    multi_url: 'deerhome/card_order/multi',
                    import_url: 'deerhome/card_order/import',
                    table: 'deerhome_card_order',
                }
            });

            var table = $("#table");
            table.on('post-common-search.bs.table', function (event, table) {
                var form = $("form", table.$commonsearch);
                $("input[name='deerhome_user_id']", form).addClass("selectpage")
                .data("source", "deerhome/user/index")
                .attr("placeholder", "UID/昵称/手机号")
                .data("primaryKey", "id")
                .data("field", "utel")
                .data("search-field", "id,uname,utel")
                .data("pagination", "true")
                .data("page-size", "10")
                .data("format-item", "UID{id} / {uname} / {utel}")
                .data("order-by", "id");

                $("input[name='deerhome_card_id']", form).addClass("selectpage")
                .data("source", "deerhome/card/index")
                .attr("placeholder", "套餐名称")
                .data("primaryKey", "id")
                .data("search-field", "id,name")
                .data("pagination", "true")
                .data("page-size", "10")
                .data("order-by", "id");
                // $(".columns-right").hide();
                Form.events.selectpage(form);
                $('.selectpicker', form).selectpicker();
            });
            // 初始化表格
            table.bootstrapTable({
                url: $.fn.bootstrapTable.defaults.extend.index_url,
                pk: 'id',
                sortName: 'id',
                search: false,
                searchFormVisible: true,
                fixedColumns: true,
                fixedNumber: 2,
                fixedRightNumber: 1,
                onLoadSuccess: function (data) {
                    $(".btn-editone").attr('data-shade','0.5').attr('data-area','["400px", "350px"]');
                },
                columns: [
                    [
                        {checkbox: true},
                        {field: 'status', title: __('Status'), addClass:"selectpicker2"
                        , searchList: {"1":__('Status 1'),"2":__('Status 2'),"3":__('Status 3')}
                        , custom: {"1": 'danger', "2": 'success', "3": 'default'}
                        , formatter: Table.api.formatter.label},
                        {field: 'sn', title: __('Sn'), operate: '='},
                        {field: 'deerhome_user_id', operate:'=', title: '下单用户',formatter:function(value, row, index){
                            let html='<div style="display:flex;">';
                                html+='<div style="width:50px;display: flex;align-items: center;justify-content: center;">';
                                    html+='<img src="'+row.user.face_image+'" style="width:40px;height:40px;border-radius:10px;margin-right:5px;">';
                                html+='</div>';
                                html+='<div style="display: flex;flex-direction: column;align-items: flex-start;justify-content: center;">';
                                    html+='<div>'+row.user.uname+'&nbsp;<span class="label label-default">UID '+row.deerhome_user_id+'</span></div>';
                                    html+='<div>'+row.user.utel+'</div>';
                                html+='</div>';
                            html+='</div>';
                            return html;
                        }},
                        {field: 'time_area_text', title: '套餐类型', searchList: {'1':'永久','2':'月卡','3':'季卡','4':'年卡'}, operate:false,sortable:true},
                        {field: 'time_area', title: '套餐类型', addClass:"selectpicker", visible:false, searchList: {'1':'永久','2':'月卡','3':'季卡','4':'年卡'},operate:"="},
                        {field: 'deerhome_card_id', title: __('套餐名称'), visible:false},
                        {field: 'deerhome_card_name', title: __('套餐名称'), operate: false},
                        
                        {field: 'price', title: __('Price'), operate:false,sortable:true},
                        {field: 'price_yh', title: __('Price_yh'), operate:'BETWEEN',sortable:true},
                        {field: 'price_need_pay', title: __('Price_need_pay'), operate:false,sortable:true},
                        {field: 'price_payed',sortable:true, title: __('Price_payed'), operate:'BETWEEN', formatter: function (value, row, index) {
                            return '<span style="color:#f75444;">￥'+value+'</span>';
                        }},
                        {field: 'num_total', title: __('总次数'), operate:false,sortable:true},
                        {field: 'num_left', title: __('剩余次数'), operate:'BETWEEN',sortable:true},
                        {field: 'end_time', title: __('剩余天数'),operate:false, addclass:'datetimerange', autocomplete:false,sortable:true,formatter: function (value, row, index) {
                            let day=0;
                            if(row.status==2){
                                if(row.left_day_text<10){
                                    day= '<span style="color:#f75444;">'+row.left_day_text+'</span>';
                                }else{
                                    day= row.left_day_text;
                                }
                            }
                            if(row.time_area==1){
                                day= '永久';
                            }
                            if(row.status==1 || row.status==3){
                                day=0;
                            }
                            return day;
                        }},
                        {field: 'start_time', title: __('套餐开始时间'),operate:'RANGE', addclass:'datetimerange', autocomplete:false,sortable:true},
                        {field: 'end_time', title: __('套餐结束时间'),operate:'RANGE', addclass:'datetimerange', autocomplete:false,sortable:true},
                        {field: 'add_time', title: __('Add_time'), operate:false, addclass:'datetimerange', autocomplete:false,sortable:true},
                        {field: 'pay_time', title: __('Pay_time'), operate:'RANGE', addclass:'datetimerange', autocomplete:false,sortable:true},
                        {field: 'done_time', title: __('Done_time'), operate:false, addclass:'datetimerange', autocomplete:false,sortable:true},
                        
                        
                        {field: 'operate', title: __('Operate'), table: table, events: Table.api.events.operate, formatter: Table.api.formatter.operate,buttons:[
                            {
                                name: 'detail',
                                title: function(r){
                                    return '【次卡订单详情】'+r.sn;
                                },
                                text: '详情',
                                url:'deerhome/card_order/detail?id={ids}',
                                classname: 'btn btn-xs btn-primary btn-dialog',
                                icon: 'fa fa-list',
                                extend: ' data-shade="0.5" data-toggle="tooltip" title="订单详情" ',
                            }
                        ]}
                    ]
                ]
            });

            // 为表格绑定事件
            Table.api.bindevent(table);
        },
        detail: function () {
            $(".btn-order_detail").click(function(){
                let title=$(this).data('title');
                let url=$(this).data('url');
                (parent || self).Fast.api.open(url, title, {shade:0.5});
            })
            Controller.api.bindevent();
        },
        api: {
            bindevent: function () {
                Form.api.bindevent($("form[role=form]"));
            }
        }
    };
    return Controller;
});
