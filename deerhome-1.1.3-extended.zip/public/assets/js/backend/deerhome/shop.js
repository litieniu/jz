define(['jquery', 'bootstrap', 'backend', 'table', 'form'], function ($, undefined, Backend, Table, Form) {

    var Controller = {
        index: function () {
            // 初始化表格参数配置
            Table.api.init({
                extend: {
                    index_url: 'deerhome/shop/index' + location.search,
                    add_url: 'deerhome/shop/add',
                    edit_url: 'deerhome/shop/edit',
                    del_url: 'deerhome/shop/del',
                    multi_url: 'deerhome/shop/multi',
                    import_url: 'deerhome/shop/import',
                    table: 'deerhome_shop',
                }
            });

            var table = $("#table");
            $.fn.bootstrapTable.locales[Table.defaults.locale]['formatSearch'] = function(){return "门店名称";};
            // 初始化表格
            table.bootstrapTable({
                url: $.fn.bootstrapTable.defaults.extend.index_url,
                pk: 'id',
                sortName: 'id',
                columns: [
                    [
                        {checkbox: true},
                        {field: 'id', title: __('Id'), operate: false},
                        {field: 'mdname', title: __('Mdname'), operate: 'LIKE'},
                        {field: 'worker_count', title: "服务人员数", operate: false},
                        {field: 'address', title: __('Address'), operate: 'LIKE'},
                        {field: 'latitude', title: __('Latitude'), operate:false},
                        {field: 'longitude', title: __('Longitude'), operate: false},
                        {field: 'operate', title: __('Operate'), table: table, events: Table.api.events.operate, formatter: Table.api.formatter.operate}
                    ]
                ]
            });

            // 为表格绑定事件
            Table.api.bindevent(table);
        },
        add: function () {
            Controller.api.bindevent();
        },
        edit: function () {
            Controller.api.bindevent();
        },
        api: {
            bindevent: function () {
                Form.api.bindevent($("form[role=form]"));
            }
        }
    };
    return Controller;
});
