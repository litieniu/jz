define(['jquery', 'bootstrap', 'backend', 'table', 'form'], function ($, undefined, Backend, Table, Form) {

    var Controller = {
        index: function () {
            // console.log(location)
            // 初始化表格参数配置
            Table.api.init({
                extend: {
                    index_url: 'deerhome/article/index' + location.search,
                    add_url: 'deerhome/article/add' + location.search,
                    edit_url: 'deerhome/article/edit',
                    del_url: 'deerhome/article/del',
                    multi_url: 'deerhome/article/multi',
                    import_url: 'deerhome/article/import',
                    table: 'deerhome_article',
                }
            });

            var table = $("#table");

            // 初始化表格
            table.bootstrapTable({
                url: $.fn.bootstrapTable.defaults.extend.index_url,
                pk: 'id',
                sortName: 'id',
                columns: [
                    [
                        {checkbox: true},
                        {field: 'id', title: __('Id')},
                        // {field: 'cate', title: __('Cate')},
                        {field: 'name', title: __('Name'), operate: 'LIKE'},
                        {field: 'add_time', title: __('Add_time'), operate:'RANGE', addclass:'datetimerange', autocomplete:false},
                        {field: 'operate', title: __('Operate'), table: table, events: Table.api.events.operate, formatter: Table.api.formatter.operate}
                    ]
                ]
            });

            // 为表格绑定事件
            Table.api.bindevent(table);
        },
        add: function () {
            Controller.api.bindevent();
        },
        edit: function () {
            Controller.api.bindevent();
        },
        api: {
            bindevent: function () {
                Form.api.bindevent($("form[role=form]"));
            }
        }
    };
    return Controller;
});
