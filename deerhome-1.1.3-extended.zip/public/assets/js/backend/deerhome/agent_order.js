define(['jquery', 'bootstrap', 'backend', 'table', 'form'], function ($, undefined, Backend, Table, Form) {

    var Controller = {
        index: function () {
            // 初始化表格参数配置
            Table.api.init({
                extend: {
                    index_url: 'deerhome/agent_order/index' + location.search,
                    table: 'deerhome_agent_order',
                }
            });

            var table = $("#table");
            table.on('post-common-search.bs.table', function (event, table) {
                $(".columns-right").hide();
            });
            // 初始化表格
            table.bootstrapTable({
                url: $.fn.bootstrapTable.defaults.extend.index_url,
                pk: 'id',
                sortName: 'id',
                search: false,
                columns: [
                    [
                        {field: 'status', title: __('Status')
                                , searchList: {"1":__('Status 1'),"2":__('Status 2'),"3":__('Status 3'),"4":__('Status 4'),"5":__('Status 5'),"6":__('Status 6'),"7":__('Status 7'),"8":__('Status 8')}
                                , formatter: function (value, row, index) {
                                    var color = "info";
                                    switch (value) {
                                        case 1:
                                            color = "warning";
                                            break;
                                        case 2:
                                            color = "primary";
                                            break;
                                        case 3:
                                            color = "info";
                                            break;
                                        case 4:
                                            color = "deer";
                                            break;
                                        case 5:
                                            color = "success";
                                            break;
                                        case 6:
                                            color = "danger";
                                            break;
                                        case 7:
                                            color = "danger";
                                            break;
                                        case 8:
                                            color = "default";
                                            break;
                                        default:
                                            break;
                                    }
                                    return '<span class="label label-' + color + '">' + __('Status '+row.status) + '</span>';
                                }
                            },
                            {field: 'sn', title: "订单号", operate: '=', formatter:function(value,row,index){
                                return `<a data-original-title="【订单${row.sn}】详情" class="btn-dialog" data-toggle="tooltip" title="点击查看" href="`+Fast.api.fixurl('deerhome/order/detail')+`?sn=${row.sn}&ids=${row.id}" >${row.sn}</a>`;
                            }},
                            {field: 'price_payed', title: "订单金额", operate:false},
                            {field: 'uname', title: "下单人", formatter:function(value,row,index){
                                return `${row.uname}(UID${row.jz_user_id})`;
                            }},
                            {field: 'agent_lev1_uid', title: "一级推广人", operate:false, formatter:function(value,row,index){
                                if(row.agent_lev1_uid == 0){
                                    return "-";
                                }
                                return `${row.lev1_name}(UID${row.agent_lev1_uid})`;
                            }},
                            {field: 'agent_lev1_price', title: "一级分佣", operate:false},
                            {field: 'agent_lev1_price_note', title: "一级分佣说明", operate:false, class: 'autocontent',formatter:Table.api.formatter.content},
                            {field: 'agent_lev2_uid', title: "二级推广人", operate:false, formatter:function(value,row,index){
                                if(row.agent_lev2_uid == 0){
                                    return "-";
                                }
                                return `${row.lev2_name}(UID${row.agent_lev2_uid})`;
                            }},
                            {field: 'agent_lev2_price', title: "二级分佣", operate:false},
                            {field: 'agent_lev2_price_note', title: "二级分佣说明", operate:false},
                    ]
                ]
            });

            // 为表格绑定事件
            Table.api.bindevent(table);
        },
        add: function () {
            Controller.api.bindevent();
        },
        edit: function () {
            Controller.api.bindevent();
        },
        api: {
            bindevent: function () {
                Form.api.bindevent($("form[role=form]"));
            }
        }
    };
    return Controller;
});
