define(['jquery', 'bootstrap', 'backend', 'table', 'form'], function ($, undefined, Backend, Table, Form) {

    var Controller = {
        index: function () {
            let _multiple=Config.multiple=='true';
            // 初始化表格参数配置
            Table.api.init({
                extend: {
                    index_url: 'deerhome/items_gg/index' + location.search,
                    add_url: 'deerhome/items_gg/add',
                    edit_url: 'deerhome/items_gg/edit',
                    del_url: 'deerhome/items_gg/del',
                    multi_url: 'deerhome/items_gg/multi',
                    import_url: 'deerhome/items_gg/import',
                    table: 'deerhome_items_gg',
                }
            });

            var table = $("#table");
            $.fn.bootstrapTable.locales[Table.defaults.locale]['formatSearch'] = function(){return "搜索";};
            table.on('post-common-search.bs.table', function (event, table) {
                $(".columns-right").hide();
            });
            // 初始化表格
            table.bootstrapTable({
                url: $.fn.bootstrapTable.defaults.extend.index_url,
                pk: 'id',
                sortName: 'id',
                uniqueId:'id',
                search: false,
                commonSearch: true,
                searchFormVisible: true,
                showToggle: false,
                showColumns: false,
                showExport: false,
                fixedColumns: true,
                fixedNumber: 1,
                fixedRightNumber: 1,
                columns: [
                    [
                        {checkbox: true},
                        {field: 'id', title: "ID", operate: false},
                        {field: 'items.name', title: "服务名称", operate: 'LIKE'},
                        {field: 'name', title: "服务规格", operate: 'LIKE'},
                        {field: 'dw', title: "单位", operate: false},
                        {field: 'price', title:"金额",operate:false},
                        {
                            field: 'operate', title: __('Operate'), width: 85, events: {
                                'click .btn-chooseone': function (e, value, row, index) {
                                    let obj={id: row.id,gg:row.name,name:row.items.name,price:row.price,dw:row.dw,hash:row.hash};
                                    if(_multiple){
                                        Fast.api.close([obj]);
                                        return;
                                    }
                                    Fast.api.close(obj);
                                },
                            }, formatter: function () {
                                return '<a href="javascript:;" class="btn btn-danger btn-chooseone btn-xs"><i class="fa fa-check"></i> ' + __('Choose') + '</a>';
                            }
                        }
                    ]
                ]
            });

            // 为表格绑定事件
            Table.api.bindevent(table);

            $(".btn-select").on("click",function () {
                var ids=Table.api.selectedids(table);
                if(ids.length==0){
                    Toastr.error("请选择");
                    return;
                }
                let arr=[];
                ids.forEach(function (v,i) {
                    let row=table.bootstrapTable('getRowByUniqueId', v);
                    arr.push({
                        id: row.id
                        ,gg:row.name
                        ,name:row.items.name
                        ,price:row.price
                        ,dw:row.dw
                        ,hash:row.hash
                    });
                });
                Fast.api.close(arr);
            })
        },
        add: function () {
            Controller.api.bindevent();
        },
        edit: function () {
            Controller.api.bindevent();
        },
        api: {
            bindevent: function () {
                Form.api.bindevent($("form[role=form]"));
            }
        }
    };
    return Controller;
});
