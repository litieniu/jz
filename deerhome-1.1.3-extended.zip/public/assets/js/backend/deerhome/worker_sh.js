define(['jquery', 'bootstrap', 'backend', 'table', 'form'], function ($, undefined, Backend, Table, Form,JNice) {

    var Controller = {
        index: function () {
            // 初始化表格参数配置
            Table.api.init({
                extend: {
                    index_url: 'deerhome/worker_sh/index' + location.search,
                    add_url: 'deerhome/worker_sh/add',
                    edit_url: 'deerhome/worker_sh/edit',
                    del_url: 'deerhome/worker_sh/del',
                    multi_url: 'deerhome/worker_sh/multi',
                    import_url: 'deerhome/worker_sh/import',
                    table: 'deerhome_worker_sh',
                }
            });

            var table = $("#table");
            //在普通搜索渲染后
            table.on('post-common-search.bs.table', function (event, table) {
                $(".columns-right").hide();
            });
      
            // 初始化表格
            table.bootstrapTable({
                url: $.fn.bootstrapTable.defaults.extend.index_url,
                pk: 'id',
                sortName: 'id',
                fixedColumns: true,
                search: false,
                showToggle: false,
                searchFormVisible: true,
                fixedNumber: 2,
                fixedRightNumber: 1,
                columns: [
                    [
                        {field: 'id', title: __('Id'),operate:false},
                        {field: 'status', title: __('Status'),addclass:'', searchList: {"1":__('Status 1'),"2":__('Status 2'),"3":__('Status 3')}, formatter: Table.api.formatter.status},
                        {field: 'face_image', title: __('Face_image'), operate: false, events: Table.api.events.image, formatter: Table.api.formatter.image},
                        {field: 'uname', title: __('Uname'), operate: 'LIKE'},
                        {field: 'utel', title: __('Utel'), operate: 'LIKE'},
                        {field: 'sfz_a_image', title: __('Sfz_a_image'), operate: false, events: Table.api.events.image, formatter: Table.api.formatter.image},
                        {field: 'sfz_b_image', title: __('Sfz_b_image'), operate: false, events: Table.api.events.image, formatter: Table.api.formatter.image},
                        {field: 'address', title: __('Address'), operate: 'LIKE',operate:false},
                        {field: 'add_time', title: __('Add_time'), operate:'RANGE', addclass:'datetimerange', autocomplete:false},
                        {field: 'sh_ren', title: __('Sh_ren'), operate: 'LIKE'},
                        {field: 'sh_con', title: __('Sh_con'), operate: 'LIKE'},
                        {field: 'sh_time', title: __('Sh_time'), operate:'RANGE', addclass:'datetimerange', autocomplete:false},
                        {field: 'operate', title: __('Operate'),
                        table: table,
                        events: Table.api.events.operate,
                        buttons:[
                            {
                                name: 'btn_sh',
                                text: `审核`,
                                title: function(row){ return `【${row.uname}】审核`},
                                classname: 'btn btn-xs btn-danger btn-dialog',
                                icon: 'fa fa-check',
                                url: `deerhome/worker_sh/edit`,
                                visible: function (row) {
                                    if(row.status!=1){
                                        return false;
                                    }
                                    return true;
                                }
                            },
                            {
                                name: 'detail',
                                text: `详情`,
                                title: function(row){ return `【${row.uname}】详情`},
                                classname: 'btn btn-xs btn-primary btn-dialog',
                                icon: 'fa fa-ellipsis-h',
                                url: `deerhome/worker_sh/edit`,
                                visible: function (row) {
                                    if(row.status==1){
                                        return false;
                                    }
                                    return true;
                                }
                            }
                        ],
                        formatter:Table.api.formatter.buttons
                    }
                    ]     
                ]
            });

            // 为表格绑定事件
            Table.api.bindevent(table);
        },
        add: function () {
            Controller.api.bindevent();
        },
        edit: function () {
            if($("#status_mask").val()>1){
                $("input").attr("disabled","disabled");
            }
            $("input[name='row[status]']").on("change",function(){
                var _this = $(this);
                if(_this.val()==2){
                    $(".tg_taggle").show();
                }else{
                    $(".tg_taggle").hide();
                }
            });
            Controller.api.bindevent();
        },
        api: {
            bindevent: function () {
                Form.api.bindevent($("form[role=form]"));
            }
        }
    };
    return Controller;
});
