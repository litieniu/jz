define(['jquery', 'bootstrap', 'backend', 'table', 'form'], function ($, undefined, Backend, Table, Form) {

    var Controller = {
        index: function () {
            // 初始化表格参数配置
            Table.api.init({
                extend: {
                    index_url: 'deerhome/evaluate/index' + location.search,
                    add_url: 'deerhome/evaluate/add',
                    edit_url: 'deerhome/evaluate/edit',
                    del_url: 'deerhome/evaluate/del',
                    multi_url: 'deerhome/evaluate/multi',
                    import_url: 'deerhome/evaluate/import',
                    table: 'deerhome_evaluate',
                }
            });

            var table = $("#table");
            $.fn.bootstrapTable.locales[Table.defaults.locale]['formatSearch'] = function(){return "订单号搜索";};
         
            // 初始化表格
            table.bootstrapTable({
                url: $.fn.bootstrapTable.defaults.extend.index_url,
                pk: 'id',
                sortName: 'id',
                columns: [
                    [
                        {checkbox: true},
                        {field: 'sn', title: "订单号", operate: '='},
                        {field: 'worker_pj_star_status', title: "显示", searchList: {"1":'显示',"2":'隐藏'}, formatter: Table.api.formatter.toggle, operate: '='},
                        {field: 'worker_pj_star_good', title: "精选", searchList: {"1":'是',"2":'否'}, formatter: Table.api.formatter.toggle, operate: '='},
                        {field: 'item_name', title: "服务内容", operate: 'LIKE'},
                        {field: 'item_gg_name', title: "服务规格", operate: 'LIKE'},
                        {field: 'num', title:"数量", operate: false},
                        {field: 'price_need_pay', title:"金额"},
                        {field: 'worker_name', title:"服务人员"},
                        {field: 'worker_pj_star', title: '评价星级', searchList: {"1":'一星',"2":'二星',"3":'三星',"4":'四星',"5":'五星'}, formatter: Table.api.formatter.label},
                        {field: 'worker_pj_con', title: __('Con'), operate: 'LIKE'},
                        {field: 'worker_pj_con_images', title:'晒图', operate: false, events: Table.api.events.image, formatter: Table.api.formatter.images},
                        {field: 'worker_pj_time', title: '评价时间', operate:'RANGE', addclass:'datetimerange', autocomplete:false}
                    ]
                ]
            });

            // 为表格绑定事件
            Table.api.bindevent(table);
        },
        add: function () {
            Controller.api.bindevent();
        },
        edit: function () {
            Controller.api.bindevent();
        },
        api: {
            bindevent: function () {
                Form.api.bindevent($("form[role=form]"));
            }
        }
    };
    return Controller;
});
