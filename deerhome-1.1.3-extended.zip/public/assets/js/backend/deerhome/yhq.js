define(['jquery', 'bootstrap', 'backend', 'table', 'form'], function ($, undefined, Backend, Table, Form) {

    var Controller = {
        index: function () {
            // 初始化表格参数配置
            Table.api.init({
                extend: {
                    index_url: 'deerhome/yhq/index' + location.search,
                    add_url: 'deerhome/yhq/add',
                    edit_url: 'deerhome/yhq/edit',
                    del_url: 'deerhome/yhq/del',
                    multi_url: 'deerhome/yhq/multi',
                    import_url: 'deerhome/yhq/import',
                    table: 'deerhome_yhq',
                }
            });

            var table = $("#table");
            $.fn.bootstrapTable.locales[Table.defaults.locale]['formatSearch'] = function(){return "活动名称";};
           
            // 初始化表格
            table.bootstrapTable({
                url: $.fn.bootstrapTable.defaults.extend.index_url,
                pk: 'id',
                sortName: 'id',
                fixedColumns: true,
                fixedNumber: 2,
                fixedRightNumber: 1,
                columns: [
                    [
                        {checkbox: true,formatter:function (value,row,index) {
                            if(row.status>1){
                                return {
                                    disabled:true
                                };
                            }
                        }},
                        {field: 'id', title: __('Id'), operate: false},
                        {field: 'status', title: __('Status'),addclass:'niceSelect', searchList: {"1":__('Status 1'),"2":__('Status 2'),"3":__('Status 3'),"4":__('Status 4')}, formatter: Table.api.formatter.status},
                        {field: 'name', title: __('Name'), operate: 'LIKE'},
                        {field: 'type', title: __('Type'), operate: false, formatter: function (value, row, index) {
                            if(value==1){
                                return `<span class="label label-primary">满减券</span>`;
                            }
                            return '无';
                        }},
                        {field: 'money_lev', title: __('Money_lev'), operate:'BETWEEN'},
                        {field: 'money_yh', title: __('Money_yh'), operate:'BETWEEN'},
                        {field: 'cate_name', title: __('Jz_cate_ids'), operate:false, formatter: function (value, row, index) {
                            if(row.jz_cate_ids=='0'){
                                return `<span class="label label-primary">${value}</span>`;
                            }
                            return value;
                        }},
                        {field: 'start_day', title: __('Start_day'), operate:'RANGE', addclass:'datetimerange', autocomplete:false, formatter: function (value, row, index) {
                            return `${value} 00:00:00`;
                        }},
                        {field: 'end_day', title: __('End_day'), operate:'RANGE', addclass:'datetimerange', autocomplete:false, formatter: function (value, row, index) {
                            return `${value} 23:59:59`;
                        }},
                        {field: 'code', title: __('Code'), operate: 'LIKE'},
                        {field: 'addtime', title: __('Addtime'), operate:'RANGE', addclass:'datetimerange', autocomplete:false},
                        {field: 'user.utel', title: __('Jz_user_id'), formatter: function (value, row, index) {
                            if(row.user.utel){
                                return `${row.user.utel}`;
                            }
                            return '-';
                        }},
                        {field: 'get_time', title: __('Get_time'), operate:'RANGE', addclass:'datetimerange', autocomplete:false},
                        {field: 'order_sn', title: __('Order_sn')},
                        {field: 'use_time', title: __('Use_time'), operate:'RANGE', addclass:'datetimerange', autocomplete:false},
                        {field: 'operate', title: __('Operate'), table: table, events: Table.api.events.operate, formatter: Table.api.formatter.buttons,buttons:[
                            {
                                name: 'detail',
                                text: `详情`,
                                title: function(row){ return `【ID${row.id}】详情`},
                                classname: 'btn btn-xs btn-success btn-dialog',
                                icon: 'fa fa-ellipsis-h',
                                url: `deerhome/yhq/edit`,
                            }
                        ],}
                    ]
                ]
            });

            // 为表格绑定事件
            Table.api.bindevent(table);
        },
        add: function () {
            Controller.api.bindevent();
        },
        edit: function () {
            $("input").attr("disabled","disabled");
            Controller.api.bindevent();
        },
        api: {
            bindevent: function () {
                Form.api.bindevent($("form[role=form]"));
            }
        }
    };
    return Controller;
});
