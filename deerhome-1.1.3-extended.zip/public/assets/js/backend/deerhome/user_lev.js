define(['jquery', 'bootstrap', 'backend', 'table', 'form'], function ($, undefined, Backend, Table, Form) {

    var Controller = {
        index: function () {
            // 初始化表格参数配置
            Table.api.init({
                extend: {
                    index_url: 'deerhome/user_lev/index' + location.search,
                    add_url: 'deerhome/user_lev/add',
                    edit_url: 'deerhome/user_lev/edit',
                    del_url: 'deerhome/user_lev/del',
                    multi_url: 'deerhome/user_lev/multi',
                    import_url: 'deerhome/user_lev/import',
                    table: 'deerhome_user_lev',
                }
            });

            var table = $("#table");
            table.on('post-common-search.bs.table', function (event, table) {
                $(".columns-right").hide();
            });
            // 初始化表格
            table.bootstrapTable({
                url: $.fn.bootstrapTable.defaults.extend.index_url,
                pk: 'id',
                sortName: 'id',
                fixedColumns: true,
                fixedRightNumber: 1,
                columns: [
                    [
                        {field: 'bg_image', title: __('Bg_image'), operate: false, events: Table.api.events.image, formatter: Table.api.formatter.image},
                        {field: 'name', title: __('Name'), operate: 'LIKE', table: table, class: 'autocontent', formatter: Table.api.formatter.content},
                        {field: 'lev', title: __('Lev')},
                        {field: 'discount', title: __('Discount'), operate:false,formatter: function (value, row, index) {
                            return value + '%';
                        }},
                        {field: 'task', title: __('Task'),formatter: function (value, row, index) {
                            let str = '';
                            if(row.task_type==1){
                                str = '全部满足';
                            }
                            if(row.task_type==2){
                                str = '满足任意一个';
                            }
                            value.forEach(function (item) {
                                str += '<br>'+item.name+'：'+item.num;
                            });
                            return str;
                        }},
                        {field: 'note', title: __('Note'), operate: 'LIKE', table: table, class: 'autocontent', formatter: Table.api.formatter.content},
                        {field: 'operate', title: __('Operate'), table: table, events: Table.api.events.operate, formatter: Table.api.formatter.operate}
                    ]
                ]
            });

            // 为表格绑定事件
            Table.api.bindevent(table);
        },
        add: function () {
            Controller.api.bindevent();
        },
        edit: function () {
            Controller.api.bindevent();
        },
        api: {
            bindevent: function () {
                Form.api.bindevent($("form[role=form]"));
            }
        }
    };
    return Controller;
});
