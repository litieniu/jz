define(['jquery', 'bootstrap', 'backend', 'table', 'form'], function ($, undefined, Backend, Table, Form) {

    var Controller = {
        index: function () {
            // 初始化表格参数配置
            Table.api.init({
                extend: {
                    index_url: 'deerhome/order_pay_log/index' + location.search,
                    add_url: 'deerhome/order_pay_log/add',
                    edit_url: 'deerhome/order_pay_log/edit',
                    del_url: 'deerhome/order_pay_log/del',
                    multi_url: 'deerhome/order_pay_log/multi',
                    import_url: 'deerhome/order_pay_log/import',
                    table: 'deerhome_order_pay_log',
                }
            });

            var table = $("#table");
            table.on('post-common-search.bs.table', function (event, table) {
                if(Config.dialog==1){
                    $(".columns-right").hide();
                    return;
                }
                var form = $("form", table.$commonsearch);
                $("input[name='deerhome_user_id']", form).addClass("selectpage")
                .data("source", "deerhome/user/index")
                .attr("placeholder", "UID/昵称/手机号")
                .data("primaryKey", "id")
                .data("field", "utel")
                .data("search-field", "id,uname,utel")
                .data("pagination", "true")
                .data("page-size", "10")
                .data("format-item", "UID{id} / {uname} / {utel}")
                .data("order-by", "id");
                
            });
            // 初始化表格
            table.bootstrapTable({
                url: $.fn.bootstrapTable.defaults.extend.index_url,
                pk: 'id',
                sortName: 'id',
                search: false,
                searchFormVisible: Config.dialog!=1,
                fixedColumns: true,
                fixedNumber: 1,
                columns: [
                    [
                        {field: 'status',addClass:"selectpicker", title: __('Status'), searchList: {"1":__('Status 1'),"2":__('Status 2'),"3":__('Status 3')}, formatter: function(value,row,index){
                            if(value==1){
                                return '<span class="label label-danger"><i class="fa fa-clock-o"></i> 待支付</span>';
                            }
                            if(value==2){
                                return '<span class="label label-success"><i class="fa fa-check"></i> 已支付</span>';
                            }
                            if(value==3){
                                return '<span class="label label-warning"><i class="fa fa-close"></i> 已取消</span>';
                            }
                            return '-';
                        }},
                        {field: 'deerhome_user_id', title: '用户UID', operate:'='},
                        {field: 'id', title: '支付流水号',formatter:function (value,row,index) {
                            return (row.order_sn || 'VIP-CARD-')+'S'+value;
                        },operate:false},
                        {field: 'order_sn', title: '关联订单号', operate: '=',formatter:function (value,row,index) {
                            return row.order_sn;
                        }},
                        {field: 'price', title: __('Price'), operate:'BETWEEN'},
                        
                        {field: 'payway_type',addClass:"selectpicker", title: __('Payway_type'), searchList: {"1":__('Payway_type 1'),"2":__('Payway_type 2')}, formatter: Table.api.formatter.label},
                        {field: 'pay_way', title: __('Pay_way'), operate: '='},
                        {field: 'note', title: __('Note'), operate: 'LIKE'},
                        {field: 'pay_time', title: __('Pay_time'), operate:'RANGE', addclass:'datetimerange', autocomplete:false},
                        {field: 'add_time', title: __('Add_time'), operate:'RANGE', addclass:'datetimerange', autocomplete:false,operate:false},
                    ]
                ]
            });

            // 为表格绑定事件
            Table.api.bindevent(table);
        },
        add: function () {
            Controller.api.bindevent();
        },
        edit: function () {
            Controller.api.bindevent();
        },
        api: {
            bindevent: function () {
                Form.api.bindevent($("form[role=form]"));
            }
        }
    };
    return Controller;
});
