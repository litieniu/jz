define(['jquery', 'bootstrap', 'backend', 'table', 'form'], function ($, undefined, Backend, Table, Form) {

    var Controller = {
        index: function () {
            // 初始化表格参数配置
            Table.api.init({
                extend: {
                    index_url: 'deerhome/fapiao/index' + location.search,
                    add_url: 'deerhome/fapiao/add',
                    edit_url: 'deerhome/fapiao/edit',
                    del_url: 'deerhome/fapiao/del',
                    multi_url: 'deerhome/fapiao/multi',
                    import_url: 'deerhome/fapiao/import',
                    table: 'deerhome_fapiao',
                }
            });

            var table = $("#table");
          
            // 初始化表格
            table.bootstrapTable({
                url: $.fn.bootstrapTable.defaults.extend.index_url,
                pk: 'id',
                sortName: 'id',
                fixedColumns: true,
                fixedRightNumber: 1,
                columns: [
                    [
                        {field: 'id', title: __('Id'),operate:false},
                        {field: 'jz_user_id', title: __('Jz_user_id'),formatter:function (value,row,index) {
                                return row.user.uname;
                        }},
                        {field: 'status', title: __('Status'),addclass:'niceSelect', searchList: {"1":__('Status 1'),"2":__('Status 2')}, formatter: Table.api.formatter.status},
                        
                        {field: 'price', title: __('Price'), operate:'BETWEEN'},
                        {field: 'type', title: __('Type'),addclass:'niceSelect', searchList: {"1":__('Type 1'),"2":__('Type 2')}, formatter: Table.api.formatter.normal},
                        {field: 'name', title: __('Name'), operate: 'LIKE'},
                        {field: 'code', title: __('Code'), operate: 'LIKE'},
                        {field: 'file', title: __('File'), operate: false, formatter: function (value,row,index) {
                            if(value=="" || !value){
                                return '-';
                            }
                            return '<a href="'+Fast.api.cdnurl(value)+'" target="_blank"><img src="'+Fast.api.fixurl("ajax/icon?suffix=pdf")+'" class="img-sm img-center"></a>';
                        }},
                        {field: 'orders', title: __('Orders'), operate: 'LIKE'},
                        {field: 'add_time', title: __('Add_time'), operate:'RANGE', addclass:'datetimerange', autocomplete:false},
                        {field: 'res_time', title: __('Res_time'), operate:'RANGE', addclass:'datetimerange', autocomplete:false},
                        {field: 'operate', title: __('Operate'), table: table, events: Table.api.events.operate, buttons:[
                            {
                                name: 'btn_sh',
                                text: `开发票`,
                                title: function(row){ return `ID【${row.id}】开发票`},
                                classname: 'btn btn-xs btn-success btn-dialog',
                                icon: 'fa fa-check',
                                url: `deerhome/fapiao/edit`,
                                visible: function (row) {
                                    if(row.status!=1){
                                        return false;
                                    }
                                    return true;
                                }
                            }
                        ],
                        formatter:Table.api.formatter.buttons}
                    ]
                ]
            });

            // 为表格绑定事件
            Table.api.bindevent(table);
        },
        add: function () {
            Controller.api.bindevent();
        },
        edit: function () {
            Controller.api.bindevent();
        },
        api: {
            bindevent: function () {
                Form.api.bindevent($("form[role=form]"));
            }
        }
    };
    return Controller;
});
