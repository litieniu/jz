var _loading = function () {
    $("<div class=\"datagrid-mask\"></div>").css({
        display: "block",
        width: "100%",
        zIndex: '99999998',
        height: $(window).height()
    }).appendTo("body");
    $("<div class=\"datagrid-mask-msg\"></div>").html("Loading...").appendTo("body").css({
        display: "block",
        zIndex: '99999999',
        fontSize: '12px',
        color: '#444',
        left: ($(document.body).outerWidth(true) - 190) / 2,
        top: ($(window).height() - 45) / 2
    });
}
var _loadingHide = function () {
    $(".datagrid-mask").remove();
    $(".datagrid-mask-msg").remove();
}

Deer = {};
Deer.post = function (url, par, okCallback, errCallback, vmObj) {
    vm = vm || vmObj;
    $.post(url, par, function (r) {
            vm.subLoading = false;
            if (r.code != 1) {
                if (typeof errCallback == "function") {
                    errCallback(r);
                    return;
                }
                vm.$alert(r.msg, '', {
                    type: 'error'
                })
                return;
            }
            if (typeof okCallback == "function") {
                okCallback(r.data, r);
                return;
            }
            Deer.ok();
        }, "json")
        .fail(function () {
            Deer.err("网络繁忙，请稍后重试！")
            if (vm.subLoading) {
                vm.subLoading = false;
            }
            if (typeof errCallback == "function") {
                errCallback({
                    msg: "网络繁忙，请稍后重试！"
                });
                return;
            }
        });
}
Deer.alert = function (str, vmObj) {
    vm = vm || vmObj;
    vm.$alert(str, '', {
        type: 'error'
    })
}
Deer.ask = function (str, okCallback, vmObj) {
    vm = vm || vmObj;
    vm.$confirm(str, '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
    }).then(() => {
        okCallback && okCallback();
    }).catch(() => {});
}
Deer.del = function (url, par, okCallback, vmObj) {
    vm = vm || vmObj;
    vm.$confirm('此操作将永久删除, 是否继续?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
    }).then(() => {
        Deer.post(url, par, okCallback)
    }).catch(() => {});
}
Deer.tip = function (str, type) {
    vm = vm || vmObj;
    vm.$message({
        type: type || 'success',
        showClose: true,
        message: str || '上传成功!'
    });
}
Deer.ok = function (str) {
    vm = vm || vmObj;
    vm.$message({
        type: 'success',
        showClose: true,
        message: str || '操作成功!'
    });
}
Deer.err = function (str) {
    vm = vm || vmObj;
    if(!vm.$message){alert(str);return;}
    vm.$message({
        type: 'error',
        showClose: true,
        message: str || '操作失败!'
    });
}
Deer.info = function (str) {
    vm = vm || vmObj;
    vm.$message({
        type: 'warning',
        showClose: true,
        message: str
    });
}
Deer.resetObj = function (obj) {
    for (k in obj) {
        // console.log(k,typeof obj[k]);
        var type = typeof obj[k];
        if (type == "object") {
            // console.log(k,obj[k].constructor,obj[k].constructor==Array)
            if (obj[k].constructor == Array) {
                obj[k] = [];
            } else {
                obj[k] = {};
            }
        } else if (type == "boolean") {
            obj[k] = false;
        } else if (type == "number") {
            obj[k] = 0;
        } else {
            obj[k] = "";
        }
    }
    // console.log(obj);
    return obj;
}

Deer.isMoney = function (arg) { //22,111,22.11   判断是否是金额

    arg = arg.toString();
    argChar = "0123456789.,";
    var beginArg = arg.substring(0, 1);
    if (beginArg == "." || beginArg == ",") {
        return false;
    }

    for (var i = 0; i < arg.length; i++) {
        if (argChar.indexOf(arg.substring(i, i + 1)) == -1) return false;
    }
    return true;
}